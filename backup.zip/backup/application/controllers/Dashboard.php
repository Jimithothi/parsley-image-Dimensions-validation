<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * @package     CodeIgniter
 * @author      Ikraftsolutions
 * @copyright   Copyright (c) Ikraftsolutions (http://ikraftsolutions.com)
 * @version 1.0
 */

class Dashboard extends SB_Controller {

	protected $layout = "admin/layouts/main";
	
    function __construct()
    {
        parent::__construct();    
    if(!$this->session->userdata('logged_in')) redirect('user/login',301);      
    }

  public function index()
  {
    $this->data = array();
    
    
    $total_courses = $this->db->get_where('course_master')->result();
    
    
    
    $userData=array(
    		'ROLE_ID'=>DEFAULT_USER_GROUP
    );
    $total_users = $this->db->get_where('user_master',$userData)->result();
    
    
    
    $this->data['total_courses']=count($total_courses);
    
    $this->data['total_users']=count($total_users);
        
    $this->data['content'] = $this->load->view('dashboard',$this->data,true);    
    $this->load->view($this->layout,$this->data);
  }
  
  
  
  
  
}
