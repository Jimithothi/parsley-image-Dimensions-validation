<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * @package     CodeIgniter
 * @author      Ikraftsolutions
 * @copyright   Copyright (c) Ikraftsolutions (http://ikraftsolutions.com)
 * @version 1.0
 */

class My_courses extends SB_Controller {

	protected $layout 	= "frontend/layouts/main";
	
	function __construct()
	{
		parent::__construct();
		//$this->load->model('coursesmodel');
		//$this->model = $this->coursesmodel;
		$this->load->model('mycoursemodel');
		$this->model = $this->mycoursemodel;
	
	}
	
	function index()
	{
		
		$USER_ID= $this->session->userdata('userId');
		
		$myCourseID=$this->model->userEnrollcourse($USER_ID);
		/*
		
		echo "<pre>";
		print_r($myCourseID);
		echo "</pre>";
		
		//exit;
		*/
		$this->data['result']=$myCourseID;
		
		if(isset($myCourseID))
		{
			for($i=0;$i<count($myCourseID);$i++)
			{
				$myCourseName[$i]=$this->model->CourseName($myCourseID[$i]['COURSE_ID']);
			}
			/*
			echo "#################################################";
			echo "<pre>";
			print_r($myCourseName);
			echo "</pre>";
			*/
			
			//echo "#################################################";
			
			
			for($i=0;$i<count($myCourseID);$i++)
			{
				$courseName[$i]=SiteHelpers::seoUrl($myCourseName[$i]['COURSE_NAME'],'dash');
			}
			
			
			
			//echo "#################################################";
			
			for($i=0;$i<count($myCourseID);$i++)
			{
				$courseCover[$i]=$this->model->courseCover($myCourseName[$i]['COURSE_ID']);
			}
			
			/*echo "<pre>";
			print_r($courseCover);
			echo "</pre>";
			
			
			echo "################################################";
			*/
			
			for($i=0;$i<count($myCourseID);$i++)
			{
				$shortContent[$i]=$this->model->getLatestcoursecontent($myCourseName[$i]['COURSE_ID']);
			}
			
			/*echo "################################################";
			echo "<pre>";
			print_r($shortContent);
			echo "</pre>";
			*/
			if(isset($myCourseName))
			{
			
				$this->data['myCourseName']=$myCourseName;  //course Name
				$this->data['courseName']=$courseName;  // course url
				$this->data['shortContent']=$shortContent;  // short content
				$this->data['courseCover']=$courseCover;	// course cover
						
				
			}
			

		}
		
	
		
		$this->data['content'] = $this->load->view('frontend/my_courses/index',$this->data,true);
		
		$this->load->view($this->layout, $this->data );
	}
  
  
  
  
}
