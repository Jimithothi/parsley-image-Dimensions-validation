<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * @package     CodeIgniter
 * @author      Ikraftsolutions
 * @copyright   Copyright (c) Ikraftsolutions (http://ikraftsolutions.com)
 * @version 1.0
 */


class User extends CI_controller {

  protected $_key   = 'id';
  protected $_class  = 'welcome';
  protected $_model  = 'usersmodel';
  protected $layout = "admin/layouts/main";

  function __construct()
  {
    parent::__construct();
    //if(!$this->session->userdata('logged_in')) redirect('admin',301);
    //else redirect('dashboard');
  }

  public function index()
  {
  	 if(!$this->session->userdata('logged_in')) redirect('admin/user/login',301);
  	
  	else redirect('dashboard');
  	
   
  }

  public function profile()
  {
    if(!$this->session->userdata('logged_in')) redirect('user/login',301);

    $info =  $this->db->get_where('user_master',array('USER_ID'=>$this->session->userdata('uid')));
    $this->data = array(
      'pageTitle'  => 'My Profile',
      'pageNote'  => 'View Detail My Info',
      'info'    => $info->row(),
    );
    $this->data['content'] = $this->load->view('user/profile',$this->data, true );
      $this->load->view($this->layout, $this->data );
  }

  public function savePassword()
  {
    $rules = array(
      array('field'   => 'password','label'   => 'password','rules'   => 'required'),
      array('field'   => 'password_confirmation','label' => 'password confirmation','rules'   => 'required|matches[password]'),
    );
    $this->form_validation->set_rules( $rules );
    if( $this->form_validation->run() ){
    	
    

      $data = array('PASSWORD'=>md5(trim($this->input->post('password'))));
      $this->db->where('USER_ID' ,$this->session->userdata('uid'));
      $this->db->update('user_master',$data);
      SiteHelpers::alert('success'," Your password has been changed succesfuly");
     // $this->session->set_flashdata('message',SiteHelpers::alert('success','Your password has been changed succesfuly'));
      redirect('admin/user/profile',301);

    } else {
    //  $this->session->set_flashdata('message','Password And Confirm-password doesnot match !');
      SiteHelpers::alert('error','Password And Confirm-password doesnot match !');
      redirect('admin/user/profile',301);
    }

  }

  public function login()
  {

  	if(!$this->session->userdata('logged_in'))
  	{
  		
  		 $this->data['email'] = '';
	    if( $this->session->userdata("_POST_DATA")){
	      $this->data = array_merge( $this->data , $this->session->userdata("_POST_DATA"));
	      $this->session->unset_userdata('_POST_DATA');
	    }
	    
	    $this->data['content'] = $this->load->view('user/login',$this->data, true );
	      $this->load->view('admin/layouts/login', $this->data );
	} 
  	else{
  		redirect('dashboard');
  	}

   
  }

  public function postLogin()
  {
    $data = array(
      'USER_NAME'    => trim($this->input->post('email')),
      'PASSWORD'  => md5(trim($this->input->post('password'))),
      'INACTIVE'  => '1'
    );

    $row = $this->db->get_where('user_master',$data)->row();
    if(count($row) >= 1)
    {
      $this->session->set_userdata(array(
        'logged_in'  => true,
        'uid'    => $row->USER_ID,
        'gid'    => $row->ROLE_ID,
        'eid'    => $row->USER_NAME,
       // 'll'    => $row->last_login,
        'fid'    => $row->FIRST_NAME.' '.$row->LAST_NAME,
      	'NICK_NAME'=>$row->NICK_NAME
      ));
      redirect('dashboard',301);

    } else {
      $this->session->set_flashdata('message',SiteHelpers::alert('error','Invalid email or password combination <br /> or your account is not active yet'));
      redirect('admin/user/login',301);
    }

  }
 
  public function logout()
  {
    $this->session->unset_userdata(array(
        'logged_in'  => '',
        'uid'    => '',
        'gid'    => '',
        'eid'    => '',
        'll'    => '',
        'fid'    => '',
    	'NICK_NAME'=>''
      ));
    redirect('admin',301);
  }
  


}

/* End of file welcome.php */
/* Location: ./application/controllers/page.php */