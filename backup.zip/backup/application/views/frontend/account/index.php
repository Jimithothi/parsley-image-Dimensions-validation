<div id="wrapper-content">
		<!-- PAGE WRAPPER-->
		<div id="page-wrapper">
			<!-- MAIN CONTENT-->
			<div class="main-content">
				<!-- CONTENT-->
				<div class="content">

					<div class="section section-padding courses-detail">
						<div class="container">
							<div class="courses-detail-wrapper">
								<div class="row">
								<form action="<?php echo site_url('account'); ?>" method="post" enctype="multipart/form-data">
								
									<div class="col-md-9 layout-right">
										
										
											<div id="appearance">
											<legend>Appearance</legend>
											
											<div class="image-edit image-edit--avatar">
												<span class="avatar avatar--xxl"> <img
													title="<?php echo $row['NICK_NAME']?>" alt="<?php echo $row['NICK_NAME']?>"
													src="<?php echo base_url()?>uploads/users/<?php echo $row['USER_IMAGE']?>" width="80px" heigth="80px">
												</span>
												<div class="form-group file optional user_s3_avatar">
													<label class="file optional control-label"
														for="user_s3_avatar">User image <em>(Recommended
															800x800)</em>
													</label><input class="file optional" type="file"
														name="user_avatar" id="user_s3_avatar">
												</div>
												
												<div class="form-actions">
													<button name="commit" type="submit" class="btn btn-green">
														Save changes
													</button>
												</div>
											</div>

										</div>
										
												
										<div id="about-you" style="margin-top: 15px">
											<fieldset>
												<legend>About you</legend>
												<div class="row">
													<div class="col-sm-9">
														<div class="input-label-icon">
															<div class="form-group string optional user_permalink">
																<label class="string optional control-label"
																	for="user_permalink">Nickname</label><input
																	class="string optional input-lg form-control"
																	type="text" value="<?php echo $row['NICK_NAME']?>"
																	name="user[permalink]" disabled id="user_permalink">
																
															</div>
														</div>
													</div>
												</div>
												<div class="row">
													<div class="col-sm-3">
														<div class="form-group string optional user_name">
															<label class="string optional control-label"
																for="user_name">Name</label><input
																class="string optional input-lg form-control"
																type="text" value="<?php echo $row['FIRST_NAME']?>" name="user[name]"
																id="user_name">
														</div>
													</div>
													<div class="col-sm-6">
														<div class="form-group string optional user_last_name">
															<label class="string optional control-label"
																for="user_last_name">Surname</label><input
																class="string optional input-lg form-control"
																type="text" value="<?php echo $row['LAST_NAME']?>"
																name="user[last_name]" id="user_last_name">
														</div>
													</div>
												</div>
												<div class="row">
													<div class="col-sm-6">
														<div
															class="form-group string optional user_seeking_this_job">
															<label class="string optional control-label"
																for="user_seeking_this_job">Professional
																headline</label><input
																class="string optional input-lg form-control"
																type="text" value="<?php echo $row['PROFESSIONAL_HEADLINE']?>" name="user[professional]"
																id="user_seeking_this_job">
														</div>
													</div>
												
												</div>
												
												<div class="row">
													<div class="col-sm-12">
														<div class="form-group text optional user_about_me">
															<label class="text optional control-label"
																for="user_about_me">Tell something about you and
																yourself</label>
															<textarea
																class="text optional form-control bbedit form-control"
																rows="5" name="user[about_me]" id="user_about_me"><?php echo $row['TELL_ABOUT_YOURSELF']?></textarea>
														</div>
													</div>
												</div>
											</fieldset>
											<div class="form-actions">
												<button name="commit" type="submit" class="btn btn-green">
													 Save changes
												</button>
											</div>
										</div>
										
									
										
										<div id="contact" style="margin-top: 15px">
											<fieldset>
												<legend>Contact</legend>
												<p class="explain">The easy way to find you</p>
												<div class="row">
													<div class="col-sm-6">
														<div class="form-group url optional user_website">
															<label class="url optional control-label"
																for="user_website">Website</label><input
																class="string url optional input-lg form-control"
																type="url" value="<?php echo $row['WEBSITE']?>" name="user[website]"
																id="user_website">
															<p class="help-block">Add http:// and some love to
																make it work.</p>
														</div>
													</div>
													<div class="col-sm-6">
														<div class="form-group tel optional user_phone">
															<label class="tel optional control-label"
																for="user_phone">Phone</label><input
																class="string tel optional input-lg form-control"
																type="tel" value="<?php echo $row['PHONE']?>" name="user[phone]"
																id="user_phone">
														</div>
													</div>
												</div>
											</fieldset>
											<div class="form-actions">
												<button name="commit" type="submit" class="btn btn-green">
													 Save changes
												</button>
											</div>
										</div>



										<!-- test end -->
									</div>
									</form>
									<div class="col-md-3 sidebar layout-left">
										<div class="row">
											<div class="clearfix"></div>
											<div
												class="category-widget widget col-sm-6 col-md-12 col-xs-6 sd380">
												<div class="title-widget">Edit Profile</div>
												<div class="content-widget">
													<aside>
														<nav role="navigation">
															<ul>
																<li><a href="#appearance" class="js-smooth-scroll"><span
																		class="pull-left">Your Photo</span></a></li>
																<li><a href="#about-you" class="js-smooth-scroll"><span
																		class="pull-left">About you</span></a></li>
																<li><a href="#learning" class="js-smooth-scroll"><span
																		class="pull-left">Learning</span></a></li>
																<li><a href="#areas" class="js-smooth-scroll"><span
																		class="pull-left">Area</span></a></li>
																<li><a href="#contact" class="js-smooth-scroll"><span
																		class="pull-left">Contact</span></a></li>
															</ul>
														</nav>
													</aside>
												</div>
											</div>
											<div class="clearfix"></div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- BUTTON BACK TO TOP-->
		<div id="back-top">
			<a href="#top"><i class="fa fa-angle-double-up"></i></a>
		</div>
	</div>

<?php $this->load->view('frontend/layouts/footer');?>