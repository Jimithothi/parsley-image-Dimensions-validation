<style type="text/css">
</style><header>
		<div class="header-topbar">
			<div class="container">
				<div class="topbar-left pull-left">
					<div class="email">
						<a><i class="topbar-icon fa fa-envelope-o"></i><span><?php echo  CONTACT_MAIL ;?></span></a>
					</div>
					<div class="hotline">
						<a href="#"><i class="topbar-icon fa fa-phone"></i><span><?php echo  PHONE_CONTACT ;?></span></a>
					</div>
				</div>
				<?php // print_r($this->session->all_userdata('login_ID'))?>
				
				<?php  if(!$this->session->userdata('login_ID')){
				//echo "Hello";
					?>
				<div class="topbar-right pull-right">

					<div class="group-sign-in">
						<button type="button" class="btn btn-green" data-toggle="modal"
							data-target="#myModalLogin">
							<span><?php echo $this->lang->line('core.login'); ?></span>
						</button>
						<button type="button" class="btn btn-green" data-toggle="modal"
							data-target="#myModalRegister">
							<span><?php echo $this->lang->line('core.register'); ?></span>
						</button>
					</div>
				</div><?php }
				
				else{
				?>
				<div class="topbar-right pull-right">
					<span class="dropdown pull-right"><a href="javascript:void(0)"
						data-toggle="dropdown" aria-expanded="true" class="main-menu"><?php //echo $this->session->userdata('nickName')?> 
						
						
						<img src="<?php echo $this->session->userdata('user_avatar')?>" alt="Profile"
							class="img-circle pull-right" width="48" height="48" />
							
							</a>
						<div class="dropdown-menu pull-right" role="menu">
							<ul>
								<li><a href="<?php echo base_url()?>account/edit" style="color: #000000"><i
										class="fa fa-edit fa-fw"></i><?php echo $this->lang->line('core.edit_profile'); ?></a></li>
								<li><a href="<?php echo base_url()?>my_courses" style="color: #000000"><i
										class="fa fa-bookmark fa-fw"></i><?php echo $this->lang->line('core.my_courses'); ?></a></li>
								<li><a href="<?php echo base_url()?>home/logout" style="color: #000000"><i
										class="fa fa-arrow-left fa-fw"></i><?php echo $this->lang->line('core.log_out'); ?></a></li>
							</ul>
						</div></span>
				</div>
				<?php 
				}?>
			</div>
		</div>


<div class="modal fade" id="bsModal3" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title" id="mySmallModalLabel">Success</h4>
      </div>
      <div class="modal-body">
      
     	 <div class="alert alert-success">
  			You can register Successfully within few time receive activation link.
		</div>

       
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save changes</button>
      </div>
    </div>
  </div>
</div>

		<!-- Modal Start for Login-->
		<div class="modal fade" id="myModalLogin" role="dialog" tabindex="-1">
			<div class="modal-dialog">
				<!-- Modal content-->
				
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal">&times;</button>
						<h4 class="modal-title"><?php echo $this->lang->line('core.login'); ?></h4>
					</div>
					<div class="modal-body">
						<div class="row">
							<div class="col-md-12">
								<p class="text-center">
									<button id="fb_login"
										class="btn btn-login btn-green">
										<span><?php echo $this->lang->line('core.fblogin'); ?></span>
									</button>
								</p>
							</div>
							 <form method="post" id="login_form" data-parsley-validate='true'>
							<div class="col-md-12">
								<label class="control-label form-label"><?php echo $this->lang->line('core.signmsg'); ?></label>
							</div>
							<div class="col-md-12">
								<input id="email" name="email"  type="email" placeholder="<?php echo $this->lang->line('core.username'); ?>"
									class="form-control form-input" required/>
							</div>
							<div class="col-md-12" style="margin-top: 10px">
								<input id="password" name="password" type="password" placeholder="<?php echo $this->lang->line('core.password'); ?>"
									class="form-control form-input" required />

							</div>
							<div class="col-md-12" style="margin-top: 10px">
								<div class="pull-right">
									<a href="<?php echo base_url()?>auth/password/new" id="Forgot"><?php echo $this->lang->line('core.forget'); ?></a>
								</div>
								
								 <div id="errbox" style="display: none"></div><br>
								 
								<button type="submit"
									id="login-btn"
									class="btn btn-login btn-green">
									<span><?php echo $this->lang->line('core.login'); ?></span>
								</button>
								
								
							</div>
							</form>
						</div>
					</div>
					<div class="modal-footer">
						<p class="text-center">
							<label><?php echo $this->lang->line('core.need_account'); ?><a href="#" id="Register"><?php echo $this->lang->line('core.register'); ?></a></label>
						</p>
					</div>
				</div>
				
				  

			</div>
		</div>
		<!-- Modal End-->
		<!-- Modal Start for Register-->
		<div class="modal fade" id="myModalRegister" role="dialog"
			tabindex="-1" >
			<div class="modal-dialog">

				<!-- Modal content-->
				<div class="modal-content">
					<div class="modal-body">
						<button type="button" class="close" data-dismiss="modal">x</button>
						<p class="text-center">
							<a href="index.html"><img
								src="<?php echo base_url();?>assets/frontend/images/logo-color-1.png" alt="" class="login"></a>
						</p>
						<div class="text-center">
						<h4><?php echo $this->lang->line('core.regmsg'); ?></h4>
						</div>
						<div class="col-md-12" style="margin-top: 10px">
							<p class="text-center">
								<button 
									class="btn btn-login btn-green" id="fb_register">
									<span><?php echo $this->lang->line('core.fbregister'); ?></span>
								</button>
							</p>
						</div>
						<div class="row">
						
						
							<center></center><div class="col-md-12"><div id="fbregerrbox" style="display: none"></div></center>
								<label><?php echo $this->lang->line('core.signupmsg'); ?></label>
							</div>
							 <form method="post" id="Register_form" data-parsley-validate='true'>
							<div class="col-md-12" style="margin-top: 10px">
								<input id="regemail" name="regemail" type="email" placeholder="<?php echo $this->lang->line('core.reg_placeholder'); ?>"
									class="form-control form-input" required/><div id="regerrbox" style="display: none"></div>
									
							</div>
							<div class="col-md-12" style="margin-top: 10px">
								<input id="regpassword" name="regpassword" type="password" placeholder="<?php echo $this->lang->line('core.regpwd_placeholder'); ?>" 
									class="form-control form-input" required />
							</div>
							<div class="col-md-12" style="margin-top: 10px">
								<label class="control-label form-label"><?php echo $this->lang->line('core.when_dob'); ?></label>
							</div>
							<div class="col-sm-3">
								<select id="user_birthday_2i" name="month[]"
									class="form-select style-1 selectbox" required>
									<option value=""><?php echo $this->lang->line('core.month'); ?></option>
									<option value="1">Jan</option>
									<option value="2">Feb</option>
									<option value="3">Mar</option>
									<option value="4">Apr</option>
									<option value="5">May</option>
									<option value="6">Jun</option>
									<option value="7">Jul</option>
									<option value="8">Aug</option>
									<option value="9">Sep</option>
									<option value="10">Oct</option>
									<option value="11">Nov</option>
									<option value="12">Dec</option>
								</select>
							</div>
							<div class="col-sm-3">
								<select id="user_birthday_3i" name="data[]"
									class="form-select style-1 selectbox" required>
									<option value=""><?php echo $this->lang->line('core.day'); ?></option>
									<option value="1">1</option>
									<option value="2">2</option>
									<option value="3">3</option>
									<option value="4">4</option>
									<option value="5">5</option>
									<option value="6">6</option>
									<option value="7">7</option>
									<option value="8">8</option>
									<option value="9">9</option>
									<option value="10">10</option>
									<option value="11">11</option>
									<option value="12">12</option>
									<option value="13">13</option>
									<option value="14">14</option>
									<option value="15">15</option>
									<option value="16">16</option>
									<option value="17">17</option>
									<option value="18">18</option>
									<option value="19">19</option>
									<option value="20">20</option>
									<option value="21">21</option>
									<option value="22">22</option>
									<option value="23">23</option>
									<option value="24">24</option>
									<option value="25">25</option>
									<option value="26">26</option>
									<option value="27">27</option>
									<option value="28">28</option>
									<option value="29">29</option>
									<option value="30">30</option>
									<option value="31">31</option>
								</select>
							</div>
							<div class="col-sm-3">
								<select id="user_birthday_1i" name="year[]"
									class="form-select style-1 selectbox" required>
									<option value=""><?php echo $this->lang->line('core.year'); ?></option>
									<option value="2003">2003</option>
									<option value="2002">2002</option>
									<option value="2001">2001</option>
									<option value="2000">2000</option>
									<option value="1999">1999</option>
									<option value="1998">1998</option>
									<option value="1997">1997</option>
									<option value="1996">1996</option>
									<option value="1995">1995</option>
									<option value="1994">1994</option>
									<option value="1993">1993</option>
									<option value="1992">1992</option>
									<option value="1991">1991</option>
									<option value="1990">1990</option>
									<option value="1989">1989</option>
									<option value="1988">1988</option>
									<option value="1987">1987</option>
									<option value="1986">1986</option>
									<option value="1985">1985</option>
									<option value="1984">1984</option>
									<option value="1983">1983</option>
									<option value="1982">1982</option>
									<option value="1981">1981</option>
									<option value="1980">1980</option>
									<option value="1979">1979</option>
									<option value="1978">1978</option>
									<option value="1977">1977</option>
									<option value="1976">1976</option>
									<option value="1975">1975</option>
									<option value="1974">1974</option>
									<option value="1973">1973</option>
									<option value="1972">1972</option>
									<option value="1971">1971</option>
								</select>
							</div>
							<div class="col-sm-6">
								<p class="small"></p>
							</div><br><Br>
						
							
							<div class="col-md-12" style="margin-top: 10px">
								<button type="submit"
									id="register-btn"
									class="btn btn-register btn-green">
									<span><?php echo $this->lang->line('core.register'); ?></span>
								</button>
							</div>
							</form>
							<div class="col-md-12" style="margin-top: 10px">
								<p class="small">
									<?php echo $this->lang->line('core.terms_policy'); ?>
								</p>
							</div>
						</div>
					</div>
					<div class="modal-footer">
						<p class="text-center">
							<label class="control-label form-label"><?php echo $this->lang->line('core.already_register'); ?><a href="#" id="Login"><?php echo $this->lang->line('core.login'); ?></a>
							</label>
						</p>
					</div>
				</div>

			</div>
		</div>
		<!-- Modal End-->
		<!-- Modal Start for Forgot Password-->
		<!-- Modal End-->

		<div class="header-main homepage-01">
			<div class="container">
				<div class="header-main-wrapper">
					<div class="navbar-heade">
						<div class="logo pull-left">
							<a href="<?php echo base_url();?>" class="header-logo"><img
								src="<?php echo base_url();?>assets/frontend/images/logo-color-1.png" alt="" /></a>
						</div>
						<button type="button" data-toggle="collapse"
							data-target=".navigation" class="navbar-toggle edugate-navbar">
							<span class="icon-bar"></span><span class="icon-bar"></span><span
								class="icon-bar"></span>
						</button>
					</div>
					<nav class="navigation collapse navbar-collapse pull-right">
						<ul class="nav-links nav navbar-nav">
							<li><a href="<?php echo base_url();?>" class="main-menu"><?php echo $this->lang->line('core.home'); ?></a></li>
							<li><a href="<?php echo base_url()?>courses" class="main-menu"><?php echo $this->lang->line('core.courses'); ?></a></li>
							<li><a href="<?php echo base_url()?>help" class="main-menu"><?php echo $this->lang->line('core.help'); ?></a></li>
							<li><a href="<?php echo base_url()?>contact-us" class="main-menu"><?php echo $this->lang->line('core.contact'); ?></a></li>
							<li class="button-search"><p class="main-menu">
									<i class="fa fa-search"></i>
								</p></li>
							<div class="nav-search hide">
								<form>
									<input type="text" placeholder="Search" class="searchbox" />
									<button type="submit" class="searchbutton fa fa-search"></button>
								</form>
							</div>
						</ul>
					</nav>
				</div>
			</div>
		</div>
	</header>
	<script>
		$(document).ready(function() {

			$("#Register").on('click', function() {
				$("#myModalLogin").modal('toggle');
				$("#myModalRegister").modal({
					keyboard : true
				});
			});
			$("#Login").on('click', function() {
				$("#myModalRegister").modal('toggle');
				$("#myModalLogin").modal({
					keyboard : true
				});
			});
			$("#Forgot").on('click', function() {
				$("#myModalLogin").modal('toggle');
				$("#myModalForgot").modal({
					keyboard : true
				});
			});
			$("#myModalLogin").on('shown.bs.modal', function() {
				$('body').css('overflow', 'hidden');
				$('body').css('position', 'fixed');
			});
			$("#myModalLogin").on('hidden.bs.modal', function() {
				$('body').css('overflow', '');
				$('body').css('position', '');
			});
			$("#myModalRegister").on('shown.bs.modal', function() {
				$('body').css('overflow', 'hidden');
				$('body').css('position', 'fixed');
			});
			$("#myModalRegister").on('hidden.bs.modal', function() {
				$('body').css('overflow', '');
				$('body').css('position', '');
			});
			$("#myModalForgot").on('shown.bs.modal', function() {
				$('body').css('overflow', 'hidden');
				$('body').css('position', 'fixed');
			});
			$("#myModalForgot").on('hidden.bs.modal', function() {
				$('body').css('overflow', '');
				$('body').css('position', '');
			});

		});
	</script>
	
<script>  
  $(document).ready(function(){
	 
    $(document).on('click','#login-btn',function(){

    	var user_name = $("input#email").val();
        var password = $("input#password").val();
        if(user_name== "" || password=="")
        {
        	preventDefault();
        }
        else
        {
    	
      	  var url = "<?php echo base_url()?>home/user_login";       
          $('#logerror').html('<img src="<?php echo base_url();?>assets/frontend/images/ajax-loader.gif" align="absmiddle"> Please wait...');  
          $.ajax({
            type: "POST",
              url: url,
              data: {email: user_name, password: password}, // serializes the form's elements.
                 success: function(data)
                   {
                	 console.log(data);
                     if(data) {      
                              console.log(data);
                          	 window.location.href = "<?php echo site_url('home/add'); ?>";
                     }
                     else { 
                    	 $("#errbox").html('<span>The email or password you entered is incorrect.</span>');
                         $("#errbox").show();
                         $('#errbox').addClass("error");
                         
                         
                     }
                   }
               });
             }
        return false;
       });
});
</script>
<script>  
  $(document).ready(function(){

	
	  
	 
    $(document).on('click','#register-btn',function(){

    	var user_name = $("input#regemail").val();
        var password = $("input#regpassword").val();
        console.log(user_name);
        console.log(password);
        
        if(user_name== "" || password=="")
        {
        	preventDefault();
        }
        else
        {
    	
      		var url = "<?php echo base_url()?>home/user_register";       
      		
        	
          $('#logerror').html('<img src="<?php echo base_url();?>assets/frontend/images/ajax-loader.gif" align="absmiddle"> Please wait...');  
          ajaxindicatorstart('please wait..');
           $.ajax({
            type: "POST",
              url: url,
              dataType: 'json',
              data: {email: user_name, password: password}, // serializes the form's elements.
                 success: function(data)
                   {
                	 //console.log(data);
                	  ajaxindicatorstop(); 
                     if(data) {  
                    	
                    	 $("#myModalRegister").modal('hide');
                    	 $("#bsModal3").modal('show');
                    //	 myModalRegister
                    	 
                              //console.log(data);
                          	
                     }
                     else {
                    	 console.log('faild'); 
                    	 $("#regerrbox").html('<span>Email Address already register.</span>');
                         $("#regerrbox").show();
                         $('#regerrbox').addClass("error");
                         
                     }
                   }
               });
             }

       
        return false;
       });
  
});
  
 
</script>
        
        
        
        
        <script>
            window.fbAsyncInit = function() {
            	FB.init({
          	      appId      : '1107622615983711',
          	      xfbml      : true,
          	      status: true,
          	      cookie: true,
          	      version    : 'v2.7'
          	    });
                $("#fb_register").click(function() {
                	ajaxindicatorstart('please wait..');
                   FB.login(function(response) {
                      
                       if (response.status === 'connected') {
                          
                           FB.api('/me?fields=id,name,email,birthday,first_name,picture{url},gender', function(response) {
                        	  
                        	   var url = "<?php echo base_url()?>home/fb_register";  
                        	   var ImageURI="https://graph.facebook.com/"+response['id']+"/picture?type=large";

                        	   
                        	  $.ajax({
                                   type: "POST",
                                     url: url,
                                     data: {email: response['email'], nickName:response['name'] , first_name:response['first_name'],last_name:response['last_name'],dob:response['birthday'],FbImage:ImageURI }, // serializes the form's elements.
                                        success: function(data)
                                          {
                                       
                                       		
                                            if(data) {   
                                            	  
                                            	ajaxindicatorstop();
                                            	
                                                 	 window.location.href = "<?php echo site_url('home/add'); ?>";
                                            }
                                            else
                                            {
                                            	ajaxindicatorstop();
                                            	 console.log('faild'); 
                                            	 $("#fbregerrbox").html('<span>Already Register.</span>');
                                                 $("#fbregerrbox").show();
                                                 $('#fbregerrbox').addClass("error");
                                                
                                            }    
                                            
                                          }
                                      });
                             
                        	   
                           });
                       }
                       else {
                          
                       }
                   },{scope: 'email'});
                }); 

                $("#fb_login").click(function() {
                	ajaxindicatorstart('please wait..');

                	 FB.login(function(response) {
                         
                    FB.login(function(response) {
                        
                        if (response.status === 'connected') {
                            
                           FB.api('/me?fields=id,name,email,birthday,first_name,picture{url},gender', function(response) {
                         	   var url = "<?php echo base_url()?>home/fb_login";  
                         	  var ImageURI="https://graph.facebook.com/"+response['id']+"/picture?type=large";

                         	
                         	  
                         	 //alert('Email: ' + response.email);
                         	
                         	 
                         	   $.ajax({
                                    type: "POST",
                                      url: url,
                                      data: {email: response['email'], nickName:response['name'] , first_name:response['first_name'],last_name:response['last_name'],FbImage:ImageURI }, // serializes the form's elements.
                                      
                                      success: function(data)
                                      {

                                          
                                    	  ajaxindicatorstop();
                                        	 console.log(data);
                                             if(data) { 
                                            	   
                                                      //console.log(data);
                                                      //alert("OKKK");
                                                  	 window.location.href = "<?php echo site_url('home/add'); ?>";
                                             }
                                            
                                       }
                                       });
 							   
                            },{scope:'email'});

                            
                        }
                        else {
                         
                        }
                    });
                },{scope: 'email'});
                 }); 
            };
            (function(d){
            var js, id = 'facebook-jssdk'; if (d.getElementById(id)) {return;}
            js = d.createElement('script'); js.id = id; js.async = true;
            js.src = "//connect.facebook.net/en_US/all.js";
            d.getElementsByTagName('head')[0].appendChild(js);
            }(document));
            
          function fbLogoutUser() {
        	    FB.getLoginStatus(function(response) {
        	        if (response && response.status === 'connected') {
        	            FB.logout(function(response) {
        	                document.location.reload();
        	            });
        	        }
        	    });
        	}               
        </script>
