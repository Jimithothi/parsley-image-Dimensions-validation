<div class="mystyle">
		<br>
		
		<div class="contactform">
		
		<div class="group-title-index">
								<h2 class="center-title"  style="color:white"><?php echo $this->lang->line('core.contact'); ?></h2>

								<div class="bottom-title">
									<i class="bottom-icon icon-icon-04"></i>
								</div>
							</div>
				<input type="text" placeholder="<?php echo $this->lang->line('core.name'); ?>" name="user"><br>
				<input type="text" placeholder="<?php echo $this->lang->line('core.emails'); ?>" name="password"><br>
				<textarea name="message" placeholder="<?php echo $this->lang->line('core.message'); ?>" rows="6"></textarea><br>
				<table>
					<tr>
						<td width="20%"><input type="submit" value="<?php echo $this->lang->line('core.btn_message'); ?>" /></td>
						<td width="8%"></td>
						<td width="37%" align="right"> <button><i class="fa fa-envelope-o" aria-hidden="true"></i></button> <span><?php echo  CONTACT_MAIL ;?></span></td>
						<td width="35%" align="right"> <button><i class="fa fa-phone" aria-hidden="true"></i></button> <span>Tel:<?php echo  PHONE_CONTACT ;?></span></td>
					</tr>
				</table>
		</div>
		<div class="grad"></div>
		<footer>
				<div class="container">
				
			<div class="hyperlink">
						<div class="pull-left hyper-left">
							<p>Derechos reservados Grupoproyectarte</p>
						</div>
						<div class="pull-right hyper-right">
							<div class="socials">
								<a href="<?php echo  FB_PAGE ;?>" class="facebook"><i class="fa fa-facebook"></i></a><a
									href="<?php echo  GOOGLE_PLUS ;?>" class="google"><i class="fa fa-google-plus"></i></a><a
									href="<?php echo  TWITTER ;?>" class="twitter"><i class="fa fa-twitter"></i></a>
								<div class="pull-right hyper-right"></div>
								<div class="pull-right hyper-right">
									<div class="dropup">
										<button class="btn btn-default dropdown-toggle" type="button"
											data-toggle="dropdown">
											Language<span></span>
										</button>
										<ul class="dropdown-menu">
											<?php foreach(SiteHelpers::langOption() as $lang) : ?>
					<li><a href="<?php echo site_url('home/lang/'.$lang['folder']);?>" style="background-color: white !important"><img src="<?php echo base_url()?><?php echo $lang['flag']?>" width="25"> <?php echo $lang['name'] ;?></a></li>
				<?php endforeach;?>	
										</ul>
									</div>
								</div>
							</div>
						</div>
						<!-- <div class="pull-right hyper-right">@ SWLABS</div> -->
					</div>
					</div>
		</footer>
</div>








