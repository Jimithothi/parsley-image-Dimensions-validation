<div class="section">
						<div class="search-input">
							<div class="container">
								<div class="search-input-wrapper">
									 <form action='<?php echo site_url($pageModule) ?>' >
										<select class="form-select style-1 selectbox" name="category">
											<option value=""><?php echo $this->lang->line('core.categories'); ?></option>
											<?php for($i=0;$i<count($category);$i++)
											{
												?>
												
												<?php if($this->session->userdata('lang')=='en')
												{?>
												<option value="<?php echo $category[$i]['URL_REWRITE_EN'];?>"><?php echo $category[$i]['CATEGORY_NAME_EN']?></option>
												
												<?php }else 
												{?>
												<option value="<?php echo $category[$i]['URL_REWRITE_SP'];?>"><?php echo $category[$i]['CATEGORY_NAME_SP']?></option>
												
												<?php 
												}?>
												
												
												<?php 	
											}
												?>
										</select><select class="form-select style-2 selectbox" name="area">
										<option value=""><?php echo $this->lang->line('core.area'); ?></option>
										
										<?php for($i=0;$i<count($area);$i++)
											{
												?>
												
												
												<?php if($this->session->userdata('lang')=='en')
												{?>
												<option value="<?php echo $area[$i]['URL_REWRITE_EN'];?>"><?php echo $area[$i]['AREA_NAME_EN']?></option>
												
												<?php }else 
												{?>
												<option value="<?php echo $area[$i]['URL_REWRITE_SP'];?>"><?php echo $area[$i]['AREA_NAME_SP']?></option>
												
												<?php 
												}?>
												
												
												<?php 	
											}
												?>
										</select> <select class="form-select style-2 selectbox" name="software">
										<option value=""><?php echo $this->lang->line('core.software'); ?></option>
											<?php for($i=0;$i<count($software);$i++)
											{
												?>
												
												
												<?php if($this->session->userdata('lang')=='en')
												{?>
												<option value="<?php echo $software[$i]['URL_REWRITE_EN'];?>"><?php echo $software[$i]['SOFTWARE_NAME_EN']?></option>
												
												<?php }else 
												{?>
												<option value="<?php echo $software[$i]['URL_REWRITE_SP'];?>"><?php echo $software[$i]['SOFTWARE_NAME_SP']?></option>
												
												<?php 
												}?>
												
												
												<?php 	
											}
												?>
										</select> 
										<button type="submit" class="form-submit btn btn-blue">
											<span>search now<i class="fa fa-search"></i></span>
										</button>
										<div class="clearfix"></div>
									</form>
								</div>
							</div>
						</div>
					</div>