



	<div id="wrapper-content">
		<!-- PAGE WRAPPER-->
		<div id="page-wrapper">
			<!-- MAIN CONTENT-->
			<div class="main-content">
				<!-- CONTENT-->
				<div class="content">
					<div class="section background-opacity page-title set-height-top">
						<div class="container">
							<div class="page-title-wrapper">
								<!--.page-title-content-->
								<h2 class="captions"><?php echo $this->lang->line('core.crative_course')?></h2>
								
							</div>
						</div>
					</div>
							
	<?php $this->load->view('frontend/courses/search');?> 
					
<?php if(isset($result)){?>
  <div class="section section-padding events-grid">
                    <div class="container">
                        <div class="group-title-index"><h4 class="top-title"><?php echo $this->lang->line('core.choose_course')?></h4>

                            <h2 class="center-title"><?php echo $this->lang->line('core.best_course')?></h2>

                            <div class="bottom-title"><i class="bottom-icon icon-icon-04"></i></div>
                        </div>
                        <div class="news-page-wrapper">
                            <div class="row">
                           <?php for($i=0;$i<count($result);$i++){?>
                          <?php // foreach ($result as $e) : ?>
       
      <?php 
      $in=strip_tags($shortContent[$i][0]['COURSE_INFO_CONT_VALUE']);
    //  echo mb_strimwidth($in, 0, 10, "");
      
      
      
      ?>
          	
        
                                <div class="col-md-4 col-sm-6">
                                    <div class="edugate-layout-3 news-gird">
                                        <div class="edugate-layout-3-wrapper"><span class="edugate-image">
                                      
                                        <?php if(isset($courseCover[$i][0]['COURSE_INFO_CONT_TYPE'])){?>
                                        
                                          <?php if($courseCover[$i][0]['COURSE_INFO_CONT_TYPE']=='FILEUPLOAD'){?>
                                        
                                       <img src="<?php echo base_url()?>uploads/course/<?php echo $courseCover[$i][0]['COURSE_INFO_CONT_VALUE'] ?>" alt=""
																class="img-responsive" />
																
																
																<?php }else 
																{
																	preg_match('/https?:\/\/(.+)?(wistia\.com|wi\.st)\/(medias|embed)\/(.+)?/', $courseCover[$i][0]['COURSE_INFO_CONT_VALUE'], $coverVideo);
																	
																	$cover="wistia_embed wistia_async_".$coverVideo[4]." popover=true popoverBorderWidth=2";
																	//echo $cover;
																?>
																
																<div class="wistia_responsive_padding"  style="padding:58.25% 0 0px 0;position:relative;">
	<div class="wistia_responsive_wrapper"  style="height:110%;left:0;position:absolute;top:0;width:100%;">
	<div class="<?php echo $cover?>" style="width:100%;height:100%;">&nbsp;</div>
	</div>
</div>
																
																<?php }?>
																<?php }
																else 
																{?>
																
															<img src="<?php echo base_url()?>uploads/course/noimage.png" alt=""
																			class="img-responsive" />
																
																	
															<?php 	}
																?>
																</span>

                                            <div class="edugate-content"><a href="<?php echo base_url()?>courses/<?php echo $courseName[$i]?>" class="title"><?php echo $result[$i]['COURSE_NAME']?></a>

                                                <div class="info">
                                                    <div class="author item"><a href="#">By <?php echo $result[$i]['CREATED_BY']?></a></div>
                                                    <div class="date-time item"><a href="#">
                                                      <?php echo date("jS M, Y", strtotime($result[$i]['CREATED_DATE']));  ?>
                                                    <?php 
                                                   // $originalDate = $e->CREATED_DATE;
                                                   // $datestring = "%M %j %Y";
                                                 //   $newDate = DateTime("d-m-Y", $originalDate);
                                                    //echo $newDate?></a></div>
                                                </div>
                                                <div class="info-more">
                                                    <div class="view item"><i class="fa fa-user"></i>

                                                        <p> <?php
                                                        if(isset($result[$i]['USER_TOT_ENROLL'])){
                                                        	echo $result[$i]['USER_TOT_ENROLL'];
                                                        }
                                                        else 
                                                        {
                                                        	echo "0";
                                                        }
                                                        
                                                        ?></p></div>
                                                    <div class="comment item"><i class="fa fa-comment"></i>

                                                        <p> <?php 
                                                        if(isset($result[$i]['USER_TOT_COMMENT'])){
                                                        	echo $result[$i]['USER_TOT_COMMENT'];
                                                        }
                                                        else 
                                                        {
                                                        	echo "0";
                                                        }
                                                        ?></p></div>
                                                </div>
                                                <div class="description"><?php echo mb_strimwidth($in, 0, 500, "");?></div>
                                                <a href="<?php echo base_url()?>courses/<?php echo $courseName[$i]?>" class="btn btn-green"><span><?php echo $this->lang->line('core.learn_now'); ?></span></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php // endforeach; ?>
                              <?php }?>
                                </div>
                           
          
                            
                            <div class="row">
                                <nav class="pagination col-md-12">
                                    <ul class="pagination__list">
                                         <?php echo  $pagination  ?>
                                    </ul>
                                </nav>
                            </div>
                             
                            
                            
                        </div>
                    </div>
                </div>
            
      <?php }
      else 
      {
      	echo "<center><h4>No found courses</h4></center>";
      }
      ?>
   
				</div>
			</div>
		</div>
		<!-- BUTTON BACK TO TOP-->
		<div id="back-top">
			<a href="#top"><i class="fa fa-angle-double-up"></i></a>
		</div>
	</div>	
	
	<?php $this->load->view('frontend/layouts/footerlang');?> <!-- footer view Load -->
	
	     