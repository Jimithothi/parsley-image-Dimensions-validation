	
	<?php //print_r($row['COURSE_ID']);
	//exit;
	
	?>
	<?php //print_r($this->session->all_userdata());
	//exit;
	?>
	
	
	
	
	
	
	<div id="wrapper-content">
		<!-- PAGE WRAPPER-->
		<div id="page-wrapper">
			<!-- MAIN CONTENT-->
			<div class="main-content">
				<!-- CONTENT-->
				<div class="content">
					<div class="section background-opacity page-title set-height-top">
						<div class="container">
							<div class="page-title-wrapper">
								<!--.page-title-content-->
								<h2 class="captions"><?php echo $this->lang->line('core.course_details')?></h2>
								
							</div>
						</div>
					</div>
						<?php $this->load->view('frontend/courses/search');?> 
					<div class="section section-padding courses-detail">
						<div class="container">
							<div class="courses-detail-wrapper">
								<div class="row">
									<div class="col-md-9 layout-left">
										<h1 class="course-title"><?php echo $row['COURSE_NAME']?></h1>
<br><Br>
										<ul role="tablist" class="nav nav-tabs edugate-tabs">
											<li role="presentation" class="active"><a href="#campus"
												data-toggle="tab" class="text"> Information & Syllabus</a></li>
											<li role="presentation"><a href="#education"
												data-toggle="tab" class="text"> FeedBack & Comments</a></li>

										</ul>
										
										
									
									
									</div>
									<div class="col-md-9 layout-left">
										<div class="tab-content courses-content">
										
											<div id="campus" role="tabpanel"
											class="tab-pane fade in active">
											
													
												<div class="course-des">
										
										 <div class="course-des-content">
                                 						
                                <!--   	<div class="wistia_responsive_padding" style="padding:56.25% 0 0px 0;position:relative;">
	<div class="wistia_responsive_wrapper" style="height:100%;left:0;position:absolute;top:0;width:100%;">
		<iframe src="//fast.wistia.net/embed/iframe/6kdlo3c61o?videoFoam=true" allowtransparency="true" frameborder="0" scrolling="no" class="wistia_embed" name="wistia_embed" allowfullscreen mozallowfullscreen webkitallowfullscreen oallowfullscreen msallowfullscreen width="98%" height="100%"></iframe>
	</div>
</div>  -->
                                      </div>
										
										
										
											<div class="course-des-title underline">Courses Info</div>
											<div class="course-des-content">
											
											<?php for ($i=0;$i<count($courseContent);$i++){
											
												if($courseContent[$i]['COURSE_INFO_CONT_TYPE']=='TEXT')
												{
													
													echo $courseContent[$i]['COURSE_INFO_CONT_VALUE'] ."<br><Br>";
													
												}
												elseif ($courseContent[$i]['COURSE_INFO_CONT_TYPE']=='MEDIA')
												{?>
												
												<?php preg_match('/https?:\/\/(.+)?(wistia\.com|wi\.st)\/(medias|embed)\/(.+)?/', $courseContent[$i]['COURSE_INFO_CONT_VALUE'], $matches);
			?>
												<div class="wistia_responsive_padding" style="padding:56.25% 0 0px 0;position:relative;">
	<div class="wistia_responsive_wrapper" style="height:100%;left:0;position:absolute;top:0;width:100%;">
		<iframe src="//fast.wistia.net/embed/iframe/<?php echo $matches[4]?>?videoFoam=true" allowtransparency="true" frameborder="0" scrolling="no" class="wistia_embed" name="wistia_embed" allowfullscreen mozallowfullscreen webkitallowfullscreen oallowfullscreen msallowfullscreen width="100%" height="100%"></iframe>
	</div>
</div><br><br> 
												<?php 
													
												}
												else 
												{?>
												<div width="100%">
													<img src="<?php echo base_url()?>uploads/course/<?php echo $courseContent[$i]['COURSE_INFO_CONT_VALUE']?>" alt=""
														class="img-responsive" /></div><br><br><?php 
												}
												
											}?>
											
												
											</div>
											
										</div>
										
										
										<?php if($enrollcourse==1){?>
										
												<div class="course-syllabus">
											<div class="course-syllabus-title underline">Courses
												syllabus</div>
											<div class="course-table">
												<div class="outer-container">
													<div class="inner-container">
														<div class="table-header">
															<table class="edu-table-responsive">
																<thead>
																	<tr class="heading-table">
																		<th class="col-1">title</th>
																		<th class="col-2">estimate time</th>
																		<th class="col-3">spent time</th>
																		<th class="col-4">status</th>
																	</tr>
																</thead>
															</table>
														</div>
														
														
														
														
														
														<div class="table-body">
															<table class="edu-table-responsive table-hover">
																<tbody>
																
																
																<?php 
																for($i=0;$i<count($units);$i++)
																{?>
																	<tr class="heading-content">
																	<td colspan="4" class="left heading-content"><a href="<?php echo base_url()?>courses/units/<?php echo $units[$i]['UNIT_ID']?>"><li class="bg-green mr25 fa fa-circle"></li>
																	<?php echo " ".$units[$i]['UNIT_NAME']?></a></td>
																	</tr>
																	
																	<?php 
																	for($j=0;$j<count($subunits[$i]);$j++)
																	{?>
																		<tr class="table-row">
																		<td class="left col-1"><i
																		class="bg-green mr25 fa fa-caret-right"></i><span>
																		<?php echo $subunits[$i][$j]['UNIT_INFO_CONT_VALUE']?></span></td>
																		<td class="col-2"><i class="w20 fa fa-clock-o"></i><span></span></td>
																		<td class="col-3"><i class="w20 fa fa-clock-o"></i><span></span></td>
																		<td class="green-color col-4"><i
																		class="w27 fa fa-check-square"></i><span></span></td>
																		</tr><?php 
																	}
																	?>
																<?php }
																	
																	?>
																
																
																	<!-- <tr class="heading-content">
																		<td colspan="4" class="left heading-content"><a href="unit.html">1.
																			Introduction</a></td>
																	</tr>
																	<tr class="table-row">
																		<td class="left col-1"><a href="unit.html"><i
																				class="bg-green mr25 fa fa-caret-right"></i><span>1.1
																					Presentation</span></a></td>
																		<td class="col-2"><i class="w20 fa fa-clock-o"></i><span>50:20</span></td>
																		<td class="col-3"><i class="w20 fa fa-clock-o"></i><span>40:20</span></td>
																		<td class="green-color col-4"><i
																			class="w27 fa fa-check-square"></i><span>Complete</span></td>
																	</tr>
																	<tr class="table-row">
																		<td class="left col-1"><a href="unit.html"><i
																				class="bg-green mr25 fa fa-caret-right"></i><span>1.2
																					influences </span></a></td>
																		<td class="col-2"><i class="w20 fa fa-clock-o"></i><span>50:20</span></td>
																		<td class="col-3"><i class="w20 fa fa-clock-o"></i><span>20:20</span></td>
																		<td class="bold-color col-4"><i
																			class="w27 fa fa-pencil-square-o"></i><span>Learning</span></td>
																	</tr>
																	 -->
																	<tr class="spacing-table">
																		<td colspan="4"></td>
																	</tr>
																	
																	
																</tbody>
															</table>
														</div>
														
														
														
														
													</div>
												</div>
											</div>
										</div>
											
											
											
											
											<?php }
											else 
											{
												?>
												
												<form action="<?php echo base_url()?>courses/enroll_course" method="post"  class="form-comment">
												
												<input type="hidden" name="courseName" value="<?php echo $courseURI?>">
												<input type="hidden" name="courseID" value="<?php echo $row['COURSE_ID']?>">
												 <button type="submit" class="btn btn-green btn-bold"><span>Enroll Course</span></button>
                                                
												</form>
												<?php 
											}
											
											?>
											
											
											
											</div>
											
											<div id="education" role="tabpanel" class="tab-pane fade">
											
											  <div class="news-comment">
                                            <div class="news-comment-title underline">FeedBack & Comments</div>
                                            <ul class="comment-list list-unstyled">
                                            
                                           
                                           
                                           
                                           <?php if(count($reviews)>0){?>
                                           
                                            <?php for($k=0;$k<count($reviews);$k++)
                                            {?>
                                            
                                            
                                             <li class="media">
                                                    <div class="list-item">
                                                        <div class="media-left">
                                                        <div class="media-image">
                                                        <?php if($reviews[$k]['USER_IMAGE']!='')
                                                        {
                                                        	?>
                                                        	<img src="<?php echo base_url()?>uploads/users/<?php echo $reviews[$k]['USER_IMAGE']?>" alt=""/>
                                                        	<?php 
                                            }
                                            else 
                                            {
                                            	?>
                                            	 <img src="<?php echo base_url()?>uploads/users/<?php echo DEFAULT_USER_IMAGE?>" alt="test"/>
                                            	<?php 
                                            }
                                            ?>
                                                        </div></div>
                                                        <div class="media-body">
                                                            <div class="pull-left">
                                                                <div class="info">
                                                                    <div class="reader item"><a><?php echo $reviews[$k]['NICK_NAME']?></a></div>
                                                                </div>
                                                            </div>
                                                            <div class="pull-right">
                                                                
                                                            </div>
                                                            <div class="clearfix"></div>
                                                            <div class="time"><?php echo $reviews[$k]['CREATED_DATE']?></div>
                                                            <div class="des"><p><?php echo $reviews[$k]['COMMENT']?></p></div>
                                                        </div>
                                                    </div>
                                                    
                                                </li>
                                            <?php }
                                            ?>
                                           
                                           <?php }
                                           else 
                                           {
                                           	 echo "<h4>no comments</h4>";
                                           }
                                           ?>
                                             
                                            </ul>
                                        </div>
                                      		  <div class="comment-write">
                                            
                                            <?php if($this->session->userdata('login_ID')==1){?>
                                            <div class="comment-write-title underline">Leave a comment</div>
                                            <form action="<?php echo base_url()?>courses/postreview" method="post"  class="form-comment">
                                                <div class="row">
                                                   
                                                    <input type="hidden" name='COURSE_ID' value="<?php echo $row['COURSE_ID']?>">
                                                    <input type="hidden" value="<?php print_r( $this->session->userdata('userId'));?>">
                                                    
                                                    
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                          <button type="button" class="btn-info"> <i class="fa fa-thumbs-o-down">NO</i></button>  <button class="btn-info"><i class="fa fa-thumbs-o-up">YES</i></button>
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="col-md-12">
                                                        <div class="contact-question form-group"><textarea name="comment" class="form-control form-input"></textarea></div>
                                                    </div>
                                                </div>
                                                <div class="contact-submit">
                                                    <button type="submit" class="btn btn-green btn-bold"><span>SUBMIT COMMENT</span></button>
                                                </div>
                                            </form>
                                            <?php }?>
                                        </div>
                                   
											</div>
											
										</div>
									</div>
									
									
									<!-- ####################################################################### -->
									
									
									
									<!-- ###################################################################### -->
									
									
									<div class="col-md-3 sidebar layout-right">
										<div class="row">
											<div class="clearfix"></div>
											
											
											
											<div class="popular-course-widget widget col-sm-6 col-md-12 col-xs-6 sd380">
												<div class="title-widget"><?php echo $this->lang->line('core.a_course_on')?></div>
												<div class="content-widget">
													<div class="media">
													<img src="assets/avatar/default-user-avatar.png" alt="" class="img-circle"  width="125" height="125"/>
																<h3><?php echo $row['CREATED_BY']?></h3>
																
														<div class="media-center"><b><?php echo $this->lang->line('core.course_details')?></b><hr>
														</div>
														<div class="media-right">
															<i class="fa fa-user"></i> <?php 
															if(isset($totalcourseUser)){
                                                        	echo $totalcourseUser;
                                                        }
                                                        else 
                                                        {
                                                        	echo "0";
                                                        }?> User<br>
															<i class="fa fa-film fa-fw"></i>
																<?php echo $row['COURSE_TOT_VIDEO']?> <?php echo $this->lang->line('core.video_lesson')?> <br>
																<i class="fa fa-thumbs-o-up fa-fw"></i>
																94%
																Positive reviews (<a class="link-secondary"><?php echo $countComment?></a>)
																															
																		<br>
																		
																		
																		<h6><b>
																<?php echo $this->lang->line('core.categories'); ?>
																</b>
																</h6>
																<span>
																
																<?php for($i=0;$i<count($courseCategory);$i++){?>
																
																<?php if($this->session->userdata('lang')=='en'){?>
																<a href="#"><h6><?php echo $courseCategory[$i][0]['CATEGORY_NAME_EN']?></h6></a>
																<?php }else{?>
																<a href="#"><h6><?php echo $courseCategory[$i][0]['CATEGORY_NAME_SP']?></h6></a>
																<?php }?>
																<?php }?>
																
																</span>
			
			
																<h6><b>
																<?php echo $this->lang->line('core.software'); ?></b>
																</h6>
																<span>
																
																<?php for($i=0;$i<count($courseSoftware);$i++){?>
																<?php if($this->session->userdata('lang')=='en'){?>
																<a href="#"><h6><?php echo $courseSoftware[$i][0]['SOFTWARE_NAME_EN']?></h6></a>
																<?php }else{?>
																<a href="#"><h6><?php echo $courseSoftware[$i][0]['SOFTWARE_NAME_SP']?></h6></a>
																<?php }?>
																<?php }?>
																
																
																</span>


															

														</div>
													</div>
													
												
												
												</div>
											</div>
											
											
											
											
											<div class="category-widget widget col-sm-6 col-md-12 col-xs-6 sd380">
												<div class="title-widget">categories</div>
												<div class="content-widget">
													<ul class="category-widget list-unstyled">
														<li><a href="#" class="link cat-item"><span
																class="pull-left">Web Design</span><span
																class="pull-right">125</span></a></li>
														<li><a href="#" class="link cat-item"><span
																class="pull-left">Wordpress Themes</span><span
																class="pull-right">97</span></a></li>
														<li><a href="#" class="link cat-item"><span
																class="pull-left">Photography</span><span
																class="pull-right">56</span></a></li>
														<li><a href="#" class="link cat-item"><span
																class="pull-left">Video</span><span class="pull-right">24</span></a></li>
														<li><a href="#" class="link cat-item"><span
																class="pull-left">Miscellaneous</span><span
																class="pull-right">13</span></a></li>
													</ul>
												</div>
											</div>
											<div class="clearfix"></div>
											<div
												class="tag-widget widget col-sm-6 col-md-12 col-xs-6 sd380">
												<div class="title-widget">tags</div>
												<div class="content-widget">
													<ul class="tag-widget list-unstyled">
														<li><a href="#" class="tag-item">Software</a></li>
														<li><a href="#" class="tag-item">Music</a></li>
														<li><a href="#" class="tag-item">Photography</a></li>
														<li><a href="#" class="tag-item">Communication</a></li>
														<li><a href="#" class="tag-item">Tutorial</a></li>
														<li><a href="#" class="tag-item">Biology</a></li>
														<li><a href="#" class="tag-item">Photoshop</a></li>
														<li><a href="#" class="tag-item">Economics</a></li>
														<li><a href="#" class="tag-item">Statistics</a></li>
													</ul>
												</div>
											</div>
											<div class="clearfix"></div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- BUTTON BACK TO TOP-->
		<div id="back-top">
			<a href="#top"><i class="fa fa-angle-double-up"></i></a>
		</div>
	</div>
	
	

	
<?php $this->load->view('frontend/layouts/footerlang');?> <!-- footer view Load -->

	