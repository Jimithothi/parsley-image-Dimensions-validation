  <?php usort($tableGrid, "SiteHelpers::_sort"); ?>
  <div class="page-content row">
    <!-- Page header -->
    <div class="page-header">
      <div class="page-title">
        <h3><a href="<?php echo site_url('dashboard') ?>">Dashboard</a> / 
        <?php echo $pageTitle ?> <?php //echo $pageTitle ?> <small><?php //echo $pageNote ?></small></h3>
      </div>

    

    </div>


  <div class="page-content-wrapper m-t">
   
  <div class="sbox" >
  <div class="sbox-title" >
    <h5><?php echo $pageNote ?><?php //echo $pageTitle ?> <small><?php //echo $pageNote ?></small></h5>
  </div>
  <div class="sbox-content" >
   <div class="toolbar-line ">    
    
    <a href="<?php echo site_url('admin/course/add') ?>" class="tips btn btn-sm btn-info"  title="<?php echo $this->lang->line('core.btn_new'); ?>">
    <i class="fa fa-plus"></i>&nbsp;<?php echo $this->lang->line('core.btn_new'); ?> </a>
      
    <a href="javascript:void(0);"  onclick="SximoDelete();" class="tips btn btn-sm btn-danger" title="<?php echo $this->lang->line('core.btn_remove'); ?>">
    <i class="fa fa-trash-o"></i>&nbsp;<?php echo $this->lang->line('core.btn_remove'); ?> </a>
  </div>
  <form action='<?php echo site_url('admin/course/destroy') ?>' class='form-horizontal' id ='SximoTable' method="post" >
   <div class="table-responsive">
    <table class="table table-striped ">
        <thead>
        <tr>
        <th> No </th>
        <th> <input type="checkbox" class="checkall" /></th>

        <?php foreach ($tableGrid as $k => $t) : ?>
          <?php if($t['view'] =='1'): ?>
            <th><?php echo $t['label'] ?></th>
          <?php endif; ?>
        <?php endforeach; ?>
        <th style="width:35px;"><?php echo $this->lang->line('core.btn_action'); ?></th>
        </tr>
        </thead>

        <tbody>
             
      <?php foreach ( $rowData as $i => $row ) : ?>
                <tr>
          <td width="50"> <?php echo ($i+1+$page) ?> </td>
          <td width="50"><input type="checkbox" class="ids" name="id[]" value="<?php echo $row->COURSE_ID ?>" />  </td>
         <?php foreach ( $tableGrid as $j => $field ) : ?>
           <?php if($field['view'] =='1'): ?>
           <td>
              <?php 
					 	if($field['field'] == 'INACTIVE') :
					 		if($row->$field['field'] =='1'):
					 			echo '<span class="label label-primary"> Active</span>';
					 		else:
					 			echo '<span class="label label-danger"> Inactive</span>';					 		
					 		endif;	


					 	elseif($field['attribute']['image']['active'] =='1'): ?>
							<?php echo SiteHelpers::showUploadedFile($row->$field['field'] , $field['attribute']['image']['path'] ) ?>
						<?php else: ?>
							<?php 
							$conn = (isset($field['conn']) ? $field['conn'] : array() ) ;
							echo SiteHelpers::gridDisplay($row->$field['field'] , $field['field'] , $conn ) ?>
						<?php endif; ?>
           </td>
           <?php endif; ?>
         <?php endforeach; ?>
         <td>
         
          <div class="btn-group">    
          
            <a  href="<?php echo site_url('admin/course/add/'.$row->COURSE_ID)?>"  class="tips "  title="edit"> <i class="btn btn-primary btn-xs dropdown-toggle fa fa-edit"></i>  <?php //echo $this->lang->line('core.btn_edit'); ?> </a> 
            
          </div>   
          
          
                
          
          </td>
                </tr>

            <?php endforeach; ?>

        </tbody>

    </table>
  </div>
  </form>
  
  <?php $this->load->view('footer');?>
  
  </div>
  </div><!-- /.sbox -->
  
  </div>
</div>

<script>
$(document).ready(function(){

  $('.do-quick-search').click(function(){
    $('#SximoTable').attr('action','<?php echo site_url("course/multisearch");?>');
    $('#SximoTable').submit();
  });
  
});  
</script>
