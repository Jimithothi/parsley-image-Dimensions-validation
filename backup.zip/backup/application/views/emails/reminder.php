<!DOCTYPE html>
<html lang="en-US">
	<head>
		<meta charset="utf-8">
	</head>
	<body>
		<h2>Password Reset </h2>

		<div>
			To reset your password, complete this form: 
<a target="_blank" href="<?php echo site_url('auth/edit?reset_password_token='.$token);?>">Click Here</a>

		</div>
	</body>
</html>