<div class="page-content row">
	<div class="page-header">
	  <div class="page-title">
		<h3> Dashboard <small>  </small></h3>
	  </div>

		 
		  
	</div>
	<div class="page-content-wrapper m-t">



		<section>

			<div class="row ">
				<div class="col-sm-6 col-md-6 b-r  p-sm ">
					<div class="small-box bg-green">
						<div class="inner">
							<h3><?php echo $total_users?></h3>

							<p>User Register</p>
						</div>
						<div class="icon">
							<i class="ion ion-person-add"></i>
						</div>
						<a href="<?php echo base_url()?>admin/users"
							class="small-box-footer"><h4>More info</h4> <i
							class="fa fa-arrow-circle-right"></i></a>
					</div>
				</div>


				<div class="col-sm-6 col-md-6 b-r  p-sm">

					<div class="small-box bg-yellow">
						<div class="inner">
							<h3><?php echo $total_courses?></h3>

							<p>Total Courses</p>
						</div>
						<div class="icon">
							<i class="ion ion-film-marker"></i>
						</div>

						<a href="<?php echo base_url()?>admin/course" class="small-box-footer"><h4>More info</h4> <i
							class="fa fa-arrow-circle-right"></i></a>
					</div>
				</div>

			</div>
		</section>















	</div>
</div>	

