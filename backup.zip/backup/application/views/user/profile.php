
  <div class="page-content row">
    <!-- Page header -->
    <div class="page-header">
      <div class="page-title">
        <h3>Profile</h3>
      </div>

      
	</div>  
		
	<div class="page-content-wrapper m-t">
		
	
	<div class="tab-content">
	 
	  	  
		<?php echo validation_errors(); ?>
	  	<form class="form-horizontal" action="<?php echo site_url('user/saveProfile') ;?>" method="post"  data-parsley-validate='true' enctype="multipart/form-data"> 
		  <div class="form-group">
			<label for="ipt" class=" control-label col-md-4"> Username </label>
			<div class="col-md-8">
			<input name="username" type="text" id="username" disabled="disabled" class="form-control input-sm" required  value="<?php echo $info->USER_NAME ;?>" />  
			 </div> 
		  </div>  
		
		</form>
		
		<form class="form-horizontal" action="<?php echo site_url('admin/user/savePassword') ;?>" method="post"  data-parsley-validate='true' >  
		  
		  <div class="form-group">
			<label for="ipt" class=" control-label col-md-4">Password</label>
			<div class="col-md-8">
			<input name="password" type="password" id="password" class="form-control input-sm" value="" required/> 
			 </div> 
		  </div>  
		  
		  <div class="form-group">
			<label for="ipt" class=" control-label col-md-4">Confirm Password </label>
			<div class="col-md-8">
			<input name="password_confirmation" type="password" id="password_confirmation" class="form-control input-sm" value="" required/>  
			 </div> 
		  </div>    
		 
	
		
		  <div class="form-group">
			<label for="ipt" class=" control-label col-md-4"> </label>
			<div class="col-md-8">
				<button class="btn btn-primary btn-sm" type="submit">Save </button>
			 </div> 
		  </div>   
		</form>
	
  
  


</div>
</div>
 
 </div>