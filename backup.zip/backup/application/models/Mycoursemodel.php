<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * @package     CodeIgniter
 * @author      Ikraftsolutions
 * @copyright   Copyright (c) Ikraftsolutions (http://ikraftsolutions.com)
 * @version 1.0
 */

class Mycoursemodel extends CI_Model
{
	
	function userEnrollcourse($USER_ID)
	{
		$this->db->select('COURSE_ID');
		$this->db->from('user_course_enroll');
		$this->db->where('USER_ID',$USER_ID);
		$query = $this->db->get();
		
		return $query->result_array();
		
		
	}
	
	function CourseName($COURSE_ID)
	{
		$this->db->select('COURSE_NAME,COURSE_ID');
		$this->db->from('course_master');
		$this->db->where('COURSE_ID',$COURSE_ID);
		$query = $this->db->get();
		
		return $query->row_array();
		
	}
	
	function courseCover($COURSE_ID)
	{
		$this->db->select('COURSE_INFO_CONT_VALUE,COURSE_INFO_CONT_TYPE');
		$this->db->from('course_information');
		$this->db->where('course_information.COURSE_ID',$COURSE_ID);
	
		$where = '(COURSE_INFO_CONT_TYPE="FILEUPLOAD" or COURSE_INFO_CONT_TYPE = "MEDIA")';
		$this->db->where($where);

		$this->db->limit(1);
		$query = $this->db->get();
	
		return $query->result_array();
	
	}
	
	
	function getLatestcoursecontent($id)
	{
		$this->db->select("*");
		$this->db->from('course_information');
		$this->db->where('course_information.COURSE_ID',$id);
		$this->db->where("course_information.COURSE_INFO_CONT_TYPE","TEXT");
		
		$this->db->limit(1);
		$query = $this->db->get();
	
		if ($query->num_rows() > 0) {
			return $query->result_array();
		}
	}

}




?>