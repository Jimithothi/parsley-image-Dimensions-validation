<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * @package     CodeIgniter
 * @author      Ikraftsolutions
 * @copyright   Copyright (c) Ikraftsolutions (http://ikraftsolutions.com)
 * @version 1.0
 */

class Groupsmodel extends SB_Model 
{
	/*
	public $table = 'role_master';
	public $primaryKey = 'ROLE_ID';

	public function __construct() {
		parent::__construct();
		
	}

	public static function querySelect(  ){
		
		
		return "   SELECT role_master.* FROM role_master   ";
	}
	public static function queryWhere(  ){
		
		return "  WHERE role_master.ROLE_ID IS NOT NULL   ";
	}
	
	public static function queryGroup(){
		return "   ";
	}*/
	
}

?>
