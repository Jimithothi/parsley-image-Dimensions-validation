<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * @package     CodeIgniter
 * @author      Ikraftsolutions
 * @copyright   Copyright (c) Ikraftsolutions (http://ikraftsolutions.com)
 * @version 1.0
 */

class Coursesmodel extends CI_Model
{
	public $table= 'course_master';
	public $primaryKey = 'COURSE_ID';
	public $jointable ='course_information';
	public $userTable='user_master';
	public $unittable="course_unit";
	
	public function __construct() {
		parent::__construct();
	
	}
	
	public function record_count() {
		return $this->db->count_all("course_master");
	}
	
	public function record_count_list($where) {
		
		$this->db->select('COURSE_ID');
		$this->db->from('course_area_category_mapping');
		
		
		if($where=='')
		{
				
		}
		else
		{
			$this->db->where($where);
		}
		
		
		
		$query = $this->db->get();
		
		return count($query->result_array());
		
		
		
		
		//return $this->db->count_all("course_master",$where);
	}
	
	
	function getcourses($args)
	{
		
		extract( array_merge( array(
				'page' 		=> '0' ,
				'limit'  	=> '0' ,
		
		
		), $args ));
		
		if($page>=$limit)
		{
			$offset = $page ;
		}
		else
		{
			$offset = ($page-1);
		}
		
		
		
		$this->db->select("$this->table.*");
		$this->db->from($this->table);
		$this->db->limit($limit,$offset);
		
		$this->db->where("$this->table.INACTIVE","1");
		$this->db->order_by("$this->table.CREATED_DATE","desc");
		
		$query = $this->db->get();
		
		if ($query->num_rows() > 0) {
			return $query->result_array();
		}
	}
	
	
	function get_popular_courses($args)
	{
		
		extract( array_merge( array(
				'page' 		=> '0' ,
				'limit'  	=> '0' ,
		
		
		), $args ));
		
		if($page>=$limit)
		{
			$offset = $page ;
		}
		else
		{
			$offset = ($page-1);
		}
		
		
		
		$this->db->select("$this->table.*");
		$this->db->from($this->table);
		$this->db->limit($limit,$offset);
		$this->db->where("$this->table.INACTIVE","1");
		$this->db->order_by("$this->table.USER_TOT_ENROLL","desc");
	
		$query = $this->db->get();
	
		if ($query->num_rows() > 0) {
			return $query->result();
		}
	}
	
	function get_highest_rated_courses($args)
	{
		
		extract( array_merge( array(
				'page' 		=> '0' ,
				'limit'  	=> '0' ,
		
		
		), $args ));
		
		if($page>=$limit)
		{
			$offset = $page ;
		}
		else
		{
			$offset = ($page-1);
		}
		
		
		$this->db->select("$this->table.*");
		$this->db->from($this->table);
		$this->db->limit($limit,$offset);
		$this->db->where("$this->table.INACTIVE","1");
		$this->db->order_by("$this->table.USER_TOT_COMMENT","desc");
	
		$query = $this->db->get();
	
		if ($query->num_rows() > 0) {
			return $query->result();
		}
	}
	
	function get_recent_courses($args)
	{
		
		extract( array_merge( array(
				'page' 		=> '0' ,
				'limit'  	=> '0' ,
				
		
		), $args ));

		if($page>=$limit)
		{
			$offset = $page ;
		}
		else
		{
			$offset = ($page-1);
		}
		

		$this->db->select("$this->table.*");
		$this->db->from($this->table);
		$this->db->limit($limit,$offset);
		$this->db->where("$this->table.INACTIVE","1");
		$this->db->order_by("$this->table.CREATED_DATE","desc");
	
		$query = $this->db->get();

		if ($query->num_rows() > 0) {
			return $query->result();
			
			
		}
	}
	
	
	
	function getLatestcourse()
	{
		$this->db->select("$this->table.*");
		$this->db->from($this->table);
		
		$this->db->where("$this->table.INACTIVE","1");
		$this->db->order_by("$this->table.CREATED_DATE","desc");
		$this->db->limit(6);
		$query = $this->db->get();
		
		if ($query->num_rows() > 0) {
			return $query->result_array();
		}
	}
	
	function getLatestcoursecontent($id)
	{
		$this->db->select("$this->jointable.*");
		$this->db->from($this->jointable);
		$this->db->where("$this->jointable.$this->primaryKey",$id);
		$this->db->where("$this->jointable.COURSE_INFO_CONT_TYPE","TEXT");
		//$this->db->order_by("$this->table.CREATED_DATE","desc");
		$this->db->limit(1);
		$query = $this->db->get();
		
		if ($query->num_rows() > 0) {
			return $query->result_array();
		}
	}
	

	function getUser($login=array())
	{
		$this->db->select('*');
		$this->db->from($this -> userTable);
		$this->db->where($login);
		$query = $this->db->get();
		return $query->result_array();
	}
	
	function getcourse($id)
	{
		$this->db->select("*");
		$this->db->from($this->table);
		$this->db->where($this->table.'.COURSE_NAME',$id);
		$query = $this->db->get();
		
		
		return $query->row_array();
		
	}
	
	function getCoursecontent($id)
	{
		$this->db->select('*');
		$this->db->from($this->jointable);
		$this->db->where($this->jointable.'.'.$this->primaryKey,$id);
		$query = $this->db->get();
	
		return $query->result_array();
	}
	
	function getUnits($id)
	{
		$this->db->select('*');
		$this->db->from($this->unittable);
		$this->db->where($this->unittable.'.'.$this->primaryKey,$id);
		$query = $this->db->get();
	
		return $query->result_array();
	}
	
	function subunit($id)
	{
		$this->db->select('*');
		$this->db->from('course_unit_information');
		$this->db->where('course_unit_information.UNIT_ID',$id);
		$this->db->where('course_unit_information.UNIT_INFO_CONT_TYPE','TEXTBOX');
		$this->db->where('course_unit_information.IS_SUBUNIT','1');
		$query = $this->db->get();
	
		return $query->result_array();
	}
	
	function courseReview($id)
	{
		$this->db->select('*');
		$this->db->from('course_review');
		$this->db->join('user_master', 'user_master.USER_ID = course_review.USER_ID');
		$this->db->where('course_review.'.$this->primaryKey,$id);
		$this->db->where('course_review.INACTIVE','1');
		$this->db->order_by('course_review.CREATED_DATE');
		
		$query = $this->db->get();
		
		return $query->result_array();
	}
	
	function countComment($id)
	{
		$this->db->select('*');
		$this->db->from('course_review');
		
		$this->db->where('course_review.'.$this->primaryKey,$id);
		$query = $this->db->get();
		
		return $query->num_rows();
	}
	
	function totaluser($id)
	{
		$this->db->select('*');
		$this->db->from('user_course_enroll');
		$this->db->where('user_course_enroll.'.$this->primaryKey,$id);
		$query = $this->db->get();
		
		return $query->num_rows();
	}
	
	function courseCount($id)
	{
		$this->db->select('*');
		$this->db->from($this->table);
		$this->db->where($this->primaryKey,$id);
		$query = $this->db->get();
	
		return $query->result_array();
	}
	
	
	function courseMapping($mapingTable,$id,$type)
	{
		$this->db->select('*');
		$this->db->from($mapingTable);
		$this->db->where($type,$id);		
		$query = $this->db->get();
		
		return $query->result_array();
		
	}
	
	function courseCover($id)
	{
		$this->db->select('COURSE_INFO_CONT_VALUE,COURSE_INFO_CONT_TYPE');
		$this->db->from($this->jointable);
		$this->db->where($this->jointable.'.'.$this->primaryKey,$id);
		
		$where = '(COURSE_INFO_CONT_TYPE="FILEUPLOAD" or COURSE_INFO_CONT_TYPE = "MEDIA")';
       	$this->db->where($where);
       
       
		//$this->db->where('COURSE_INFO_CONT_TYPE','FILEUPLOAD');
		//$this->db->or_where('COURSE_INFO_CONT_TYPE','MEDIA');
		$this->db->limit(1);
		$query = $this->db->get();
		
		return $query->result_array();
		
	}
	
	function Search($serachtable,$where)
	{
		$this->db->select('*');
		$this->db->from($serachtable);
		$this->db->where($where);
		$query = $this->db->get();
		
		return $query->result_array();
	}
	
	
	
	function searchCourse($where)
	{
		$this->db->select('COURSE_ID');
		$this->db->from('course_area_category_mapping');
		
		
		if($where=='')
		{
			
		}
		else 
		{
			$this->db->where($where);
		}
		
		
		
		$query = $this->db->get();
		
		return $query->result_array();
	}
	
	function searchCourselist($where,$args)
	{
		$this->db->select('COURSE_ID');
		$this->db->from('course_area_category_mapping');
	
		extract( array_merge( array(
				'page' 		=> '0' ,
				'limit'  	=> '0' ,
	
	
		), $args ));
	
		if($page>=$limit)
		{
			$offset = $page ;
		}
		else
		{
			$offset = ($page-1);
		}
	
		$this->db->limit($limit,$offset);
	
		if($where=='')
		{
				
		}
		else
		{
			$this->db->where($where);
		}
	
	
	
		$query = $this->db->get();
	
		return $query->result();
	}
	
	function recommended_courses_id($course_id)
	{
		$this->db->select('COURSE_ID');
		$this->db->from($this->table);
		$this->db->limit(3);
		$where="COURSE_ID<>$course_id";
		$this->db->where($where);
		$query = $this->db->get();
	
		return $query->result_array();
	
	}
	
	function recommended_courses($courseId)
	{
		$this->db->select("$this->table.*,$this->jointable.COURSE_INFO_CONT_VALUE,$this->jointable.COURSE_INFO_CONT_TYPE");
		$this->db->from($this->table);
		$this->db->join($this->jointable, "$this->jointable.$this->primaryKey = $this->table.$this->primaryKey");
		$this->db->where("$this->table.$this->primaryKey",$courseId);
		$where = "($this->jointable.COURSE_INFO_CONT_TYPE='FILEUPLOAD' or $this->jointable.COURSE_INFO_CONT_TYPE = 'MEDIA')";
		$this->db->limit(1);
		$this->db->where($where);
		
		$query = $this->db->get();
		
		return $query->result_array();
		
	}
	
}