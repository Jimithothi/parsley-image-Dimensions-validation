<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * @package     CodeIgniter
 * @author      Ikraftsolutions
 * @copyright   Copyright (c) Ikraftsolutions (http://ikraftsolutions.com)
 * @version 1.0
 */

class Usersmodel extends SB_Model 
{

	public $table = 'user_master';
	public $primaryKey = 'USER_ID';

	public function __construct() {
		parent::__construct();
		
	}

	public static function querySelect(  ){
		
		
		return "   SELECT user_master.* FROM user_master   ";
	}
	public static function queryWhere(  ){
		
		return "  WHERE user_master.ROLE_ID  <> 1   ";
	}
	
	public static function queryGroup(){
		return "   ";
	}
	function getUser($login=array())
	{
		$this->db->select('*');
		$this->db->from($this -> table);
		$this->db->where($login);
		$query = $this->db->get();
	
		return $query->result_array();
	}
}

?>
