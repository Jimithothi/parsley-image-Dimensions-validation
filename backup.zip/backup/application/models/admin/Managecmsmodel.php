<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * @package     CodeIgniter
 * @author      Ikraftsolutions
 * @copyright   Copyright (c) Ikraftsolutions (http://ikraftsolutions.com)
 * @version 1.0
 */

class Managecmsmodel extends SB_Model 
{

	public $table = 'cms';
	public $primaryKey = 'CMS_ID';

	public function __construct() {
		parent::__construct();
		
	}

	public static function querySelect(  ){
		
		
		return "   SELECT cms.* FROM cms   ";
	}
	public static function queryWhere(  ){
		
		return "  WHERE cms.CMS_ID IS NOT NULL   ";
	}
	
	public static function queryGroup(){
		return "   ";
	}
	
}

?>
