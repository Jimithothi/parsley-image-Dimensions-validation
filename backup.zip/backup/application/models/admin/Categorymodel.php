<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * @package     CodeIgniter
 * @author      Ikraftsolutions
 * @copyright   Copyright (c) Ikraftsolutions (http://ikraftsolutions.com)
 * @version 1.0
 */

class Categorymodel extends SB_Model 
{

	public $table = 'category_master';
	public $primaryKey = 'CATEGORY_ID';

	public function __construct() {
		parent::__construct();
		
	}

	public static function querySelect(  ){
		
		
		return "   SELECT category_master.* FROM category_master   ";
	}
	public static function queryWhere(  ){
		
		return "  WHERE category_master.CATEGORY_ID IS NOT NULL   ";
	}
	
	public static function queryGroup(){
		return "   ";
	}
	
}

?>
