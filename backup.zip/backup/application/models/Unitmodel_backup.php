<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * @package     CodeIgniter
 * @author      Ikraftsolutions
 * @copyright   Copyright (c) Ikraftsolutions (http://ikraftsolutions.com)
 * @version 1.0
 */

class Unitmodel extends SB_Model 
{

	public $table = 'course_unit';
	public $primaryKey = 'UNIT_ID';

	public function __construct() {
		parent::__construct();
		
	}

	public static function querySelect(  ){
		
		
		return "   SELECT course_unit.* FROM course_unit   ";
	}
	public static function queryWhere(  ){
		
		return "  WHERE course_unit.UNIT_ID IS NOT NULL   ";
	}
	
	public static function queryGroup(){
		return "   ";
	}
	
}

?>
