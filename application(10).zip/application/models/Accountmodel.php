<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * @package     CodeIgniter
 * @author      Ikraftsolutions
 * @copyright   Copyright (c) Ikraftsolutions (http://ikraftsolutions.com)
 * @version 1.0
 */

class Accountmodel extends SB_Model 
{

	public $table = 'user_master';
	public $primaryKey = 'USER_ID';

	public function __construct() {
		parent::__construct();
		
	}

	public function getuserRow( $id )
	{
		 
		
		$this->db->select('*');
		$this->db->from($this->table);
		$this->db->where($this->primaryKey,$id);
		$query = $this->db->get();
	
		return $query->row_array();
		
	}
	
}

?>
