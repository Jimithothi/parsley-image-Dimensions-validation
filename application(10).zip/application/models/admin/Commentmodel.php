<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Commentmodel extends SB_Model 
{

	public $table = 'course_review';
	public $primaryKey = 'ID';

	public function __construct() {
		parent::__construct();
		
	}

	public static function querySelect(  ){
		
		
		return "   SELECT course_review.* FROM course_review   ";
	}
	public static function queryWhere(  ){
		
		return "  WHERE course_review.ID IS NOT NULL   ";
	}
	
	public static function queryGroup(){
		return "   ";
	}
	
	public function getRowscomments( $args )
	{
		$table = $this->table;
		$key = $this->primaryKey;
	
		extract( array_merge( array(
				'page' 		=> '0' ,
				'limit'  	=> '0' ,
				'sort' 		=> '' ,
				'order' 	=> '' ,
				'params' 	=> '' ,
				'COURSE_ID'	=> ''
		), $args ));
	
		if($page>=$limit)
		{
			$offset = $page ;
		}
		else
		{
			$offset = ($page-1);
		}
	
		$limitConditional = ($page !=0 && $limit !=0) ? "LIMIT  $offset , $limit" : '';
		$orderConditional = ($sort !='' && $order !='') ?  " ORDER BY {$sort} {$order} " : '';
	
		$table = $this->table;
	
		$where=$this->queryWhere().' AND '.$table.'.COURSE_ID='.$COURSE_ID;
		$rows = array();
		$query = $this->db->query( $this->querySelect() . $where. "
		{$params} ". $this->queryGroup() ." {$orderConditional}  {$limitConditional} ");
		$result = $query->result();
		$query->free_result();
	
		if($key =='' ) { $key ='*'; } else { $key = $table.".".$key ; }
		$counter_select = preg_replace( '/[\s]*SELECT(.*)FROM/Usi', 'SELECT count('.$key.') as total FROM', $this->querySelect() );
		//echo 	$counter_select; exit;
		$query = $this->db->query( $counter_select . $where." {$params} ". $this->queryGroup());
		$res = $query->result();
		$total = $res[0]->total;
		$query->free_result();
	
		return $results = array('rows'=> $result , 'total' => $total);
	
	
	}
	
}

?>
