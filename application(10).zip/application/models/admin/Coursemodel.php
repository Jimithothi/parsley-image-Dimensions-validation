<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * @package     CodeIgniter
 * @author      Ikraftsolutions
 * @copyright   Copyright (c) Ikraftsolutions (http://ikraftsolutions.com)
 * @version 1.0
 */

class Coursemodel extends SB_Model 
{

	public $table = 'course_master';
	public $primaryKey = 'COURSE_ID';
	public $tableInfo='course_information';

	public function __construct() {
		parent::__construct();
		
	}

	public static function querySelect(  ){
		
		
		return "   SELECT course_master.* FROM course_master   ";
	}
	public static function queryWhere(  ){
		
		return "  WHERE course_master.COURSE_ID IS NOT NULL   ";
	}
	
	public static function queryGroup(){
		return "   ";
	}
	
	/**
	 * course mapping delete
	 * @param string $table
	 * @param string $key
	 * @param int $id
	 */
	
	function course_mapping_delete($table,$key,$id)
	{
		for($i=0;$i<count($id);$i++)
		{
			$csql="delete from ".$table." where ".$key."=".$id[$i];
			$this->db->query($csql);
		}
	}
	
	/**
	 * when course edit after update that time this method used
	 * @param string $table
	 * @param string $key
	 * @param int $id
	 */
	
	function course_information_delete($table,$key,$id)
	{
		$this->db->where($key, $id);
		$this->db->delete($table);
	}
	
	/**
	 * when course delete that time his information also delete that time this method used
	 * @param string $table
	 * @param string $key
	 * @param int $id
	 */
	
	function course_delete($table,$key,$id)
	{
		for($i=0;$i<count($id);$i++)
		{
			$query= $this->db->query("select UNIT_ID from course_unit where COURSE_ID=$id[$i]");
	
			$result = $query->result_array();
	
			for($k=0;$k<count($result);$k++)
			{
				
				$this->unitImageDelete($result[$k]['UNIT_ID']);
				$sql="delete from course_unit_information where UNIT_ID=".$result[$k]['UNIT_ID'];
				$this->db->query($sql);
				$usql="delete from course_unit where UNIT_ID=".$result[$k]['UNIT_ID'];
				$this->db->query($usql);
			}
			$csql="delete from ".$table." where ".$key."=".$id[$i];
			$this->db->query($csql);
		}
	}
	
	function reviewDelete($table,$id)
	{
		//echo count($id);
		for($i=0;$i<count($id);$i++)
		{
			$csql="delete from ".$table." where ".$this->primaryKey."=".$id[$i];
			$this->db->query($csql);
		}
		
		//exit;
	}
	
	function courseImageDelete($id)
	{
		for($i=0;$i<count($id);$i++)
		{
			$query= $this->db->query("select COURSE_INFO_CONT_VALUE from $this->tableInfo where COURSE_ID=$id[$i] and COURSE_INFO_CONT_TYPE='FILEUPLOAD'");
			
			$result = $query->result_array();
			
			for($j=0;$j<count($result);$j++)
			{
				if(file_exists('uploads/course/'.$result[$j]['COURSE_INFO_CONT_VALUE']))
				{
					//echo "yes";
					unlink( FCPATH .'uploads/course/'.$result[$j]['COURSE_INFO_CONT_VALUE']);
				}
			}
		}
		
	}
	
	function unitImageDelete($id)
	{
		
			$query= $this->db->query("select UNIT_INFO_CONT_VALUE from course_unit_information where UNIT_ID=$id and UNIT_INFO_CONT_TYPE='FILEUPLOAD'");
				
			$result = $query->result_array();
				
			for($j=0;$j<count($result);$j++)
			{
				if(file_exists('uploads/course/unit/'.$result[$j]['UNIT_INFO_CONT_VALUE']))
				{
					//echo "yes";
					unlink( FCPATH .'uploads/course/unit/'.$result[$j]['UNIT_INFO_CONT_VALUE']);
				}
			}
	}
	
}

?>
