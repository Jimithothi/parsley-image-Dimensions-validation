<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * @package     CodeIgniter
 * @author      Ikraftsolutions
 * @copyright   Copyright (c) Ikraftsolutions (http://ikraftsolutions.com)
 * @version 1.0
 */

class Homemodel extends CI_Model
{
	
	

	public function __construct() {
		parent::__construct();

	}

	







}




?>