<div class="page-content row">
    <!-- Page header -->
<div class="page-header">
  <div class="page-title">
  <h3> <a href="<?php echo site_url('dashboard') ?>"> Dashboard</a> / 
    <a href="<?php echo site_url('admin/comment') ?>"><?php echo $pageTitle ?></a> / 
    <?php echo "Form"?><?php //echo $pageTitle ?> <small><?php //echo $pageNote ?></small></h3>
  </div>
       
</div>
 
   <div class="page-content-wrapper m-t">  
   
   
    <ul class="nav nav-tabs" style="margin-bottom:10px;">
			<li><a href="<?php echo base_url()?>course/add/<?php echo $this->session->userdata('COURSE_ID')?>"><?php echo "Course Info"; ?> </a></li>
			<li><a href="<?php echo base_url()?>unit/index/<?php echo $row['COURSE_ID']?>"><?php echo "Unit"; ?> </a></li>
					<li class="active" ><a
				href="<?php echo base_url()?>admin/comment/index/<?php echo $this->session->userdata('COURSE_ID')?>"><?php echo "Comments"; ?> </a></li>
		
			
				</ul>  
      
    <div class="sbox" >
    <div class="sbox-title" >
      <h5>Edit Comments<?php //echo $pageTitle ?> <small><?php //echo $pageNote ?></small></h5>
    </div>
    <div class="sbox-content" >

      
     <form action="<?php echo site_url('admin/comment/save/'.$row['ID']); ?>" class='form-horizontal'  parsley-validate='true' novalidate='true' method="post" enctype="multipart/form-data" > 


<div class="col-md-12">
						<fieldset>
									
								  <div class="form-group hidethis " style="display:none;">
									<label for="ID" class=" control-label col-md-4 text-left"> ID </label>
									<div class="col-md-8">
									  <input type='text' class='form-control' placeholder='' value='<?php echo $row['ID'];?>' name='ID'   /> <br />
									  <i> <small></small></i>
									 </div> 
								  </div> 					
								  <div class="form-group  " >
									<label for="COMMENT" class=" control-label col-md-4 text-left"> COMMENT </label>
									<div class="col-md-8">
									  <textarea name='COMMENT' rows='2' id='COMMENT' class='form-control '  
				           ><?php echo $row['COMMENT'] ;?></textarea> <br />
									  <i> <small></small></i>
									 </div> 
								  </div> 					
								  <div class="form-group  " >
									<label for="INACTIVE" class=" control-label col-md-4 text-left"> INACTIVE </label>
									<div class="col-md-8">
									  
					<label class='radio radio-inline'>
					<input type='radio' name='INACTIVE' value ='1'  <?php if($row['INACTIVE'] == '1') echo 'checked="checked"';?> > Active </label>
					<label class='radio radio-inline'>
					<input type='radio' name='INACTIVE' value ='0'  <?php if($row['INACTIVE'] == '0') echo 'checked="checked"';?> > Inactive </label> <br />
									  <i> <small></small></i>
									 </div> 
								  </div> </fieldset>
			</div>
			
			
    
      <div style="clear:both"></div>  
        
     <div class="toolbar-line text-center">    
      <button type="submit" name="submit" class="btn btn-info btn-sm"><i class="icon-checkmark-circle2"></i> Update</button>
       <a href="<?php echo site_url('admin/comment');?>" class="btn btn-sm btn-warning"><i class="icon-cancel-circle2 "></i> <?php echo $this->lang->line('core.btn_cancel'); ?> </a>
     </div>
            
    </form>
    
    </div>
    </div>

  </div>  
</div>  
</div>
       
<script type="text/javascript">
$(document).ready(function() { 
    
});
</script>     