<div class="page-content row">
	<!-- Page header -->
	<div class="page-header">
		<div class="page-title">
			<h3>
				<a href="<?php echo site_url('dashboard') ?>"> Dashboard</a> / <a
					href="<?php echo site_url('admin/course') ?>"><?php echo $pageTitle ?></a> 
    <?php //echo $pageTitle ?> <small><?php //echo $pageNote ?></small>
			</h3>
		</div>

	</div>

	<div class="page-content-wrapper m-t">  
    <?php if($this->session->userdata('COURSE_ID')!=''){ ?>	
   <ul class="nav nav-tabs" style="margin-bottom: 10px;">


			<li class="active"><a><?php echo "Course Info"; ?> </a></li>
			<li><a
				href="<?php echo base_url()?>unit/index/<?php echo $this->session->userdata('COURSE_ID')?>"><?php echo "Unit"; ?> </a></li>
				<li><a
				href="<?php echo base_url()?>admin/comment/index/<?php echo $this->session->userdata('COURSE_ID')?>"><?php echo "Comments"; ?> </a></li>
		</ul> 
		<?php }?>   
    <div class="sbox">
			<div class="sbox-title">
				<h5><?php echo $addForm;?><?php //echo $pageTitle ?> <small><?php //echo $pageNote ?></small>
				</h5>
			</div>
			<div class="sbox-content">


				<form
					action="<?php echo site_url('admin/course/save/'.$row['COURSE_ID']); ?>"
					class='form-horizontal' data-parsley-validate='true'
					method="post" enctype="multipart/form-data" id="validationForm">

					<!-- Hidden field for counters -->
					<input type="hidden" value="0" id='hidden'>
					<p></p>
					<!-- End Hidden field for counters -->
					<div class="col-md-11">
						<fieldset>

							<div class="form-group hidethis " style="display: none;">
								<label for="COURSE ID" class=" control-label col-md-4 text-left">
									COURSE ID </label>
								<div class="col-md-8">
									<input type='text' class='form-control' placeholder=''
										value='<?php echo $row['COURSE_ID'];?>' name='COURSE_ID' /> <br />
									<i> <small></small></i>
								</div>
							</div>
							<div class="form-group  ">
								<label for="Name" class=" control-label col-md-4 text-left">
									Name <span class="asterix"> * </span>
								</label>
								<div class="col-md-8">
									<input type='text' class='form-control' placeholder=''
										value='<?php echo $row['COURSE_NAME'];?>' name='COURSE_NAME'
										data-parsley-pattern="/^[A-z0-9 \u00C0-\u00ff]+$/" data-parsley-pattern-message="we are not allow special character" required /> <br /> <i> <small></small></i>
								</div>
							</div>


							<div class="form-group  ">
								<label for="Name" class=" control-label col-md-4 text-left">
									Category <span class="asterix"> </span>
								</label>
								<div class="col-md-8">
									
									<?php if(count($checkCategory)>0){?>
									<?php
										
for($i = 0; $i < count ( $category ); $i ++) {
											
											$check = SiteHelpers::getCheckbox ( $category [$i] ['CATEGORY_ID'], $checkCategory );
											
											?>
										
										
										<input type="checkbox" name="category[]"
										value="<?php echo $category[$i]['CATEGORY_ID']?>"
										<?php echo $check?> data-parsley-mincheck="1" required>  &nbsp;&nbsp;<?php echo $category[$i]['CATEGORY_NAME_EN']?> <br>
																					<?php
										}
									} 

									else {
										for($i = 0; $i < count ( $category ); $i ++) {
											?>
											<input type="checkbox" name="category[]"
										value="<?php echo $category[$i]['CATEGORY_ID']?>" data-parsley-mincheck="1" required>  &nbsp;&nbsp;<?php echo $category[$i]['CATEGORY_NAME_EN']?> <br>
											<?php
										}
									}
									?>
									  <i> <small></small></i>
								</div>
							</div>



							<div class="form-group  ">
								<label for="Name" class=" control-label col-md-4 text-left">
									Software <span class="asterix"> </span>
								</label>
								<div class="col-md-8">
									
									<?php if(count($checkSoftware)>0){?>
									<?php
										
for($i = 0; $i < count ( $software ); $i ++) {
											// echo $category[$i]['CATEGORY_ID'];
											
											$check = SiteHelpers::getCheckbox ( $software [$i] ['SOFTWARE_ID'], $checkSoftware );
											// echo $check;
											?>
										<input type="checkbox" name="software[]"
										value="<?php echo $software[$i]['SOFTWARE_ID']?>"
										<?php echo $check?> data-parsley-mincheck="1" required>  &nbsp;&nbsp;<?php echo $software[$i]['SOFTWARE_NAME_EN']?> <br>
																					<?php
										}
									} else {
										for($i = 0; $i < count ( $software ); $i ++) {
											?>
											<input type="checkbox" name="software[]"
										value="<?php echo $software[$i]['SOFTWARE_ID']?>" data-parsley-mincheck="1" required>  &nbsp;&nbsp;<?php echo $software[$i]['SOFTWARE_NAME_EN']?> <br>
											<?php
										}
									}
									?>
									  <i> <small></small></i>
								</div>
							</div>
							<div class="form-group  ">
								<label for="Name" class=" control-label col-md-4 text-left">
									Area <span class="asterix"> </span>
								</label>
								<div class="col-md-8">
									
									<?php if(count($checkArea)>0){?>
									<?php
										
for($i = 0; $i < count ( $area ); $i ++) {
											
											$check = SiteHelpers::getCheckbox ( $area [$i] ['AREA_ID'], $checkArea );
											
											?>
										<input type="checkbox" name="area[]"
										value="<?php echo $area[$i]['AREA_ID']?>" <?php echo $check?> data-parsley-mincheck="1" required>  &nbsp;&nbsp;<?php echo $area[$i]['AREA_NAME_EN']?> <br>
																					<?php
										}
									} 

									else {
										for($i = 0; $i < count ( $area ); $i ++) {
											?>
											<input type="checkbox" name="area[]"
										value="<?php echo $area[$i]['AREA_ID']?>" data-parsley-mincheck="1" required>  &nbsp;&nbsp;<?php echo $area[$i]['AREA_NAME_EN']?> <br>
											<?php
										}
									}
									?>
									  <i> <small></small></i>
								</div>
							</div>
								  			
								 <?php if($row['COURSE_ID']!=""){?>					
								  <div class="form-group  ">
								<label for="INACTIVE" class=" control-label col-md-4 text-left">
									Status </label>
								<div class="col-md-8">

									<label class='radio radio-inline'> <input type='radio'
										name='INACTIVE' value='0'
										<?php if($row['INACTIVE'] == '0') echo 'checked="checked"';?>>
										Inactive
									</label> <label class='radio radio-inline'> <input type='radio'
										name='INACTIVE' value='1'
										<?php if($row['INACTIVE'] == '1') echo 'checked="checked"';?>>
										Active
									</label> <br /> <i> <small></small></i>
								</div>
							</div> 
								 <?php } else{?>					
								  
								  <input type='hidden' class='form-control' placeholder=''
								value='1' name='INACTIVE' /> <br />
									  
								 <?php }?>
								 
								  <div class="form-group">
								<label class="col-sm-4 text-right"> </label>
								<div class="col-sm-8">

									<a id="texteditor" class="btn btn-primary">Text</a> <a
										id="fileuplaod" class="btn btn-primary">Image / File Upload</a> <a
										id="media" class="btn btn-primary">Media</a>

								</div>
							</div>
							<div id="myForm">
								   
								      <?php
														
if ($row ['COURSE_ID'] != "") {
															
															// print_r($COURSE_CONTENT);
															
															for($i = 0; $i < count ( $COURSE_CONTENT ); $i ++) {
																if ($COURSE_CONTENT [$i] ['COURSE_INFO_CONT_TYPE'] == 'TEXT') {
																	?><?php

																	/**
																	 *
																	 * @var Ambiguous $in
																	 */
																	// $in=strip_tags($content_material[$i]['COURSE_INFO_CONT_VALUE']);
																	// echo mb_strimwidth($in, 0, 10, "");
																	
																	?>
								      		<div class="div<?=$i?>" id="InputsWrapper_<?=$i?>">
									<div class="form-group  ">
										' <a id="<?=$i?>" class="removeclass0"><span><i
												class="fa fa-trash-o fa-lg"></i></span></a> <a id="<?=$i?>"
											class="upclass"><span><i class="fa fa-arrow-up"></i></span></a>
										<a id="<?=$i?>" class="downclass"><span><i
												class="fa fa-arrow-down"></i></span></a> <label
											for="Course Name" class=" control-label col-md-4 text-left">
											Editor <span class="asterix"> * </span>
										</label>
										<div class="col-md-8">
											<textarea name="COURSE_CONTENT[]" rows="5"
												id="editor_<?=$i?>" class="form-control markItUp "><?php echo $COURSE_CONTENT[$i]['COURSE_INFO_CONT_VALUE']?></textarea>
											<br> <i> <small></small></i>
										</div>
										<input type="hidden" name="type[]" value="TEXT"
											id="field_type'<?=$i?>">
									</div>
								</div> 
								<script type="text/javascript">
	area1 =  new MooEditable("editor_<?=$i?>",{
		actions: 'bold italic underline insertorderedlist insertunorderedlist'
	});
</script>
								      														<?php
																} elseif ($COURSE_CONTENT [$i] ['COURSE_INFO_CONT_TYPE'] == 'MEDIA') {
																	?>
								      		<div class="div<?=$i?>" id="InputsWrapper_<?=$i?>">
									<div class="form-group  ">
										' <a id="<?=$i?>" class="removeclass0"><span><i
												class="fa fa-trash-o fa-lg"></i></span></a> <a id="<?=$i?>"
											class="upclass"><span><i class="fa fa-arrow-up"></i></span></a>
										<a id="<?=$i?>" class="downclass"><span><i
												class="fa fa-arrow-down"></i></span></a> <label
											for="Course Name" class=" control-label col-md-4 text-left">
											Editor <span class="asterix"> * </span>
										</label>
										<div class="col-md-8">

											<input class="form-control" type="text"
												name="COURSE_CONTENT[]" id="media_<?=$i?>"
												placeholder="http://"
												value="<?php echo $COURSE_CONTENT[$i]['COURSE_INFO_CONT_VALUE']?>"
												 data-parsley-pattern="/^((http[s]?|ftp):)\/\/([a-z0-9_\.-]+)\.([\da-z\.-]+)\.([a-z\.]{2,6})\/(medias)\/([A-Za-z0-9_\.-]{10})/"  required
												/><br> <i> <small></small></i>
										</div>
										<input type="hidden" name="type[]" value="MEDIA"
											id="field_type'<?=$i?>">
									</div>
								</div> 
								      	
								      	<?php
																} elseif ($COURSE_CONTENT [$i] ['COURSE_INFO_CONT_TYPE'] == 'FILEUPLOAD') {
																	
																	?>
								      		
								      		<div class="div<?=$i?>" id="InputsWrapper_<?=$i?>">
									<div class="form-group  ">
										' <a id="<?=$i?>" class="removeclass0"><span><i
												class="fa fa-trash-o fa-lg"></i></span></a> <a id="<?=$i?>"
											class="upclass"><span><i class="fa fa-arrow-up"></i></span></a>
										<a id="<?=$i?>" class="downclass"><span><i
												class="fa fa-arrow-down"></i></span></a> <label
											for="Course Name" class=" control-label col-md-4 text-left">
											Editor <span class="asterix"> * </span>
										</label>
										<div class="col-md-8">
											<input type="hidden"
												value="<?php echo $COURSE_CONTENT[$i]['COURSE_INFO_CONT_VALUE']?>"
												name="COURSE_CONTENT_IMAGE[]"> <input
												<?php if($COURSE_CONTENT[$i]['COURSE_INFO_CONT_VALUE'] =='') echo 'class="required"' ;?>
												type="file" name="COURSE_CONTENT[]" id="file_<?=$i?>"
												placeholder="http://" /><br>
								      				<?php echo SiteHelpers::CourseshowUploadedFile($COURSE_CONTENT[$i]['COURSE_INFO_CONT_VALUE'],'/uploads/course/') ;?>
								      							<i> <small></small></i>
										</div>
										<input type="hidden" name="type[]" value="FILEUPLOAD"
											id="field_type'<?=$i?>">
									</div>
								</div> 
								      		
								      		<?php
																} else {
																}
																
																?>
								      	  <script type="text/javascript">
										
								      	document.getElementById("hidden").value = <?php echo $i?>+1;

								      	</script>
								      	  
								      	<?php
															}
															
															?>					
								    
								    
								    
								 	<?php
														}
														?>  
								   </div>
						</fieldset>
					</div>



					<div style="clear: both"></div>

					<div class="toolbar-line text-center">    
       <?php if($row['COURSE_ID']!=""){?>					
								     <button type="submit" name="Update" class="btn btn-info btn-sm"><i class="icon-checkmark-circle2"></i> Update</button>
     <input type="hidden" name="Update" value="update"/>
								 <?php }else{?>
								  <input type="submit" name="Sava&Unit"
							class="btn btn-info btn-sm " value="Save & Add Unit" />
      
								 
								 	<?php
							}
							?>   
      <a href="<?php echo site_url('admin/course');?>"
							class="btn btn-sm btn-warning"><i class="icon-cancel-circle2 "></i> <?php echo $this->lang->line('core.btn_cancel'); ?> </a>
					</div>

				</form>

			</div>
		</div>

	</div>
</div>

<script>
$(document).ready(function() {
    window.Parsley
        .addValidator('fileextension', function (value, requirement) {
        		var tagslistarr = requirement.split(',');
            var fileExtension = value.split('.').pop();
						var arr=[];
						$.each(tagslistarr,function(i,val){
   						 arr.push(val);
						});
            if(jQuery.inArray(fileExtension, arr)!='-1') {
           
              return true;
            } else {
             
              return false;
            }
        }, 32)
        .addMessage('en', 'fileextension', 'The extension doesn\'t match the required');

    $("#validationForm").parsley();

});


</script>
<script type="text/javascript">
$(document).ready(function() { 
    
});
</script>
