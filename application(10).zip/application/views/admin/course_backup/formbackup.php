<div class="page-content row">
    <!-- Page header -->
<div class="page-header">
  <div class="page-title">
  <h3> <a href="<?php echo site_url('dashboard') ?>"> Dashboard</a> / 
    <a href="<?php echo site_url('course') ?>"><?php echo $pageTitle ?></a> / 
    <?php echo "Form"?><?php //echo $pageTitle ?> <small><?php //echo $pageNote ?></small></h3>
  </div>
       
</div>
 
   <div class="page-content-wrapper m-t">     
    <div class="sbox" >
    <div class="sbox-title" >
      <h5><?php //echo $pageTitle ?> <small><?php //echo $pageNote ?></small></h5>
    </div>
    <div class="sbox-content" >

      
     <form action="<?php echo site_url('course/save/'.$row['COURSE_ID']); ?>" class='form-horizontal'  parsley-validate='true' novalidate='true' method="post" enctype="multipart/form-data" > 

<input type="hidden" value="0" id='hidden'> <p></p>
<div class="col-md-12">
						<fieldset>
									
								  <div class="form-group hidethis " style="display:none;">
									<label for="COURSE ID" class=" control-label col-md-4 text-left"> COURSE ID </label>
									<div class="col-md-8">
									  <input type='text' class='form-control' placeholder='' value='<?php echo $row['COURSE_ID'];?>' name='COURSE_ID'   /> <br />
									  <i> <small></small></i>
									 </div> 
								  </div> 					
								  <div class="form-group  " >
									<label for="Course Name" class=" control-label col-md-4 text-left"> Course Name </label>
									<div class="col-md-8">
									  <input type='text' class='form-control' placeholder='' value='<?php echo $row['COURSE_NAME'];?>' name='COURSE_NAME'   /> <br />
									  <i> <small></small></i>
									 </div> 
								  </div> 					
								  <?php if($row['COURSE_ID']!=""){?>					
								  <div class="form-group  " >
									<label for="INACTIVE" class=" control-label col-md-4 text-left"> Status </label>
									<div class="col-md-8">
									  
											<label class='radio radio-inline'>
											<input type='radio' name='INACTIVE' value ='0'  <?php if($row['INACTIVE'] == '0') echo 'checked="checked"';?> > Inactive </label>
											<label class='radio radio-inline'>
											<input type='radio' name='INACTIVE' value ='1'  <?php if($row['INACTIVE'] == '1') echo 'checked="checked"';?> > Active </label> <br />
										<i> <small></small></i>
									 </div> 
								  </div> 
								 <?php } else{?>					
								  
								  <input type='hidden' class='form-control' placeholder='' value='1' name='INACTIVE'   /> <br />
									  
								 <?php }?>
								 <div class="form-group">
									<label class="col-sm-4 text-right"> </label>
									<div class="col-sm-8">	
										<!-- <input type="button" class="btn btn-primary" onclick="btnmedia()" name="Submit" value="Text"/>
										<input type="button" class="btn btn-primary" onclick="btnfile()" name="Submit" value="FileUpload"/>
										<input type="button" class="btn btn-primary" onclick="btneditor()" name="Submit" value="FileUpload"/>
										-->
										<a id="texteditor" class="btn btn-primary">Text</a>
						<a id="fileuplaod" class="btn btn-primary">File Upload</a>
						<a id="media" class="btn btn-primary">Media</a>					
										
										
									</div>
								  </div>
										<div id="courseForm">
								
									 <div class="form-group">
									
										<label class="col-sm-4 text-right"> </label>
										<div class="col-sm-8">	
										
										
										</div>
									  </div>
								</div>
								   </fieldset>
			</div>
			
			
    
      <div style="clear:both"></div>  
        
     <div class="toolbar-line text-center">    
      <input type="submit" name="apply" class="btn btn-info btn-sm" value="<?php echo $this->lang->line('core.btn_apply'); ?>" />
      <input type="submit" name="submit" class="btn btn-primary btn-sm" value="<?php echo $this->lang->line('core.btn_submit'); ?>" />
      <a href="<?php echo site_url('course');?>" class="btn btn-sm btn-warning"><?php echo $this->lang->line('core.btn_cancel'); ?> </a>
     </div>
            
    </form>
    
    </div>
    </div>

  </div>  
</div>  
</div>
       
<script type="text/javascript">
$(document).ready(function() { 
    
});
</script>     