<?php

print_r($COURSE_ID);
?>