<?php 

echo "hello";
print_r($COURSE_ID);



?>
