<div class="page-content row">
    <!-- Page header -->
<div class="page-header">
  <div class="page-title">
  <h3> <?php echo $pageTitle ?> <small><?php echo $pageNote ?></small></h3>
  </div>
  <ul class="breadcrumb">
    <li><a href="<?php echo site_url('dashboard') ?>"> Dashboard </a></li>
    <li><a href="<?php echo site_url('groups') ?>"><?php echo $pageTitle ?></a></li>
    <li class="active"> Form </li>
  </ul>      
</div>
 
   <div class="page-content-wrapper m-t">     
    <div class="sbox" >
    <div class="sbox-title" >
      <h5><?php echo $pageTitle ?> <small><?php echo $pageNote ?></small></h5>
    </div>
    <div class="sbox-content" >

      
     <form action="<?php echo site_url('groups/save/'.$row['ROLE_ID']); ?>" class='form-horizontal'  data-parsley-validate='true' method="post" enctype="multipart/form-data" > 


<div class="col-md-12">
						<fieldset><legend> groups</legend>
									
								  <div class="form-group hidethis " style="display:none;">
									<label for="ROLE ID" class=" control-label col-md-4 text-left"> ROLE ID </label>
									<div class="col-md-8">
									  <input type='text' class='form-control' placeholder='' value='<?php echo $row['ROLE_ID'];?>' name='ROLE_ID'   /> <br />
									  <i> <small></small></i>
									 </div> 
								  </div> 					
								  <div class="form-group  " >
									<label for="ROLE NAME" class=" control-label col-md-4 text-left"> ROLE NAME </label>
									<div class="col-md-8">
									  <input type='text' class='form-control' placeholder='' value='<?php echo $row['ROLE_NAME'];?>' name='ROLE_NAME'   /> <br />
									  <i> <small></small></i>
									 </div> 
								  </div> 					
								  <div class="form-group  " >
									<label for="INACTIVE" class=" control-label col-md-4 text-left"> INACTIVE </label>
									<div class="col-md-8">
									  
					<label class='radio radio-inline'>
					<input type='radio' name='INACTIVE' value ='1'  <?php if($row['INACTIVE'] == '1') echo 'checked="checked"';?> > Active </label>
					<label class='radio radio-inline'>
					<input type='radio' name='INACTIVE' value ='0'  <?php if($row['INACTIVE'] == '0') echo 'checked="checked"';?> > Inactive </label> <br />
									  <i> <small></small></i>
									 </div> 
								  </div> </fieldset>
			</div>
			
			
    
      <div style="clear:both"></div>  
        
     <div class="toolbar-line text-center">    
      <input type="submit" name="apply" class="btn btn-info btn-sm" value="<?php echo $this->lang->line('core.btn_apply'); ?>" />
      <input type="submit" name="submit" class="btn btn-primary btn-sm" value="<?php echo $this->lang->line('core.btn_submit'); ?>" />
      <a href="<?php echo site_url('groups');?>" class="btn btn-sm btn-warning"><?php echo $this->lang->line('core.btn_cancel'); ?> </a>
     </div>
            
    </form>
    
    </div>
    </div>

  </div>  
</div>  

       
<script type="text/javascript">
$(document).ready(function() { 
    
});
</script>     