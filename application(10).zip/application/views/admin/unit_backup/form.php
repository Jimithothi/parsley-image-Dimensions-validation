<div class="page-content row">
    <!-- Page header -->
<div class="page-header">
  <div class="page-title">
  <h3> <a href="<?php echo site_url('dashboard') ?>"> Dashboard</a> / 
    <a href="<?php echo site_url('unit') ?>"><?php echo $pageTitle ?></a> / 
    <?php echo "Form"?><?php //echo $pageTitle ?> <small><?php //echo $pageNote ?></small></h3>
  </div>
       
</div>
 
   <div class="page-content-wrapper m-t">     
    <div class="sbox" >
    <div class="sbox-title" >
      <h5><?php //echo $pageTitle ?> <small><?php //echo $pageNote ?></small></h5>
    </div>
    <div class="sbox-content" >

      
     <form action="<?php echo site_url('unit/save/'.$row['UNIT_ID']); ?>" class='form-horizontal'  parsley-validate='true' novalidate='true' method="post" enctype="multipart/form-data" > 
<input type="hidden" value="0" id='hidden'> <p></p>

<div class="col-md-12">
						<fieldset>
									
								  <div class="form-group hidethis " style="display:none;">
									<label for="UNIT ID" class=" control-label col-md-4 text-left"> UNIT ID </label>
									<div class="col-md-8">
									  <input type='text' class='form-control' placeholder='' value='<?php echo $row['UNIT_ID'];?>' name='UNIT_ID'   /> <br />
									  <i> <small></small></i>
									 </div> 
								  </div> 
								  <div class="form-group  " >
								
									<div class="col-md-8">
									 <input type='hidden' class='form-control' placeholder='' value='<?php echo $row['COURSE_ID']['COURSE_ID'];?>' name='COURSE_ID'   /> <br />
									 
									 
									  <i> <small></small></i>
									 </div> 
								  </div> 
								  					
								  <div class="form-group  " >
									<label for="COURSE ID" class=" control-label col-md-4 text-left"> COURSE NAME </label>
									<div class="col-md-8">
									 <input type='text' class='form-control' placeholder='' value='<?php echo $row['COURSE_ID']['COURSE_NAME'];?>' name='COURSE_NAME'   /> <br />
									 
									 
									  <i> <small></small></i>
									 </div> 
								  </div> 					
								  <div class="form-group  " >
									<label for="UNIT NAME" class=" control-label col-md-4 text-left"> UNIT NAME </label>
									<div class="col-md-8">
									  <input type='text' class='form-control' placeholder='' value='<?php echo $row['UNIT_NAME'];?>' name='UNIT_NAME'   /> <br />
									  <i> <small></small></i>
									 </div> 
								  </div> 
								  
								   <div class="form-group">
									<label class="col-sm-4 text-right"> </label>
									<div class="col-sm-8">	
										
										<a id="texteditor" class="btn btn-primary">Text</a>
										<a id="fileuplaod" class="btn btn-primary">File Upload</a>
										<a id="media" class="btn btn-primary">Media</a>	
										
									</div>
								  </div>
								  
								   <div id="myForm">
								   
								      <?php if($row['UNIT_ID']!=""){
								      	
								      	//print_r($content_material[0]);
								      	
								      for ($i=0;$i<count($content_material);$i++)
								      {
								      	if($content_material[$i]['UNIT_INFO_CONT_TYPE']=='TEXT')
								      	{
								      		?>
								      		<div class="div<?=$i?>" id="InputsWrapper_<?=$i?>">
								      		<div class="form-group  " >'
								      		<a id="<?=$i?>" class="removeclass0" ><span><i class="fa fa-trash-o fa-lg"></i><span></a>
								      		<a id="<?=$i?>" class="upclass"><span><i class="fa fa-arrow-up"></i></span></a>
								      		<a id="<?=$i?>" class="downclass"><span><i class="fa fa-arrow-down"></i></span></a>
								      				<label for="Course Name" class=" control-label col-md-4 text-left"> Editor <span class="asterix"> * </span></label>
								      				<div class="col-md-8">
								      						<textarea name="COURSE_CONTENT[]" rows="5" id="editor_<?=$i?>" class="form-control markItUp "><?php echo $content_material[$i]['UNIT_INFO_CONT_VALUE']?></textarea><br>
								      								<i> <small></small></i>
								      				</div> <input type="hidden" name="type[]" value="TEXT" id="field_type'<?=$i?>">
								      		</div>
								      		</div> 
								      														<?php 
								      														
								      	}
								      	elseif ($content_material[$i]['UNIT_INFO_CONT_TYPE']=='MEDIA')
								      	{
								      	?>
								      		<div class="div<?=$i?>" id="InputsWrapper_<?=$i?>">
								      		<div class="form-group  " >'
								      		<a id="<?=$i?>" class="removeclass0" ><span><i class="fa fa-trash-o fa-lg"></i><span></a>
								      		<a id="<?=$i?>" class="upclass"><span><i class="fa fa-arrow-up"></i></span></a>
								      		<a id="<?=$i?>" class="downclass"><span><i class="fa fa-arrow-down"></i></span></a>
								      				<label for="Course Name" class=" control-label col-md-4 text-left"> Editor <span class="asterix"> * </span></label>
								      				<div class="col-md-8">
								      				
								      				<input class="form-control" type="text" name="COURSE_CONTENT[]" id="media_<?=$i?>" placeholder="http://" value="<?php echo $content_material[$i]['UNIT_INFO_CONT_VALUE']?>" data-parsley-pattern="^[a-zA-Z]{4}[ -]?[a-zA-Z]{4}[ -]?[a-zA-Z]{4}[ -]?[a-zA-Z]{4}$" required/><br>
								      				
								      							<i> <small></small></i>
								      				</div> <input type="hidden" name="type[]" value="MEDIA" id="field_type'<?=$i?>">
								      		</div>
								      		</div> 
								      	
								      	<?php 
								      	}else {
								      		
								      		?>
								      		
								      		<div class="div<?=$i?>" id="InputsWrapper_<?=$i?>">
								      		<div class="form-group  " >'
								      		<a id="<?=$i?>" class="removeclass0" ><span><i class="fa fa-trash-o fa-lg"></i><span></a>
								      		<a id="<?=$i?>" class="upclass"><span><i class="fa fa-arrow-up"></i></span></a>
								      		<a id="<?=$i?>" class="downclass"><span><i class="fa fa-arrow-down"></i></span></a>
								      				<label for="Course Name" class=" control-label col-md-4 text-left"> Editor <span class="asterix"> * </span></label>
								      				<div class="col-md-8">
								      				
								      				<input class="form-control parsley-validated" type="file" name="COURSE_CONTENT[]" id="file_<?=$i?>" placeholder="http://"/><br>
								      				<?php echo SiteHelpers::showUploadedFile($content_material[$i]['UNIT_INFO_CONT_VALUE'],'/uploads/course/unit/') ;?>
								      				
								      							<i> <small></small></i>
								      				</div> <input type="hidden" name="type[]" value="FILEUPLOAD" id="field_type'<?=$i?>">
								      		</div>
								      		</div> 
								      		
								      		<?php 
								      	}
								      	
								      	?>
								      	  <script type="text/javascript">
										
								      	document.getElementById("hidden").value = <?php echo $i?>+1;

								      	</script>
								      	  
								      	<?php 								    
								      	
								      }
								      	
								   
								      	?>					
								    
								    
								    
								 	<?php
								 } ?>  
								   </div>
								  
								  </fieldset>
			</div>
			
			
    
      <div style="clear:both"></div>  
        
     <div class="toolbar-line text-center">    
  
   
      <?php if($row['UNIT_ID']!=""){?>					
								    <input type="submit" name="Update" class="btn btn-primary btn-sm" value="Update" />
     
								 <?php }else{?>
								  <input type="submit" name="Save" class="btn btn-info btn-sm" value="Save" />
      
								 
								 	<?php
								 } ?>   
      <a href="<?php echo site_url('course');?>" class="btn btn-sm btn-warning"><?php echo $this->lang->line('core.btn_cancel'); ?> </a>
    </div>
            
    </form>
    
    </div>
    </div>

  </div>  
</div>  
</div>
       
<script type="text/javascript">
$(document).ready(function() { 

		$("#COURSE_ID").jCombo("<?php echo site_url('unit/comboselect?filter=course_master:COURSE_ID:COURSE_NAME') ?>",
		{  selected_value : '<?php echo $row["COURSE_ID"] ?>' });
		    
});
</script>     