<div class="page-content row">
    <!-- Page header -->
<div class="page-header">
  <div class="page-title">
  <h3> <a href="<?php echo site_url('dashboard') ?>"> Dashboard</a> / 
    <a href="<?php echo site_url('admin/managecms') ?>"><?php echo $pageTitle ?></a> 
    <?php //echo $pageTitle ?> <small><?php //echo $pageNote ?></small></h3>
  </div>
       
</div>
 
   <div class="page-content-wrapper m-t">     
    <div class="sbox" >
    <div class="sbox-title" >
      <h5>  <?php echo $addForm;?>   <?php //echo $pageTitle ?> <small><?php //echo $pageNote ?></small></h5>
    </div>
    <div class="sbox-content" >

      
     <form action="<?php echo site_url('admin/managecms/save/'.$row['CMS_ID']); ?>" class='form-horizontal'  data-parsley-validate='true' method="post" enctype="multipart/form-data" > 


<div class="col-md-12">
						<fieldset>
									
								  <div class="form-group hidethis " style="display:none;">
									<label for="CMS ID" class=" control-label col-md-4 text-left"> CMS ID </label>
									<div class="col-md-8">
									  <input type='text' class='form-control' placeholder='' value='<?php echo $row['CMS_ID'];?>' name='CMS_ID'   /> <br />
									  <i> <small></small></i>
									 </div> 
								  </div> 					
								  <div class="form-group  " >
									<label for="Type" class=" control-label col-md-4 text-left"> Type </label>
									<div class="col-md-8">
									  
					<?php $CMS_TYPE = explode(',',$row['CMS_TYPE']);
					$CMS_TYPE_opt = array( 'ACCOUNCEMENT' => 'ACCOUNCEMENT' ,  'NEWS' => 'NEWS' , ); ?>
					<select name='CMS_TYPE' rows='5'   class='select2 '  > 
						<?php 
						foreach($CMS_TYPE_opt as $key=>$val)
						{
							echo "<option  value ='$key' ".($row['CMS_TYPE'] == $key ? " selected='selected' " : '' ).">$val</option>"; 						
						}						
						?></select> <br />
									  <i> <small></small></i>
									 </div> 
								  </div> 					
								  <div class="form-group  " >
									<label for="Name (EN)" class=" control-label col-md-4 text-left"> Name (EN) <span class="asterix" style="color: red;"> * </span></label>
									<div class="col-md-8">
									  <input type='text' class='form-control' placeholder='' value='<?php echo $row['CMS_TITLE_EN'];?>' name='CMS_TITLE_EN'  required /> <br />
									  <i> <small></small></i>
									 </div> 
								  </div> 					
								  <div class="form-group  " >
									<label for="Name (SP)" class=" control-label col-md-4 text-left"> Name (SP) <span class="asterix" style="color: red;"> * </span></label>
									<div class="col-md-8">
									  <input type='text' class='form-control' placeholder='' value='<?php echo $row['CMS_TITLE_SP'];?>' name='CMS_TITLE_SP'  required /> <br />
									  <i> <small></small></i>
									 </div> 
								  </div> 	
								  				
								  <div class="form-group  " >
									<label for="Description (EN)" class=" control-label col-md-4 text-left"> Description (EN) </label>
									<div class="col-md-8">
									  <textarea name='CMS_DESC_EN' rows='2' id='CMS_DESC_EN' data-parsley-maxlength="100" class='form-control '  
				           ><?php echo $row['CMS_DESC_EN'] ;?></textarea> <br /><i> <small></small></i>
									 </div> 
								  </div> 					
								  <div class="form-group  " >
									<label for="Description (ES)" class=" control-label col-md-4 text-left"> Description (ES) </label>
									<div class="col-md-8">
									 <textarea name='CMS_DESC_SP' rows='2' id='CMS_DESC_SP' data-parsley-maxlength="100" class='form-control '  
				           ><?php echo $row['CMS_DESC_SP'] ;?></textarea> <br /><i> <small></small></i>
									 </div> 
								  </div> 					
								  <div class="form-group  " >
									<label for="Image" class=" control-label col-md-4 text-left"> Image <span class="asterix" style="color: red;"> * </span></label>
									<div class="col-md-8">
									  <input  type='file' name='CMS_IMAGE' id='CMS_IMAGE' <?php if($row['CMS_IMAGE'] =='') echo 'class="required"' ;?> style='width:150px !important;'  />
					<?php echo SiteHelpers::showUploadedFile($row['CMS_IMAGE'],'/uploads/News/') ;?>
				 <br />
									  <i> <small></small></i>
									 </div> 
								  </div> 					
								 <?php if($row['CMS_ID']!=""){?>					
								  <div class="form-group  " >
									<label for="INACTIVE" class=" control-label col-md-4 text-left"> Status </label>
									<div class="col-md-8">
									  
											<label class='radio radio-inline'>
											<input type='radio' name='INACTIVE' value ='0'  <?php if($row['INACTIVE'] == '0') echo 'checked="checked"';?> > Inactive </label>
											<label class='radio radio-inline'>
											<input type='radio' name='INACTIVE' value ='1'  <?php if($row['INACTIVE'] == '1') echo 'checked="checked"';?> > Active </label> <br />
										<i> <small></small></i>
									 </div> 
								  </div> 
								 <?php } else{?>					
								  
								  <input type='hidden' class='form-control' placeholder='' value='1' name='INACTIVE'   /> <br />
									  
								 <?php }?>  </fieldset>
			</div>
			
			
    
      <div style="clear:both"></div>  
        
     <div class="toolbar-line text-center">    
      <?php if($row['CMS_ID']!=""){?>					
								    <button type="submit" name="Update" class="btn btn-info btn-sm"><i class="icon-checkmark-circle2"></i> Update</button>
     
								 <?php }else{?>
								 <button type="submit" name="submit" class="btn btn-primary btn-sm"><i class="icon-bubble-check"></i> Save</button>
								 	<?php
								 } ?>   
      <a href="<?php echo site_url('admin/managecms');?>" class="btn btn-sm btn-warning"><i class="icon-cancel-circle2 "></i> <?php echo $this->lang->line('core.btn_cancel'); ?> </a>
     </div>
            
    </form>
    
    </div>
    </div>

  </div>  
</div>  

       
<script type="text/javascript">
$(document).ready(function() { 
    
});
</script>     