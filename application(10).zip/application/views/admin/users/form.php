<div class="page-content row">
    <!-- Page header -->
<div class="page-header">
  <div class="page-title">
  <h3> <a href="<?php echo site_url('dashboard') ?>"> Dashboard</a> / 
    <a href="<?php echo site_url('users') ?>"><?php echo $pageTitle ?></a> / 
    <?php echo "Form"?><?php //echo $pageTitle ?> <small><?php //echo $pageNote ?></small></h3>
  </div>
       
</div>
 
   <div class="page-content-wrapper m-t">     
    <div class="sbox" >
    <div class="sbox-title" >
      <h5><?php //echo $pageTitle ?> <small><?php //echo $pageNote ?></small></h5>
    </div>
    <div class="sbox-content" >

      
     <form action="<?php echo site_url('admin/users/save/'.$row['USER_ID']); ?>" class='form-horizontal'  parsley-validate='true' novalidate='true' method="post" enctype="multipart/form-data" > 


<div class="col-md-12">
						<fieldset>
									
								  <div class="form-group hidethis " style="display:none;">
									<label for="USER ID" class=" control-label col-md-4 text-left"> USER ID </label>
									<div class="col-md-8">
									  <input type='text' class='form-control' placeholder='' value='<?php echo $row['USER_ID'];?>' name='USER_ID'   /> <br />
									  <i> <small></small></i>
									 </div> 
								  </div> 					
								  <div class="form-group  " >
									<label for="USER NAME" class=" control-label col-md-4 text-left"> USER NAME <span class="asterix"> * </span></label>
									<div class="col-md-8">
									  <input type='email' class='form-control' placeholder='' value='<?php echo $row['USER_NAME'];?>' name='USER_NAME'  required /> <br />
									  <i> <small></small></i>
									 </div> 
								  </div> 					
								  <div class="form-group  " >
									<label for="FIRST NAME" class=" control-label col-md-4 text-left"> FIRST NAME </label>
									<div class="col-md-8">
									  <input type='text' class='form-control' placeholder='' value='<?php echo $row['FIRST_NAME'];?>' name='FIRST_NAME'   /> <br />
									  <i> <small></small></i>
									 </div> 
								  </div> 					
								  <div class="form-group  " >
									<label for="LAST NAME" class=" control-label col-md-4 text-left"> LAST NAME </label>
									<div class="col-md-8">
									  <input type='text' class='form-control' placeholder='' value='<?php echo $row['LAST_NAME'];?>' name='LAST_NAME'   /> <br />
									  <i> <small></small></i>
									 </div> 
								  </div> 					
								  <div class="form-group  " >
									<label for="NICK NAME" class=" control-label col-md-4 text-left"> NICK NAME </label>
									<div class="col-md-8">
									  <input type='text' class='form-control' placeholder='' value='<?php echo $row['NICK_NAME'];?>' name='NICK_NAME'  required /> <br />
									  <i> <small></small></i>
									 </div> 
								  </div> 					
								  <div class="form-group  " >
									<label for="PROFESSIONAL HEADLINE" class=" control-label col-md-4 text-left"> PROFESSIONAL HEADLINE </label>
									<div class="col-md-8">
									  <input type='text' class='form-control' placeholder='' value='<?php echo $row['PROFESSIONAL_HEADLINE'];?>' name='PROFESSIONAL_HEADLINE'   /> <br />
									  <i> <small></small></i>
									 </div> 
								  </div> 					
								  <div class="form-group  " >
									<label for="COUNTRY" class=" control-label col-md-4 text-left"> COUNTRY </label>
									<div class="col-md-8">
									  
					<?php $COUNTRY = explode(',',$row['COUNTRY']);
					$COUNTRY_opt = array( '' => '' , ); ?>
					<select name='COUNTRY' rows='5'   class='select2 '  > 
						<?php 
						foreach($COUNTRY_opt as $key=>$val)
						{
							echo "<option  value ='$key' ".($row['COUNTRY'] == $key ? " selected='selected' " : '' ).">$val</option>"; 						
						}						
						?></select> <br />
									  <i> <small></small></i>
									 </div> 
								  </div> 					
								  <div class="form-group  " >
									<label for="DOB" class=" control-label col-md-4 text-left"> DOB </label>
									<div class="col-md-8">
									  
				<input type='text' class='form-control date' placeholder='' value='<?php echo $row['DOB'];?>' name='DOB'
				style='width:150px !important;'	   /> <br />
									  <i> <small></small></i>
									 </div> 
								  </div> 					
								  <div class="form-group  " >
									<label for="TELL ABOUT YOURSELF" class=" control-label col-md-4 text-left"> TELL ABOUT YOURSELF </label>
									<div class="col-md-8">
									  <input type='text' class='form-control' placeholder='' value='<?php echo $row['TELL_ABOUT_YOURSELF'];?>' name='TELL_ABOUT_YOURSELF'   /> <br />
									  <i> <small></small></i>
									 </div> 
								  </div> 					
								  <div class="form-group  " >
									<label for="WEBSITE" class=" control-label col-md-4 text-left"> WEBSITE </label>
									<div class="col-md-8">
									  <input type='text' class='form-control' placeholder='' value='<?php echo $row['WEBSITE'];?>' name='WEBSITE'   /> <br />
									  <i> <small></small></i>
									 </div> 
								  </div> 					
								  <div class="form-group  " >
									<label for="PHONE" class=" control-label col-md-4 text-left"> PHONE </label>
									<div class="col-md-8">
									  <input type='text' class='form-control' placeholder='' value='<?php echo $row['PHONE'];?>' name='PHONE'   /> <br />
									  <i> <small></small></i>
									 </div> 
								  </div> 					
								  <div class="form-group  " >
									<label for="Image" class=" control-label col-md-4 text-left"> Image </label>
									<div class="col-md-8">
									  <input  type='file' name='USER_IMAGE' id='USER_IMAGE' <?php if($row['USER_IMAGE'] =='') echo 'class="required"' ;?> style='width:150px !important;'  />
					<?php echo SiteHelpers::showUploadedFile($row['USER_IMAGE'],'/uploads/users/') ;?>
				 <br />
									  <i> <small></small></i>
									 </div> 
								  </div> 					
								  <div class="form-group  " >
									<label for="Status" class=" control-label col-md-4 text-left"> Status </label>
									<div class="col-md-8">
									  
					<label class='radio radio-inline'>
					<input type='radio' name='INACTIVE' value ='0'  <?php if($row['INACTIVE'] == '0') echo 'checked="checked"';?> > Inactive </label>
					<label class='radio radio-inline'>
					<input type='radio' name='INACTIVE' value ='1'  <?php if($row['INACTIVE'] == '1') echo 'checked="checked"';?> > Active </label> <br />
									  <i> <small></small></i>
									 </div> 
								  </div> 					
								  <div class="form-group  " >
									<label for="Role" class=" control-label col-md-4 text-left"> Role </label>
									<div class="col-md-8">
									  <select name='ROLE_ID' rows='5' id='ROLE_ID' code='{$ROLE_ID}' 
							class='select2 '    required></select> <br />
									  <i> <small></small></i>
									 </div> 
								  </div> </fieldset>
			</div>
			
			
    
      <div style="clear:both"></div>  
        
     <div class="toolbar-line text-center">    
       <?php if($row['USER_ID']!=""){?>					
								    <button type="submit" name="Update" class="btn btn-info btn-sm"><i class="icon-checkmark-circle2"></i> Update</button>
     
								 <?php }else{?>
								  <button type="submit" name="submit" class="btn btn-primary btn-sm"><i class="icon-bubble-check"></i> Save</button>
								 
								 	<?php
								 } ?>   
      <a href="<?php echo site_url('admin/users');?>" class="btn btn-sm btn-warning"><i class="icon-cancel-circle2 "></i> <?php echo $this->lang->line('core.btn_cancel'); ?> </a>
       </div>
            
    </form>
    
    </div>
    </div>

  </div>  
</div>  
</div>
       
<script type="text/javascript">
$(document).ready(function() { 

		$("#ROLE_ID").jCombo("<?php echo site_url('users/comboselect?filter=role_master:ROLE_ID:ROLE_NAME') ?>",
		{  selected_value : '<?php echo $row["ROLE_ID"] ?>' });
		    
});
</script>     