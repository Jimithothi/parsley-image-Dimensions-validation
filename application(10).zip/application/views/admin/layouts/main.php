<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="ISO-8859-1">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?php echo  CNF_APPNAME ;?></title>

<link rel="stylesheet" href="<?php echo base_url();?>assets/admin/js/plugins/bootstrap/css/bootstrap.css" type="text/css"  />	
 <!-- <link href="http://fonts.googleapis.com/css?family=Lato:400,400,400italic,600,700|Raleway:400,400,500,600,700|Crete+Round:400italic" rel="stylesheet" type="text/css" />
 --> <link href="<?php echo base_url('assets/admin/css/sximo.css');?>" rel="stylesheet">	
	<link href="<?php echo base_url('assets/admin/css/AdminLTE.min.css');?>" rel="stylesheet">	

<link rel="stylesheet" href="<?php echo base_url();?>assets/admin/css/icons.min.css" type="text/css"  />
<link media="all" type="text/css" rel="stylesheet" href="<?php echo base_url();?>assets/admin/js/plugins/select2/select2.css">



<link rel="stylesheet" href="<?php echo base_url();?>assets/admin/fonts/awesome/css/font-awesome.min.css" type="text/css"  />
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/admin/js/plugins/iCheck/skins/square/red.css" type="text/css"  />
<link rel="stylesheet" href="<?php echo base_url();?>assets/admin/js/plugins/markitup/skins/simple/style.css" type="text/css"  />
<link rel="stylesheet" href="<?php echo base_url();?>assets/admin/js/plugins/markitup/sets/default/style.css" type="text/css"  />
<link rel="stylesheet" href="<?php echo base_url();?>assets/admin/js/plugins/fancybox/jquery.fancybox.css" type="text/css"  />
<link rel="stylesheet" href="<?php echo base_url();?>assets/admin/js/plugins/toastr/toastr.css" type="text/css"  />
	
	
	<script src="<?php echo base_url();?>assets/admin/js/bootstrap.min.js"></script>
	<script src="<?php echo base_url();?>assets/admin/js/jquery-2.2.4.min.js"></script>
	<script type="text/javascript" src="<?php echo base_url();?>assets/admin/js/parsley.min.js"></script>
	
	
	
	<link rel="stylesheet" href="<?php echo base_url();?>assets/frontend/css/MooEditable/MooEditable.css" type="text/css">

<script src="<?php echo base_url();?>assets/admin/js/plugins/jquery.cookie.js"></script>
<script src="<?php echo base_url();?>assets/admin/js/plugins/jquery-ui.min.js"></script>

<script src="<?php echo base_url();?>assets/admin/js/plugins/select2/select2.min.js"></script>

<script src="<?php echo base_url();?>assets/admin/js/plugins/iCheck/icheck.min.js"></script>
<script src="<?php echo base_url();?>assets/admin/js/plugins/prettify.js"></script>
<script src="<?php echo base_url();?>assets/admin/js/plugins/fancybox/jquery.fancybox.js"></script>
<script src="<?php echo base_url();?>assets/admin/js/plugins/prettify.js"></script>

<script src="<?php echo base_url();?>assets/admin/js/plugins/datepicker/js/bootstrap-datetimepicker.min.js"></script>
<script src="<?php echo base_url();?>assets/admin/js/plugins/bootstrap.datetimepicker/js/bootstrap-datetimepicker.min.js"></script>
<script src="<?php echo base_url();?>assets/admin/js/plugins/jquery.jCombo.min.js"></script>
<script src="<?php echo base_url();?>assets/admin/js/backup.js"></script>
<script src="<?php echo base_url();?>assets/admin/js/plugins/bootstrap.summernote/summernote.min.js"></script>
<script src="<?php echo base_url();?>assets/admin/js/plugins/toastr/toastr.js"></script>

<script src="<?php echo base_url();?>assets/admin/js/plugins/markitup/jquery.markitup.js"></script>
<script src="<?php echo base_url();?>assets/admin/js/plugins/markitup/sets/default/set.js"></script>

<script src="<?php echo base_url();?>assets/admin/js/plugins/tinymce_4.4.3/tinymce.min.js"></script>

<script src="<?php echo base_url();?>assets/admin/js/sximo.js"></script>









<script src="<?php echo base_url();?>assets/frontend/libs/MooEditable/mootools.js"></script>
<script src="<?php echo base_url();?>assets/frontend/libs/MooEditable/MooEditable.js"></script>

		<script>
	tinymce.init({
		selector: "mceEditor",
  menubar:false,
  statusbar: false,
  
  height: 200,
  plugins: [
    '  lists  preview anchor',
    ' fullscreen',    
  ],
  toolbar: 'bold italic underline |  bullist numlist  ',
});
	</script>
	
		<script type="text/javascript">
		//$('.markItUp').mooEditable();
	//area1 =  new MooEditable("markItUp",{
	//	actions: 'bold italic underline insertorderedlist insertunorderedlist'
	//});
	
</script>

		<!--[if lt IE 9]>
			<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
			<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
		<![endif]-->	


</head>

<body class="sxim-init" >
<div id="wrapper">
	<?php $this->load->view('admin/layouts/sidemenu');?>
	<div class="gray-bg " id="page-wrapper">
		<?php $this->load->view('admin/layouts/headmenu');?>
		<?php echo $content ;?>		
	</div>
</div>

<div class="modal fade" id="sximo-modal" tabindex="-1" role="dialog">
<div class="modal-dialog">
  <div class="modal-content">
	<div class="modal-header bg-default">
		
		<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
		<h4 class="modal-title">Modal title</h4>
	</div>
	<div class="modal-body" id="sximo-modal-content">

	</div>

  </div>
</div>
</div>


<script type="text/javascript">
	jQuery(document).ready(function ($) {
		$('#sidemenu').sximMenu();	
		

	});		
  
<?php 
if( $msg = $this->session->flashdata("message")){
?>  
  toastr["<?php echo $msg['type'] ?>"]("<?php echo $msg['caption'] ?>","<?php echo $msg['title'] ?>"); 
<?php 
}
?>
  
</script>
</body>
</html>
