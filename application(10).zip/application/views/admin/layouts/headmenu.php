<div class="row  ">
	<nav style="margin-bottom: 0;" role="navigation" class="navbar navbar-static-top gray-bg">
	<div class="navbar-header">
		<a href="javascript:void(0)" class="navbar-minimalize minimalize-btn btn btn-primary "><i class="fa fa-bars"></i> </a>			
	</div>
	
	
	 <ul class="nav navbar-top-links navbar-right">
		
	 	<?php if($this->session->userdata('gid') ==1) : ?>

			
	
		<?php endif;?>

		<li class="user dropdown">
		<a href="<?php echo site_url('admin/user/logout') ;?>"><i class="icon-exit"></i> <?php echo $this->lang->line('core.m_logout'); ?> </a></li>
			
			
			
		
	</ul>	
	</nav>	 
	 
</div>	