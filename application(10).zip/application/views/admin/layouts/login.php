<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title> Proyectarte - Login</title>

<link rel="stylesheet" href="<?php echo site_url();?>assets/admin/js/plugins/bootstrap/css/bootstrap.css" type="text/css"  />	
<link rel="stylesheet" href="<?php echo site_url();?>assets/admin/css/sximo.css" type="text/css"  />

<script src="<?php echo base_url();?>assets/admin/js/plugins/jquery.min.js"></script>
<script src="<?php echo base_url();?>assets/admin/js/plugins/parsley.js"></script>
<script src="<?php echo base_url();?>assets/admin/js/plugins/bootstrap/js/bootstrap.min.js"></script>

		<!--[if lt IE 9]>
			<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
			<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
		<![endif]-->	

		
	
  	</head>
<body class="gray-bg">
    <div class="middle-box  ">
        <div>

           <?php echo $content ;?>
        </div>
    </div>



</body> 
</html>
