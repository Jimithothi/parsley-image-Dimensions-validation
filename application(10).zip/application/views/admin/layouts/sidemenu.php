<nav role="navigation" class="navbar-default navbar-static-side">
	 <div class="sidebar-collapse">				  
	   <ul id="sidemenu" class="nav expanded-menu">
		<li class="logo-header" >
		 <a class="navbar-brand" href="<?php echo site_url('dashboard') ;?>">
		 <img width="100%" align="middle" style="margin-right:5px;" alt="My Apps" src="<?php echo base_url() ;?>assets/admin/images/Home_logo.png">
			<?php //echo CNF_APPNAME;?>
		 </a>
		</li>
		<li class="nav-header">
			<div class="dropdown profile-element" style="text-align:center;"> 
				<span>
					<?php echo SiteHelpers::avatar('75');?>
					
				</span>
				<a href="<?php echo site_url('admin/user/profile');?>" >
				<span class="clear"> <span class="block m-t-xs"> <strong class="font-bold"><?php echo $this->session->userdata('fid');?> </strong>
				 <br /> Last Login : <br />
				<small><?php echo date("H:i M j, Y",strtotime($this->session->userdata('ll'))) ;?></small>				
				 </span> 
				 </span>
				 </a>
			</div>
			<div class="photo-header "> <?php echo SiteHelpers::avatar('50');?> </div>
		</li> 
			
			
			 <li>
		<a href="<?php echo base_url()?>admin/area/" class="expand level-closed">
			<i class=""></i> <span class="nav-label">
				Manage Area			</span> 
		</a> 
			<a href="<?php echo base_url()?>admin/banner/" class="expand level-closed">
			<i class=""></i> <span class="nav-label">
				Manage Banner			</span> 
		</a>
		<a href="<?php echo base_url()?>admin/category/" class="expand level-closed">
			<i class=""></i> <span class="nav-label">
				Manage Category			</span> 
		</a>
		<a href="<?php echo base_url()?>admin/managecms/" class="expand level-closed">
			<i class=""></i> <span class="nav-label">
				Manage CMS			</span> 
		</a>
		
		<a href="<?php echo base_url()?>admin/software/" class="expand level-closed">
			<i class=""></i> <span class="nav-label">
				Manage Software			</span> 
		</a>
			
		<a href="<?php echo base_url()?>admin/users/" class="expand level-closed">
			<i class=""></i> <span class="nav-label">
				Manage User			</span> 
		</a>
		
		<a href="<?php echo base_url()?>admin/course/" class="expand level-closed">
			<i class=""></i> <span class="nav-label">
				Course Management			</span> 
		</a>
		
		
		
					
			</li>
					
					
							
	</div>
</nav>	