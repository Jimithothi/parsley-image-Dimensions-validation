<!DOCTYPE html>
<html lang="en-US">
	<head>
		<meta charset="utf-8">
	</head>
	<body>
		<h2>Hello <?php echo $NICK_NAME ;?> , </h2>
		<p> Thank your for joining with our site </p>
		<p> Bellow is your account Info </p>
		<p>
			Email :  <?php echo $USER_NAME ?> <br />
			Password :  <?php echo $PWD ?><br />
		</p>
			<br /><br /><p> Thank You </p><br /><br />
		
		 <?php echo CNF_APPNAME ?> 
	</body>
</html>