	<div id="wrapper-content">
		<!-- PAGE WRAPPER-->
		<div id="page-wrapper">
			<!-- MAIN CONTENT-->
			<div class="main-content">
				<!-- CONTENT-->
				<div class="content">
					<div class="section background-opacity page-title set-height-top">
						<div class="container">
							<div class="page-title-wrapper">
								<!--.page-title-content-->
								<h2 class="captions"><?php echo $this->lang->line('core.contact'); ?></h2>
								
							</div>
						</div>
					</div>
					
					<div class="section section-padding contact-main">
						<div class="container">
							<div class="contact-main-wrapper">
								<div class="row contact-method">
									<div class="col-md-4">
										<div class="method-item">
											<i class="fa fa-map-marker"></i>

											<p class="sub">COME TO</p>

											<div class="detail">
												<p>Address Here</p>
											</div>
										</div>
									</div>
									<div class="col-md-4">
										<div class="method-item">
											<i class="fa fa-phone"></i>

											<p class="sub">CALL TO</p>

											<div class="detail">
												<p>Local: <?php echo  PHONE_CONTACT ;?></p>

												<p>Mobile: <?php echo  PHONE_CONTACT ;?></p>
											</div>
										</div>
									</div>
									<div class="col-md-4">
										<div class="method-item">
											<i class="fa fa-envelope"></i>

											<p class="sub">CONNECT TO</p>

											<div class="detail">
												<p><?php echo  CONTACT_MAIL ;?></p>

												<p>www.proyectarte.com</p>
											</div>
										</div>
									</div>
								</div>
								<form class="bg-w-form contact-form" method="post" action="<?php echo base_url()?>submitcontact">
									<div class="row">
									
									<div class="col-md-12">
											<div class="form-group">
											
												<?php if($this->session->flashdata('message')!=''){?>
												<div class="alert alert-success fade in">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <strong>Success!</strong> <?php echo $this->session->flashdata('message'); ?>
  </div>
			<?php }?>									
												
											</div>
										</div>
										
										
										<div class="col-md-6">
											<div class="form-group">
												<label class="control-label form-label"><?php echo $this->lang->line('core.name'); ?> <span
													class="highlight">*</span></label><input type="text" placeholder="" name="name"
													class="form-control form-input" required/>
												<!--label.control-label.form-label.warning-label(for="") Warning for the above !-->
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group">
												<label class="control-label form-label"><?php echo $this->lang->line('core.emails'); ?> <span
													class="highlight">*</span></label><input type="email" placeholder=""
													class="form-control form-input" name="email" required/>
												<!--label.control-label.form-label.warning-label(for="")-->
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group">
												<label class="control-label form-label"><?php echo $this->lang->line('core.purpose'); ?></label><select
													class="form-control form-input selectbox">
													<option value="">Please Select</option>
													<option value="">example 1</option>
													<option value="">example 2</option>
													<option value="">example 3</option>
												</select>
												<!--label.control-label.form-label.warning-label(for="", hidden)-->
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group">
												<label class="control-label form-label"><?php echo $this->lang->line('core.subject'); ?> <span
													class="highlight">*</span></label><input
													type="text" placeholder="" class="form-control form-input" name="subject" required/>
												<!--label.control-label.form-label.warning-label(for="", hidden)-->
											</div>
										</div>
										<div class="col-md-12">
											<div class="contact-question form-group">
												<label class="control-label form-label"><?php echo $this->lang->line('core.help_message'); ?> <span class="highlight">*</span>
												</label>
												<textarea class="form-control form-input" name="message" required></textarea>
											</div>
										</div>
									</div>
									<div class="contact-submit">
										<button type="submit" class="btn btn-contact btn-green">
											<span><?php echo $this->lang->line('core.btn_message'); ?></span>
										</button>
									</div>
								</form>
							</div>
						</div>
					</div>
					
				</div>
			</div>
		</div>
		<!-- BUTTON BACK TO TOP-->
		<div id="back-top">
			<a href="#top"><i class="fa fa-angle-double-up"></i></a>
		</div>
	</div>

	<?php $this->load->view('frontend/layouts/footerlang');?> <!-- footer view Load -->
		<script src="<?php echo base_url();?>assets/frontend/js/contact.js"></script>