	<div class="section choose-course-3">
						<div class="choose-course-3-wrapper row">
							<div class="testimonials-title-index">
								

								<h2 class="center-title">TESTIMONIALES</h2>

								<div class="bottom-title">
									<i class="bottom-icon icon-icon-04"></i>
								</div>
							</div>
							
							<div class="testmoniales">
							
								<div class="item-course-wrapper">
									<div>
										<i>
										<img src="<?php echo base_url();?>assets/image_test/Untitled.png" alt=""
																 />
																</i>
									</div>
									<div class="info-course">
										<a href="#" class="name-course">Victor Munoz</a>

										<div class="info">Enjoy the courses from home without schedules or deliveries. You set your own agenda.</div>
									</div>
								</div>
							</div>
							<div class="testmoniales">
								<div class="item-course-wrapper">
									<div>
										<i>
										<img src="<?php echo base_url();?>assets/image_test/Untitled1.png" alt=""
																 />
										</i>
									</div>
									<div class="info-course">
										<a href="#" class="name-course">Phillip Sprague</a>

										<div class="info">Videos of the highest quality so you do not miss detail. And as access is unlimited, you can watch them again and again.</div>
									</div>
								</div>
							</div>
							<div class="testmoniales">
								<div class="item-course-wrapper">
									<div>
										<i>
										<img src="<?php echo base_url();?>assets/image_test/Untitled2.png" alt=""
																class="icons-img" />
										</i>
									</div>
									<div class="info-course">
										<a href="#" class="name-course">German Carranza</a>

										<div class="info">Learn techniques and methods of great value explained by the great experts of the creative sector.</div>
									</div>
								</div>
							</div>
							<div class="testmoniales">
								<div class="item-course-wrapper">
									<div>
										<i>
										<img src="<?php echo base_url();?>assets/image_test/Untitled3.png" alt=""
																class="icons-img" />
										</i>
									</div>
									<a href="#" class="info-course">
										<div class="name-course">Sabrina Schvartz</div>
										<div class="info">Expose your doubts, ask for feedback, provides solutions. Share learning with other students in the community.</div>
									</a>
								</div>
							</div>
							<div class="testmoniales">
								<div class="item-course-wrapper">
									<div>
										<i>
										<img src="<?php echo base_url();?>assets/image_test/Untitled4.png" alt=""
																class="icons-img" />
										</i>
									</div>
									<div class="info-course">
										<a href="#" class="name-course">Isamar Rojas</a>

										<div class="info">Each teacher teaches only what he does best, ensuring convey passion and excellence in each lesson.</div>
									</div>
								</div>
							</div>
							<div class="testmoniales">
								<div class="item-course-wrapper">
									<div>
										<i>
										<img src="<?php echo base_url();?>assets/image_test/Untitled5.png" alt=""
																class="icons-img" />
										</i>
									</div>
									<div class="info-course">
										<a href="#" class="name-course">Jessica Cabrera</a>

										<div class="info">More than 300.000 creative and growing. Domestika is the place to share and learn what you love.</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				