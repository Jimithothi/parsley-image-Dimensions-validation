<!-- Annoucement -->
					<?php  $news=FrontendHelpers::annoucement();
if(count($news)>0){?>
<div class="section choose-course-3">
						<div class="choose-course-3-wrapper row">
						
<?php   foreach($news as $e): ?>
						
						<div class="item-course">
								<div class="item-course-wrapper">
									<div class="icon-course">
										<i>
										<img src="uploads/News/<?php echo $e->CMS_IMAGE?>" alt="" width="64px" height="67px"
																 />
																</i>
									</div>
									<div class="info-course">
									<?php if($this->session->userdata('lang')=='en'){?>
										<a class="name-course">
										
										<?php echo $e->CMS_TITLE_EN?></a>
<?php }
else {?>
<a class="name-course">
										
										<?php echo $e->CMS_TITLE_SP?></a>
<?php }?>

<?php if($this->session->userdata('lang')=='en'){?>
										<div class="info"><?php echo $e->CMS_DESC_EN?></div>
<?php }
else {?>
<div class="info"><?php echo $e->CMS_DESC_SP?></div>
<?php }?>
								
										
									</div>
								</div>
							</div>
							
							
						
						
						
													 		
   						
<?php endforeach; ?>
</div>
					</div>	
<?php }?>	
					
					
					<!-- End Annoucement -->
					