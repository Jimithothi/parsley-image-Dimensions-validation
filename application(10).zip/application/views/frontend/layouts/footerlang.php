<footer>

		<div class="footer-main">
			<div class="container">
				<div class="footer-main-wrapper">
					<div class="row">
						<div class="col-sm-12 col-md-10">
							<div class="row">

								<div class="col-md-3 col-xs-6 col-sm-3">
									<!-- USEFULL LINKS -->
									<div class="useful-link-widget widget">
										<div class="title-widget"><?php echo $this->lang->line('core.categories'); ?></div>
										<div class="content-widget">
											<div class="useful-link-list">
												<div class="row">
													<div class="col-md-12 col-sm-12 col-xs-12">
														<ul class="list-unstyled">
														 <?php  $category=FrontendHelpers::footer_category();
																 $software=FrontendHelpers::footer_software();
																 $area=FrontendHelpers::footer_area();
																 
															?>
														 <?php if(count($category)>0){?>
														 	 <?php   foreach($category as $e): ?>
														 	 <?php if($this->session->userdata('lang')=='en'){?>
														 		 <li><i class="fa fa-angle-right"></i><a href="<?php echo base_url()?>courses/category/<?php echo $e->URL_REWRITE_EN;?>"> <?php  echo $e->CATEGORY_NAME_EN; ?></a></li>
  															    <?php } else {?>
  															   
														 		 <li><i class="fa fa-angle-right"></i><a href="<?php echo base_url()?>courses/category/<?php echo $e->URL_REWRITE_SP;?>"> <?php  echo $e->CATEGORY_NAME_SP; ?></a></li>
  															    <?php }?>
   															 <?php endforeach; ?>
															<?php }?>
														</ul>
													</div>

												</div>
											</div>
										</div>
									</div>
								</div>

								<div class="col-md-3 col-xs-6 col-sm-3">
									<!-- USEFULL LINKS -->
									<div class="useful-link-widget widget">
										<div class="title-widget"><?php echo $this->lang->line('core.area'); ?></div>
										<div class="content-widget">
											<div class="useful-link-list">
												<div class="row">
													<div class="col-md-12 col-sm-12 col-xs-12">
														<ul class="list-unstyled">
															<ul class="list-unstyled">
														 <?php if(count($area)>0){?>
															 <?php   foreach($area as $e): ?>
															 <?php if($this->session->userdata('lang')=='en'){?>
														 		 <li><i class="fa fa-angle-right"></i><a href="<?php echo base_url()?>courses/area/<?php echo $e->URL_REWRITE_EN;?>"> <?php  echo $e->AREA_NAME_EN; ?></a></li>
  															   
  															    <?php } else {?>
  															       <li><i class="fa fa-angle-right"></i><a href="<?php echo base_url()?>courses/area/<?php echo $e->URL_REWRITE_SP;?>"> <?php  echo $e->AREA_NAME_SP; ?></a></li>
  															   
  															         <?php }?>
   															 <?php endforeach; ?>
   															 <?php }?>
														</ul>
													</div>

												</div>
											</div>
										</div>
									</div>
								</div>

								<div class="col-md-3 col-xs-6 col-sm-3">
									<!-- GALLERY -->
									<div class="useful-link-widget widget">
										<div class="title-widget"><?php echo $this->lang->line('core.software'); ?></div>
										<div class="content-widget">
											<div class="useful-link-list">
												<div class="row">
													<div class="col-md-12 col-sm-12 col-xs-12">
														<ul class="list-unstyled">
															<?php if(count($software)>0){?>
															 <?php   foreach($software as $e): ?>
															  <?php if($this->session->userdata('lang')=='en'){?>
														 		 <li><i class="fa fa-angle-right"></i><a href="<?php echo base_url()?>courses/software/<?php echo $e->URL_REWRITE_EN;?>"> <?php  echo $e->SOFTWARE_NAME_EN; ?></a></li>
  															   <?php } else {?>
  															    <li><i class="fa fa-angle-right"></i><a href="<?php echo base_url()?>courses/software/<?php echo $e->URL_REWRITE_SP;?>"> <?php  echo $e->SOFTWARE_NAME_SP; ?></a></li>
  															  
  															    <?php }?>
   															 <?php endforeach; ?>
   															 <?php }?>
														</ul>
													</div>

												</div>
											</div>
										</div>
									</div>
								</div>

								<div class="col-md-2 col-xs-4 col-sm-1">
									<!-- NEWS LETTER -->
									<div class="useful-link-widget widget">
										<div class="title-widget">Lists</div>
										<div class="content-widget">
											<div class="useful-link-list">
												<div class="row">
													<div class="col-md-12 col-sm-12 col-xs-12">
														<ul class="list-unstyled">
															<li><i class="fa fa-angle-right"></i><a href="<?php echo base_url()?>courses/recent">Recent
																	courses</a></li>
															<li><i class="fa fa-angle-right"></i><a href="<?php echo base_url()?>courses/high_rated">Highest
																	rated</a></li>
															<li><i class="fa fa-angle-right"></i><a href="<?php echo base_url()?>courses/popular">Popular
																	courses</a></li>
														</ul>
													</div>

												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>

						<div class="col-sm-12 col-md-2">
							<div class="edugate-widget widget">
								<div class="title-widget"><?php echo $this->lang->line('core.reach_us'); ?></div>
								<div class="content-widget">
									
									<div class="info-list">
										<ul class="list-unstyled">
											<li><i class="fa fa-envelope-o"></i><a href="#"> <?php echo  CONTACT_MAIL ;?></a></li>
											<li><i class="fa fa-phone"></i><a href="#">P: <?php echo  PHONE_CONTACT ;?></a></li>
											<li><i class="fa fa-map-marker"></i><a href="#"><p>Address Here</p></a></li>
										</ul>
									</div>
								</div>
							</div>
						</div>

					</div>
				</div>
				<div class="hyperlink">
					<div class="pull-left hyper-left">
						<ul class="list-inline">
							<li><a href="<?php echo base_url();?>"><?php echo $this->lang->line('core.home'); ?></a></li>
							<li><a href="<?php echo base_url()?>courses"><?php echo $this->lang->line('core.courses'); ?></a></li>
							<li><a href="<?php echo base_url()?>help"><?php echo $this->lang->line('core.help'); ?></a></li>
							<li><a href="<?php echo base_url()?>contact-us"><?php echo $this->lang->line('core.contact'); ?></a></li>
						</ul>

					</div>
					<div class="pull-right hyper-right">
						<div class="socials">
							<a href="<?php echo  FB_PAGE ;?>" class="facebook"><i class="fa fa-facebook"></i></a><a
								href="<?php echo  GOOGLE_PLUS ;?>" class="google"><i class="fa fa-google-plus"></i></a><a
								href="<?php echo  TWITTER ;?>" class="twitter"><i class="fa fa-twitter"></i></a>
							<div class="pull-right hyper-right"></div>
							<div class="pull-right hyper-right">
								<div class="dropup">
									<button class="btn btn-default dropdown-toggle" type="button"
										data-toggle="dropdown">
										Language<span class="caret"></span>
									</button>
									<ul class="dropdown-menu">
										<?php foreach(SiteHelpers::langOption() as $lang) : ?>
					<li><a href="<?php echo site_url('home/lang/'.$lang['folder']);?>" style="background-color: white !important"><img src="<?php echo base_url()?><?php echo $lang['flag']?>" width="25"> <?php echo $lang['name'] ;?></a></li>
				<?php endforeach;?>	
									</ul>
								</div>
							</div>
						</div>
					</div>
					<!-- <div class="pull-right hyper-right">@ SWLABS</div> -->
				</div>
			</div>
		</div>
	</footer>
	