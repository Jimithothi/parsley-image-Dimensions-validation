<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * @package     CodeIgniter
 * @author      Ikraftsolutions
 * @copyright   Copyright (c) Ikraftsolutions (http://ikraftsolutions.com)
 * @version 1.0
 */

class Courses extends SB_Controller
{
	protected $layout = "frontend/layouts/main";
	public $pmodule		= 'courses';
	public $per_page	= COURSE_PAGINATION;
	public $comment_per_page=2;
	
	function __construct()
	{
		parent::__construct();
		$this->load->model('coursesmodel');
		$this->model = $this->coursesmodel;
		
		$this->load->model('admin/coursemodel');
		$this->cmodel = $this->coursemodel;
		
		$this->data = array_merge( $this->data, array(
			
				'pageModule'	=> 'courses',
		));
	}
	
	function index()
	{
		/***************************************************/
		/////////////	SEARCHING //////////////////////////
		
		$category = (!is_null($this->input->get('category', true)) ? $this->input->get('category', true) : NULL);
		$area = (!is_null($this->input->get('area', true)) ? $this->input->get('area', true) : NULL);
		$software = (!is_null($this->input->get('software', true)) ? $this->input->get('software', true) : NULL);
		
		log_message('info', "CATEGORY :::::: ".$category);
		log_message('info', "AREA ::::: ".$area);
		log_message('info', "SOFTWARE ::::::: ".$software);
		
		
		$serachCondition='';
		
		if ($category!='')
		{
			
			$whereCat="URL_REWRITE_EN ='".$category."' OR URL_REWRITE_SP='".$category."'";
			
			$category= $this->model->Search('category_master',$whereCat);
			$serachCondition.='(AREA_CAT_SOFTWARE_ID='.$category[0]['CATEGORY_ID'].' AND TYPE="CATEGORY")';
		}
		if ($area!='')
		{
			if($category!='')
			{
				$whereArea="URL_REWRITE_EN ='".$area."' OR URL_REWRITE_SP='".$area."'";
					
				$area= $this->model->Search('area_master',$whereArea);
				$serachCondition.=' OR (AREA_CAT_SOFTWARE_ID='.$area[0]['AREA_ID'].' AND TYPE="AREA") ';
			}
			else 
			{
				$whereArea="URL_REWRITE_EN ='".$area."' OR URL_REWRITE_SP='".$area."'";
				
				$area= $this->model->Search('area_master',$whereArea);
				$serachCondition.=' (AREA_CAT_SOFTWARE_ID='.$area[0]['AREA_ID'].' AND TYPE="AREA") ';
			}
		}
		
		if ($software!='')
		{
			if($area!='')
			{
					$whereSoft="URL_REWRITE_EN ='".$software."' OR URL_REWRITE_SP='".$software."'";
					
					$software= $this->model->Search('software_master',$whereSoft);
					$serachCondition.=' OR (AREA_CAT_SOFTWARE_ID='.$software[0]['SOFTWARE_ID'].' AND TYPE="SOFTWARE") ';
			}
			else 
			{
				if($category!='')
				{
					$whereSoft="URL_REWRITE_EN ='".$software."' OR URL_REWRITE_SP='".$software."'";
						
					$software= $this->model->Search('software_master',$whereSoft);
					$serachCondition.=' OR (AREA_CAT_SOFTWARE_ID='.$software[0]['SOFTWARE_ID'].' AND TYPE="SOFTWARE") ';
				}
				else
				{
					$whereSoft="URL_REWRITE_EN ='".$software."' OR URL_REWRITE_SP='".$software."'";
						
					$software= $this->model->Search('software_master',$whereSoft);
					$serachCondition.=' (AREA_CAT_SOFTWARE_ID='.$software[0]['SOFTWARE_ID'].' AND TYPE="SOFTWARE") ';
				}
			}
			
		}	
		
	
		
		if($serachCondition!=''){
			$searchcourse=$this->model->searchCourse($serachCondition);
		}
		else 
		{
			//$searchcourse=$this->model->getcourses($params);
			
			
			
			$page = max(1, (int) $this->input->get('page', 1));
			
			
			$params = array(
					'page'		=> $page ,
					'limit'		=> ( $this->per_page ) ,
						
			);
				
			//$searchcourses=$this->model->get_recent_courses($params);
			
			$searchcourses=$this->model->getcourses($params);
				
			$total=$this->model->record_count();
				
			$pagination = $this->paginatorcourse( array(
					'total_rows' => $total ,
					'per_page'	 => $params['limit']
			),$module='courses');
				
			$this->data['pagination']	= $pagination;
				
				
			$searchcourse = json_decode(json_encode($searchcourses),true);
			
		}	
		
		
		for ($i=0;$i<count($searchcourse);$i++)
		{
			$data=array(
					'COURSE_ID'=>$searchcourse[$i]['COURSE_ID'],
					'INACTIVE'=>'1'
			);
			$result[$i] = $this->db->get_where('course_master',$data)->row_array();
		}
		
		/////////////	END SEARCHING ///////////////////////
		/***************************************************/
		
		for($i=0;$i<count($result);$i++)
		{
			$courseName[$i]=SiteHelpers::seoUrl($result[$i]['COURSE_NAME'],'dash');
		}
		
		$this->data['courseName']=$courseName;
		
		for($i=0;$i<count($result);$i++)
		{
			$courseCover[$i]=$this->model->courseCover($result[$i]['COURSE_ID']);
			
		}
		
		
		
		$this->data['courseCover']=$courseCover;
		
		/*
		 * 
		 * 
		for($i=0;$i<count($result);$i++)
		{
				
			$countComment[$i]=$this->model->countComment($result[$i]['COURSE_ID']);
			$totalcourseUser[$i]=$this->model->totaluser($result[$i]['COURSE_ID']);
		}
		$this->data['countComment']=$countComment;
		
		$this->data['totalcourseUser']=$totalcourseUser;
		**/
		
		for($i=0;$i<count($result);$i++)
		{
			$shortContent[$i]=$this->model->getLatestcoursecontent($result[$i]['COURSE_ID']);
		}
		$this->data['result']=$result;
		if(count($result)!=null){
		$this->data['shortContent']=$shortContent;
		}
		
		$this->data['category']=$this->cmodel->getSelectbox('category_master');
		$this->data['software']=$this->cmodel->getSelectbox('software_master');
		$this->data['area']=$this->cmodel->getSelectbox('area_master');

		
		$this->data['content']= $this->load->view('frontend/courses/index',$this->data, TRUE);
		$this->load->view($this->layout, $this->data );
	}
	
	function view($page = null)
	{
		$courseURI=$page;
		$page= str_replace('-',' ',urldecode($page));

		$result=$this->model->getcourse($page);
		
		if(count($result)==0)
		{
			show_404();
		}
		else 
		{
			$this->data['row']=$result;
			
			$content=$this->model->getCoursecontent($result['COURSE_ID']);
			
			$unitInformation=$this->model->getUnits($result['COURSE_ID']);
			
			for($i=0;$i<count($unitInformation);$i++)
			{
				$subunit[$i]=$this->model->subunit($unitInformation[$i]['UNIT_ID']);
			}
			
			/*******************
			* Course Mapping
			/******************/
			$dataCategory=array(
					'COURSE_ID'=>$result['COURSE_ID'],
					'TYPE'=>'CATEGORY',
			);
			$dataSoftware=array(
					'COURSE_ID'=>$result['COURSE_ID'],
					'TYPE'=>'SOFTWARE',
			);
			$dataArea=array(
					'COURSE_ID'=>$result['COURSE_ID'],
					'TYPE'=>'AREA',
			);
			$checkCategory=$this->cmodel->getCheckSelectbox('course_area_category_mapping',$dataCategory);
			$checkSoftware=$this->cmodel->getCheckSelectbox('course_area_category_mapping',$dataSoftware);
			$checkArea=$this->cmodel->getCheckSelectbox('course_area_category_mapping',$dataArea);
			
			

			$recommended_courses_id=$this->model->recommended_courses_id($result['COURSE_ID']);
			
			for($i=0;$i<count($recommended_courses_id);$i++)
			{
				$recommended_courses[$i]=$this->model->recommended_courses($recommended_courses_id[$i]['COURSE_ID']);
			}
			
			
			for($i=0;$i<count($recommended_courses);$i++)
			{
				$courseName[$i]=SiteHelpers::seoUrl($recommended_courses[$i][0]['COURSE_NAME'],'dash');
			}
			
			
			$this->data['courseName']=$courseName;
			
			
			$this->data['recommended_courses']=$recommended_courses;

			
			for($i=0;$i<count($checkArea);$i++)
			{
				$courseArea[$i]=$this->model->courseMapping('area_master',$checkArea[$i]['AREA_CAT_SOFTWARE_ID'],$type="AREA_ID");
			}
			
			for($i=0;$i<count($checkCategory);$i++)
			{
				$courseCategory[$i]=$this->model->courseMapping('category_master',$checkCategory[$i]['AREA_CAT_SOFTWARE_ID'],$type="CATEGORY_ID");
			}
			
			for($i=0;$i<count($checkSoftware);$i++)
			{
				$courseSoftware[$i]=$this->model->courseMapping('software_master',$checkSoftware[$i]['AREA_CAT_SOFTWARE_ID'],$type="SOFTWARE_ID");
			}
			if(isset($courseArea))
			{
					$this->data['courseArea']=$courseArea;
			}
			
			if(isset($courseCategory))
			{
				
				$this->data['courseCategory']=$courseCategory;
			}
			if(isset($courseSoftware))
			{
				$this->data['courseSoftware']=$courseSoftware;
			}
			
			/*****************/
			
			/*********************
			 * Review & Users Count
			 ********************/
			$this->data['countComment']=$this->model->countComment($result['COURSE_ID']);
			$this->data['totalcourseUser']=$this->model->totaluser($result['COURSE_ID']);
			
			
			$page = max(1, (int) $this->input->get('page', 1));
			
			
			$params = array(
					'page'		=> $page ,
					'limit'		=> ( $this->comment_per_page ) ,
						
			);
				
			$comment=$this->model->courseReview($result['COURSE_ID'],$params);
				
			$total=$this->model->countComment($result['COURSE_ID']);
				
			$pagination = $this->paginatorcourse( array(
					'total_rows' => $total ,
					'per_page'	 => $params['limit']
			),$module='courses/'.SiteHelpers::seoUrl($result['COURSE_NAME'],'dash').'/review');
				
			$this->data['pagination']	= $pagination;
			
			
			/*echo "<pre>";
			print_r($params);
			echo "</pre>";
			
			echo "##########################";
				
			echo "<pre>";
		print_r($pagination);
		echo "</pre>";
		
		exit;
		*/	
			
			
			/*******************/
			$this->data['reviews']=$comment;
			if(isset($unitInformation)>0){
				$this->data['units']=$unitInformation;
			}
			
			if(isset($subunit)>0){
			$this->data['subunits']=$subunit;
			}
			
			/******************************
			*  ENROLL
			******************************/
			
			$enrollCourse=array(
				'COURSE_ID'		=> $result['COURSE_ID'],
				'USER_ID'		=> $this->session->userdata('userId')
					
			);
			
			$row = $this->db->get_where('user_course_enroll',$enrollCourse)->row();
			
			$this->data['enrollcourse']=count($row);
			$this->data['courseURI']=$courseURI;
			/*****************************/
			
			$this->data['courseContent']=$content;
			$this->data['category']=$this->cmodel->getSelectbox('category_master');
			$this->data['software']=$this->cmodel->getSelectbox('software_master');
			$this->data['area']=$this->cmodel->getSelectbox('area_master');
			$this->data['content']= $this->load->view('frontend/courses/view',$this->data, TRUE);
			$this->load->view($this->layout, $this->data );
		}
	}
	
	function enroll_course()
	{
		
		if($this->session->userdata('userId')!='')
		{
			$data=array(
				'COURSE_ID'				=> $this->input->post('courseID'),
				'USER_ID'				=> $this->session->userdata('userId'),
				'COURSE_ENROLL_DATE'	=> now()
			);
		
			$this->db->insert('user_course_enroll', $data);
			
			
			$where=array(
					'COURSE_ID'	=>$this->input->post('courseID'),
			);
				
			$Data = $this->db->get_where('course_master',$where)->row_array();
				
			if($Data['USER_TOT_ENROLL']=='')
			{
				$courseUserUpdate=1;
			}
			else
			{
				$courseUserUpdate=$Data['USER_TOT_ENROLL']+1;
			}
				
			$usercountupdate=array(
					'USER_TOT_ENROLL'	=>$courseUserUpdate
			);
				
			$this->db->where('COURSE_ID',$this->input->post('courseID'));
			$this->db->update('course_master',$usercountupdate);
				
		
		}
		else 
		{
			SiteHelpers::alert('error'," Please Login after you can Enroll course");
		}
		
		redirect('courses/'.$this->input->post('courseName'));
		
		
		//exit;
	}
	
	function postreview()
	{
			$courseId=$this->input->post('COURSE_ID');
			$userID=$this->session->userdata('userId');
			$comment=$this->input->post('comment');
			
			$data=array(
					'USER_ID'=>$userID,
					'COURSE_ID'=>$courseId,
					'COMMENT'=>$comment,
					'CREATED_DATE'=>now(),
					'INACTIVE'=>'1'
			);
			
			$this->db->insert('course_review',$data);
			
			$where=array(
				'COURSE_ID'	=>$courseId,
			);
			
			$Data = $this->db->get_where('course_master',$where)->row_array();
			
			if($Data['USER_TOT_COMMENT']=='')
			{
				$courseCntUpdate=1;
			}
			else 
			{
				$courseCntUpdate=$Data['USER_TOT_COMMENT']+1;
			}
			
			$cmtcountupdate=array(
				'USER_TOT_COMMENT'	=>$courseCntUpdate	
			);
			
			$this->db->where('COURSE_ID',$courseId);
			$this->db->update('course_master',$cmtcountupdate);
			
			
			
			redirect($_SERVER['HTTP_REFERER']);
	}

	function category($category = null)
	{
		$where="URL_REWRITE_EN ='".$category."' OR URL_REWRITE_SP='".$category."'";
		
		$Data = $this->db->get_where('category_master',$where)->row_array();
		
		
		if($this->session->userdata('lang')=='en')
		{
			
			
			$catData=array(
					'URL_REWRITE_EN'=>$Data['URL_REWRITE_EN']
			);
		}
		else 
		{
			
			
			$catData=array(
					'URL_REWRITE_SP'=>$Data['URL_REWRITE_SP']
			);
		}
		
		$row = $this->db->get_where('category_master',$catData)->row_array();
		
		

		$serachCondition='(AREA_CAT_SOFTWARE_ID='.$row['CATEGORY_ID'].' AND TYPE="CATEGORY")';
		
		
		$page = max(1, (int) $this->input->get('page', 1));
		
		
		$params = array(
				'page'		=> $page ,
				'limit'		=> ( $this->per_page ) ,
					
		);
			
		
		$searchcourses=$this->model->searchCourselist($serachCondition,$params);
			
		
		$total=$this->model->record_count_list($serachCondition);
		
		
		//echo $total;
			
		$pagination = $this->paginatorcourse( array(
				'total_rows' => $total ,
				'per_page'	 => $params['limit']
		),$module='courses/category/'.$category);
			
		$this->data['pagination']	= $pagination;
			
		
			
		$searchcourse = json_decode(json_encode($searchcourses),true);
		
		
		
		//$searchcourse=$this->model->searchCourse($serachCondition);
		
		for ($i=0;$i<count($searchcourse);$i++)
		{
			$data=array(
					'COURSE_ID'=>$searchcourse[$i]['COURSE_ID'],
					'INACTIVE'=>'1'
			);
			$result[$i] = $this->db->get_where('course_master',$data)->row_array();
		}
		if(count($searchcourse)>0){
		
		for($i=0;$i<count($result);$i++)
		{
			$courseName[$i]=SiteHelpers::seoUrl($result[$i]['COURSE_NAME'],'dash');
		}
		
		$this->data['courseName']=$courseName;
		
		for($i=0;$i<count($result);$i++)
		{
			$courseCover[$i]=$this->model->courseCover($result[$i]['COURSE_ID']);
		}
		
		
		
		$this->data['courseCover']=$courseCover;
		
		for($i=0;$i<count($result);$i++)
		{
		
			$countComment[$i]=$this->model->countComment($result[$i]['COURSE_ID']);
		}
		$this->data['countComment']=$countComment;
		
		for($i=0;$i<count($result);$i++)
		{
			$shortContent[$i]=$this->model->getLatestcoursecontent($result[$i]['COURSE_ID']);
		}
		
		$this->data['result']=$result;
		if(count($result)!=null){
			$this->data['shortContent']=$shortContent;
		}
		}
		$this->data['category']=$this->cmodel->getSelectbox('category_master');
		$this->data['software']=$this->cmodel->getSelectbox('software_master');
		$this->data['area']=$this->cmodel->getSelectbox('area_master');
		
		$this->data['content']= $this->load->view('frontend/courses/index',$this->data, TRUE);
		$this->load->view($this->layout, $this->data );
		
		
	}
	
	function software($software = null)
	{
		$where="URL_REWRITE_EN ='".$software."' OR URL_REWRITE_SP='".$software."'";
		
		$Data = $this->db->get_where('software_master',$where)->row_array();
		
		if($this->session->userdata('lang')=='en')
		{
			$catData=array(
					'URL_REWRITE_EN'=>$Data['URL_REWRITE_EN']
			);
		}
		else
		{
			$catData=array(
					'URL_REWRITE_SP'=>$Data['URL_REWRITE_SP']
			);
		}
		
		$row = $this->db->get_where('software_master',$catData)->row_array();
		
		
		$serachCondition='(AREA_CAT_SOFTWARE_ID='.$row['SOFTWARE_ID'].' AND TYPE="SOFTWARE")';
		
		
		$page = max(1, (int) $this->input->get('page', 1));
		
		
		$params = array(
				'page'		=> $page ,
				'limit'		=> ( $this->per_page ) ,
					
		);
			
		
		$searchcourses=$this->model->searchCourselist($serachCondition,$params);
			
		
		$total=$this->model->record_count_list($serachCondition);
		
		
		//echo $total;
			
		$pagination = $this->paginatorcourse( array(
				'total_rows' => $total ,
				'per_page'	 => $params['limit']
		),$module='courses/software/'.$software);
			
		$this->data['pagination']	= $pagination;
			
		
			
		$searchcourse = json_decode(json_encode($searchcourses),true);
		
		
		
		
		
	//	$searchcourse=$this->model->searchCourse($serachCondition);
		
		for ($i=0;$i<count($searchcourse);$i++)
		{
			$data=array(
					'COURSE_ID'=>$searchcourse[$i]['COURSE_ID'],
					'INACTIVE'=>'1'
			);
			$result[$i] = $this->db->get_where('course_master',$data)->row_array();
		}
		if(count($searchcourse)>0){
		
			for($i=0;$i<count($result);$i++)
			{
				$courseName[$i]=SiteHelpers::seoUrl($result[$i]['COURSE_NAME'],'dash');
			}
		
			$this->data['courseName']=$courseName;
		
			for($i=0;$i<count($result);$i++)
			{
				$courseCover[$i]=$this->model->courseCover($result[$i]['COURSE_ID']);
			}
		
		
		
			$this->data['courseCover']=$courseCover;
		
			for($i=0;$i<count($result);$i++)
			{
		
				$countComment[$i]=$this->model->countComment($result[$i]['COURSE_ID']);
			}
			$this->data['countComment']=$countComment;
		
			for($i=0;$i<count($result);$i++)
			{
				$shortContent[$i]=$this->model->getLatestcoursecontent($result[$i]['COURSE_ID']);
			}
		
			$this->data['result']=$result;
			if(count($result)!=null){
				$this->data['shortContent']=$shortContent;
			}
		}
		$this->data['category']=$this->cmodel->getSelectbox('category_master');
		$this->data['software']=$this->cmodel->getSelectbox('software_master');
		$this->data['area']=$this->cmodel->getSelectbox('area_master');
		
		$this->data['content']= $this->load->view('frontend/courses/index',$this->data, TRUE);
		$this->load->view($this->layout, $this->data );
		
		
		
		
	}
	
	function area($area=null)
	{
		$where="URL_REWRITE_EN ='".$area."' OR URL_REWRITE_SP='".$area."'";
		
		$Data = $this->db->get_where('area_master',$where)->row_array();
		
		if($this->session->userdata('lang')=='en')
		{
			$catData=array(
					'URL_REWRITE_EN'=>$Data['URL_REWRITE_EN']
			);
		}
		else
		{
			$catData=array(
					'URL_REWRITE_SP'=>$Data['URL_REWRITE_SP']
			);
		}
		
		$row = $this->db->get_where('area_master',$catData)->row_array();
		
		
		$serachCondition='(AREA_CAT_SOFTWARE_ID='.$row['AREA_ID'].' AND TYPE="AREA")';
		
		
		
		$page = max(1, (int) $this->input->get('page', 1));
		
		
		$params = array(
				'page'		=> $page ,
				'limit'		=> ( $this->per_page ) ,
					
		);
			
		
		$searchcourses=$this->model->searchCourselist($serachCondition,$params);
			
		
		$total=$this->model->record_count_list($serachCondition);
		
		
		//echo $total;
			
		$pagination = $this->paginatorcourse( array(
				'total_rows' => $total ,
				'per_page'	 => $params['limit']
		),$module='courses/area/'.$area);
			
		$this->data['pagination']	= $pagination;
			
		$searchcourse = json_decode(json_encode($searchcourses),true);
		
		for ($i=0;$i<count($searchcourse);$i++)
		{
			$data=array(
					'COURSE_ID'=>$searchcourse[$i]['COURSE_ID'],
					'INACTIVE'=>'1'
			);
			$result[$i] = $this->db->get_where('course_master',$data)->row_array();
		}
		if(count($searchcourse)>0){
		
			for($i=0;$i<count($result);$i++)
			{
				$courseName[$i]=SiteHelpers::seoUrl($result[$i]['COURSE_NAME'],'dash');
			}
		
			$this->data['courseName']=$courseName;
		
			for($i=0;$i<count($result);$i++)
			{
				$courseCover[$i]=$this->model->courseCover($result[$i]['COURSE_ID']);
			}
		
		
		
			$this->data['courseCover']=$courseCover;
		
			for($i=0;$i<count($result);$i++)
			{
		
				$countComment[$i]=$this->model->countComment($result[$i]['COURSE_ID']);
			}
			$this->data['countComment']=$countComment;
		
			for($i=0;$i<count($result);$i++)
			{
				$shortContent[$i]=$this->model->getLatestcoursecontent($result[$i]['COURSE_ID']);
			}
		
			$this->data['result']=$result;
			if(count($result)!=null){
				$this->data['shortContent']=$shortContent;
			}
		}
		$this->data['category']=$this->cmodel->getSelectbox('category_master');
		$this->data['software']=$this->cmodel->getSelectbox('software_master');
		$this->data['area']=$this->cmodel->getSelectbox('area_master');
		
		$this->data['content']= $this->load->view('frontend/courses/index',$this->data, TRUE);
		$this->load->view($this->layout, $this->data );
		
		
	}
	
	function popular()
	{
		/***************************************************/
		/////////////	SEARCHING //////////////////////////
		
		$category = (!is_null($this->input->get('category', true)) ? $this->input->get('category', true) : NULL);
		$area = (!is_null($this->input->get('area', true)) ? $this->input->get('area', true) : NULL);
		$software = (!is_null($this->input->get('software', true)) ? $this->input->get('software', true) : NULL);
		
		
		$serachCondition='';
		
		if ($category!='')
		{
				
			$whereCat="URL_REWRITE_EN ='".$category."' OR URL_REWRITE_SP='".$category."'";
				
			$category= $this->model->Search('category_master',$whereCat);
			$serachCondition.='(AREA_CAT_SOFTWARE_ID='.$category[0]['CATEGORY_ID'].' AND TYPE="CATEGORY")';
		}
		if ($area!='')
		{
			if($category!='')
			{
				$whereArea="URL_REWRITE_EN ='".$area."' OR URL_REWRITE_SP='".$area."'";
					
				$area= $this->model->Search('area_master',$whereArea);
				$serachCondition.=' OR (AREA_CAT_SOFTWARE_ID='.$area[0]['AREA_ID'].' AND TYPE="AREA") ';
			}
			else
			{
				$whereArea="URL_REWRITE_EN ='".$area."' OR URL_REWRITE_SP='".$area."'";
		
				$area= $this->model->Search('area_master',$whereArea);
				$serachCondition.=' (AREA_CAT_SOFTWARE_ID='.$area[0]['AREA_ID'].' AND TYPE="AREA") ';
			}
		}
		
		if ($software!='')
		{
			if($area!='')
			{
				$whereSoft="URL_REWRITE_EN ='".$software."' OR URL_REWRITE_SP='".$software."'";
					
				$software= $this->model->Search('software_master',$whereSoft);
				$serachCondition.=' OR (AREA_CAT_SOFTWARE_ID='.$software[0]['SOFTWARE_ID'].' AND TYPE="SOFTWARE") ';
			}
			else
			{
				if($category!='')
				{
					$whereSoft="URL_REWRITE_EN ='".$software."' OR URL_REWRITE_SP='".$software."'";
		
					$software= $this->model->Search('software_master',$whereSoft);
					$serachCondition.=' OR (AREA_CAT_SOFTWARE_ID='.$software[0]['SOFTWARE_ID'].' AND TYPE="SOFTWARE") ';
				}
				else
				{
					$whereSoft="URL_REWRITE_EN ='".$software."' OR URL_REWRITE_SP='".$software."'";
		
					$software= $this->model->Search('software_master',$whereSoft);
					$serachCondition.=' (AREA_CAT_SOFTWARE_ID='.$software[0]['SOFTWARE_ID'].' AND TYPE="SOFTWARE") ';
				}
			}
				
		}
		if($serachCondition!=''){
			$searchcourse=$this->model->searchCourse($serachCondition);
		}
		else
		{
			//$searchcourse=$this->model->get_popular_courses($params);
			

			$page = max(1, (int) $this->input->get('page', 1));
				
				
			$params = array(
					'page'		=> $page ,
					'limit'		=> ( $this->per_page ) ,
			
			);
			
			//$searchcourses=$this->model->get_recent_courses($params);
				
			$searchcourses=$this->model->get_popular_courses($params);
			
			$total=$this->model->record_count();
			
			$pagination = $this->paginatorcourse( array(
					'total_rows' => $total ,
					'per_page'	 => $params['limit']
			),$module='courses/popular');
			
			$this->data['pagination']	= $pagination;
			
			
			$searchcourse = json_decode(json_encode($searchcourses),true);
						
		}
		
		for ($i=0;$i<count($searchcourse);$i++)
		{
			$data=array(
					'COURSE_ID'=>$searchcourse[$i]['COURSE_ID'],
					'INACTIVE'=>'1'
			);
			$result[$i] = $this->db->get_where('course_master',$data)->row_array();
		}
		
		/////////////	END SEARCHING ///////////////////////
		/***************************************************/
		
		for($i=0;$i<count($result);$i++)
		{
			$courseName[$i]=SiteHelpers::seoUrl($result[$i]['COURSE_NAME'],'dash');
		}
		
		$this->data['courseName']=$courseName;
		
		for($i=0;$i<count($result);$i++)
		{
			$courseCover[$i]=$this->model->courseCover($result[$i]['COURSE_ID']);
				
		}
	
		$this->data['courseCover']=$courseCover;
		
		for($i=0;$i<count($result);$i++)
		{
		
			$countComment[$i]=$this->model->countComment($result[$i]['COURSE_ID']);
			$totalcourseUser[$i]=$this->model->totaluser($result[$i]['COURSE_ID']);
		}
		$this->data['countComment']=$countComment;
		
		$this->data['totalcourseUser']=$totalcourseUser;
		
		
		for($i=0;$i<count($result);$i++)
		{
			$shortContent[$i]=$this->model->getLatestcoursecontent($result[$i]['COURSE_ID']);
		}
		$this->data['result']=$result;
		if(count($result)!=null){
			$this->data['shortContent']=$shortContent;
		}
		
		
		
		$this->data['category']=$this->cmodel->getSelectbox('category_master');
		$this->data['software']=$this->cmodel->getSelectbox('software_master');
		$this->data['area']=$this->cmodel->getSelectbox('area_master');
		
		$this->data['List_course']="popular course";
		
		$this->data['content']= $this->load->view('frontend/courses/lists',$this->data, TRUE);
		$this->load->view($this->layout, $this->data );
		
	}
	
	function high_rated()
	{
		/***************************************************/
		/////////////	SEARCHING //////////////////////////
		
		$category = (!is_null($this->input->get('category', true)) ? $this->input->get('category', true) : NULL);
		$area = (!is_null($this->input->get('area', true)) ? $this->input->get('area', true) : NULL);
		$software = (!is_null($this->input->get('software', true)) ? $this->input->get('software', true) : NULL);
		
		
		$serachCondition='';
		
		if ($category!='')
		{
		
			$whereCat="URL_REWRITE_EN ='".$category."' OR URL_REWRITE_SP='".$category."'";
		
			$category= $this->model->Search('category_master',$whereCat);
			$serachCondition.='(AREA_CAT_SOFTWARE_ID='.$category[0]['CATEGORY_ID'].' AND TYPE="CATEGORY")';
		}
		if ($area!='')
		{
			if($category!='')
			{
				$whereArea="URL_REWRITE_EN ='".$area."' OR URL_REWRITE_SP='".$area."'";
					
				$area= $this->model->Search('area_master',$whereArea);
				$serachCondition.=' OR (AREA_CAT_SOFTWARE_ID='.$area[0]['AREA_ID'].' AND TYPE="AREA") ';
			}
			else
			{
				$whereArea="URL_REWRITE_EN ='".$area."' OR URL_REWRITE_SP='".$area."'";
		
				$area= $this->model->Search('area_master',$whereArea);
				$serachCondition.=' (AREA_CAT_SOFTWARE_ID='.$area[0]['AREA_ID'].' AND TYPE="AREA") ';
			}
		}
		
		if ($software!='')
		{
			if($area!='')
			{
				$whereSoft="URL_REWRITE_EN ='".$software."' OR URL_REWRITE_SP='".$software."'";
					
				$software= $this->model->Search('software_master',$whereSoft);
				$serachCondition.=' OR (AREA_CAT_SOFTWARE_ID='.$software[0]['SOFTWARE_ID'].' AND TYPE="SOFTWARE") ';
			}
			else
			{
				if($category!='')
				{
					$whereSoft="URL_REWRITE_EN ='".$software."' OR URL_REWRITE_SP='".$software."'";
		
					$software= $this->model->Search('software_master',$whereSoft);
					$serachCondition.=' OR (AREA_CAT_SOFTWARE_ID='.$software[0]['SOFTWARE_ID'].' AND TYPE="SOFTWARE") ';
				}
				else
				{
					$whereSoft="URL_REWRITE_EN ='".$software."' OR URL_REWRITE_SP='".$software."'";
		
					$software= $this->model->Search('software_master',$whereSoft);
					$serachCondition.=' (AREA_CAT_SOFTWARE_ID='.$software[0]['SOFTWARE_ID'].' AND TYPE="SOFTWARE") ';
				}
			}
		
		}
		if($serachCondition!=''){
			$searchcourse=$this->model->searchCourse($serachCondition);
		}
		else
		{
			//$searchcourse=$this->model->get_highest_rated_courses();
			
			
			$page = max(1, (int) $this->input->get('page', 1));
			
			
			$params = array(
					'page'		=> $page ,
					'limit'		=> ( $this->per_page ) ,
			);
				
			//$searchcourses=$this->model->get_recent_courses($params);
			
			$searchcourses=$this->model->get_highest_rated_courses($params);
				
			$total=$this->model->record_count();
				
			$pagination = $this->paginatorcourse( array(
					'total_rows' => $total ,
					'per_page'	 => $params['limit']
			),$module='courses/high_rated');
				
			$this->data['pagination']	= $pagination;
				
				
			$searchcourse = json_decode(json_encode($searchcourses),true);
				
				
			
			
			
		}
		
		for ($i=0;$i<count($searchcourse);$i++)
		{
			$data=array(
					'COURSE_ID'=>$searchcourse[$i]['COURSE_ID'],
					'INACTIVE'=>'1'
			);
			$result[$i] = $this->db->get_where('course_master',$data)->row_array();
		}
		
		/////////////	END SEARCHING ///////////////////////
		/***************************************************/
		
		for($i=0;$i<count($result);$i++)
		{
			$courseName[$i]=SiteHelpers::seoUrl($result[$i]['COURSE_NAME'],'dash');
		}
		
		$this->data['courseName']=$courseName;
		
		for($i=0;$i<count($result);$i++)
		{
			$courseCover[$i]=$this->model->courseCover($result[$i]['COURSE_ID']);
		
		}
		
		$this->data['courseCover']=$courseCover;
		
		for($i=0;$i<count($result);$i++)
		{
			$countComment[$i]=$this->model->countComment($result[$i]['COURSE_ID']);
			$totalcourseUser[$i]=$this->model->totaluser($result[$i]['COURSE_ID']);
		}
		
		$this->data['countComment']=$countComment;
		
		$this->data['totalcourseUser']=$totalcourseUser;
		
		for($i=0;$i<count($result);$i++)
		{
			$shortContent[$i]=$this->model->getLatestcoursecontent($result[$i]['COURSE_ID']);
		}
		$this->data['result']=$result;
		if(count($result)!=null){
			$this->data['shortContent']=$shortContent;
		}
		
		$this->data['category']=$this->cmodel->getSelectbox('category_master');
		$this->data['software']=$this->cmodel->getSelectbox('software_master');
		$this->data['area']=$this->cmodel->getSelectbox('area_master');
		
		$this->data['List_course']="high rated course";
		
		$this->data['content']= $this->load->view('frontend/courses/lists',$this->data, TRUE);
		$this->load->view($this->layout, $this->data );
		
	}
	function recent()
	{
		/***************************************************/
		/////////////	SEARCHING //////////////////////////
		
		$category = (!is_null($this->input->get('category', true)) ? $this->input->get('category', true) : NULL);
		$area = (!is_null($this->input->get('area', true)) ? $this->input->get('area', true) : NULL);
		$software = (!is_null($this->input->get('software', true)) ? $this->input->get('software', true) : NULL);
		
		
		$serachCondition='';
		
		if ($category!='')
		{
		
			$whereCat="URL_REWRITE_EN ='".$category."' OR URL_REWRITE_SP='".$category."'";
		
			$category= $this->model->Search('category_master',$whereCat);
			$serachCondition.='(AREA_CAT_SOFTWARE_ID='.$category[0]['CATEGORY_ID'].' AND TYPE="CATEGORY")';
		}
		if ($area!='')
		{
			if($category!='')
			{
				$whereArea="URL_REWRITE_EN ='".$area."' OR URL_REWRITE_SP='".$area."'";
					
				$area= $this->model->Search('area_master',$whereArea);
				$serachCondition.=' OR (AREA_CAT_SOFTWARE_ID='.$area[0]['AREA_ID'].' AND TYPE="AREA") ';
			}
			else
			{
				$whereArea="URL_REWRITE_EN ='".$area."' OR URL_REWRITE_SP='".$area."'";
		
				$area= $this->model->Search('area_master',$whereArea);
				$serachCondition.=' (AREA_CAT_SOFTWARE_ID='.$area[0]['AREA_ID'].' AND TYPE="AREA") ';
			}
		}
		
		if ($software!='')
		{
			if($area!='')
			{
				$whereSoft="URL_REWRITE_EN ='".$software."' OR URL_REWRITE_SP='".$software."'";
					
				$software= $this->model->Search('software_master',$whereSoft);
				$serachCondition.=' OR (AREA_CAT_SOFTWARE_ID='.$software[0]['SOFTWARE_ID'].' AND TYPE="SOFTWARE") ';
			}
			else
			{
				if($category!='')
				{
					$whereSoft="URL_REWRITE_EN ='".$software."' OR URL_REWRITE_SP='".$software."'";
		
					$software= $this->model->Search('software_master',$whereSoft);
					$serachCondition.=' OR (AREA_CAT_SOFTWARE_ID='.$software[0]['SOFTWARE_ID'].' AND TYPE="SOFTWARE") ';
				}
				else
				{
					$whereSoft="URL_REWRITE_EN ='".$software."' OR URL_REWRITE_SP='".$software."'";
		
					$software= $this->model->Search('software_master',$whereSoft);
					$serachCondition.=' (AREA_CAT_SOFTWARE_ID='.$software[0]['SOFTWARE_ID'].' AND TYPE="SOFTWARE") ';
				}
			}
		
		}
		/***********************/
		
		
		
		/*******************************/
		if($serachCondition!=''){
			$searchcourse=$this->model->searchCourse($serachCondition);
		}
		else
		{
			
			
            
			
			$page = max(1, (int) $this->input->get('page', 1));
		
		
			$params = array(
					'page'		=> $page ,
					'limit'		=> ( $this->per_page ) ,
					
			);
			
			$searchcourses=$this->model->get_recent_courses($params);
			
			$total=$this->model->record_count();
			
			$pagination = $this->paginatorcourse( array(
					'total_rows' => $total ,
					'per_page'	 => $params['limit']
			),$module='courses/recent');
			
			$this->data['pagination']	= $pagination;
			
			
			$searchcourse = json_decode(json_encode($searchcourses),true);
			
			
			
		}
		for ($i=0;$i<count($searchcourse);$i++)
		{
			$data=array(
					'COURSE_ID'=>$searchcourse[$i]['COURSE_ID'],
					'INACTIVE'=>'1'
			);
			$result[$i] = $this->db->get_where('course_master',$data)->row_array();
		}

		
		/////////////	END SEARCHING ///////////////////////
		/***************************************************/
		
		for($i=0;$i<count($result);$i++)
		{
			$courseName[$i]=SiteHelpers::seoUrl($result[$i]['COURSE_NAME'],'dash');
		}
		
		$this->data['courseName']=$courseName;
		
		for($i=0;$i<count($result);$i++)
		{
			$courseCover[$i]=$this->model->courseCover($result[$i]['COURSE_ID']);
		}
		
		$this->data['courseCover']=$courseCover;
		
		for($i=0;$i<count($result);$i++)
		{
			$countComment[$i]=$this->model->countComment($result[$i]['COURSE_ID']);
			$totalcourseUser[$i]=$this->model->totaluser($result[$i]['COURSE_ID']);
		}
		$this->data['countComment']=$countComment;
		
		$this->data['totalcourseUser']=$totalcourseUser;
		
		for($i=0;$i<count($result);$i++)
		{
			$shortContent[$i]=$this->model->getLatestcoursecontent($result[$i]['COURSE_ID']);
		}
		$this->data['result']=$result;
		if(count($result)!=null){
			$this->data['shortContent']=$shortContent;
		}
		
		$this->data['category']=$this->cmodel->getSelectbox('category_master');
		$this->data['software']=$this->cmodel->getSelectbox('software_master');
		$this->data['area']=$this->cmodel->getSelectbox('area_master');
		
		$this->data['List_course']="recent course";
		
		$this->data['content']= $this->load->view('frontend/courses/lists',$this->data, TRUE);
		$this->load->view($this->layout, $this->data );
		
	}
}

?>