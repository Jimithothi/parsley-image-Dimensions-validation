<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * @package     CodeIgniter
 * @author      Ikraftsolutions
 * @copyright   Copyright (c) Ikraftsolutions (http://ikraftsolutions.com)
 * @version 1.0
 */


class Page extends SB_controller {


	protected $layout = "frontend/layouts/main";
	
	function __construct()
	{
		parent::__construct();	
		
				
	}
	
	
	public function index($id)
	{
		$this->data=array();
		
		//echo $id;
		
		//exit;
		if($id=='help')
		{
			$this->data['content']= $this->load->view('frontend/page/help',$this->data, TRUE);
		}
		elseif ($id=='contact-us')
		{
			 $this->data['content']= $this->load->view('frontend/page/contactus',$this->data, TRUE);	
		}
		else 
		{
			redirect(base_url());
		}
		
			
		
			
    	$this->load->view($this->layout, $this->data );
		
	}
	
	
}
