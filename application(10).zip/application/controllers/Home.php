<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * @package     CodeIgniter
 * @author      Ikraftsolutions
 * @copyright   Copyright (c) Ikraftsolutions (http://ikraftsolutions.com)
 * @version 1.0
 */

class Home extends SB_Controller
{
	protected $layout 	= "frontend/layouts/main";
	function __construct()
	{
		parent::__construct();
		$this->load->model('coursesmodel');
		$this->model = $this->coursesmodel;
	}
	
	
	
	function index()
	{
		if($this->session->userdata('log_in'))
		{
		}
		
		$result=$this->model->getLatestcourse(); 
		
		
		
		for($i=0;$i<count($result);$i++)
		{
			$countComment[$i]=$this->model->countComment($result[$i]['COURSE_ID']);
			$totalcourseUser[$i]=$this->model->totaluser($result[$i]['COURSE_ID']);
		}
		
		
		
		
		for($i=0;$i<count($result);$i++)
		{
			$shortContent[$i]=$this->model->getLatestcoursecontent($result[$i]['COURSE_ID']);
		}
		
		for($i=0;$i<count($result);$i++)
		{
			$courseCover[$i]=$this->model->courseCover($result[$i]['COURSE_ID']);
			
		}

		$this->data['courseCover']=$courseCover;
		
		$this->data['countComment']=$countComment;
		$this->data['totalcourseUser']=$totalcourseUser;
		$this->data['result']=$result;
		if(count($result)!=null){
		$this->data['shortContent']=$shortContent;
		
		}
		for($i=0;$i<count($result);$i++)
		{
			$courseName[$i]=SiteHelpers::seoUrl($result[$i]['COURSE_NAME'],'dash');
		}
		
		
		$this->data['courseName']=$courseName;
		
		$this->data['content'] = $this->load->view('frontend/home/index',$this->data,true);
		
		$this->load->view($this->layout, $this->data );
	}
	public function user_login()
	{
   		$login = array(
			'USER_NAME'=> $this->input->post('email'),
   			'PASSWORD'=>md5(trim($this->input->post('password',true)))
		);
   		$user=$this->model->getUser($login);
   		
   		
   		
   		$row = $this->db->get_where('user_master',$login)->row();
   			
   		
	   	if(count($user)==1)
	   	{
	   		if($user[0]['USER_IMAGE']=='')
	   		{
	   			$this->session->set_userdata(array(
	   					'login_ID'  => true,
	   					'userId'    => $user[0]['USER_ID'],
	   					'userName'    => $user[0]['USER_NAME'],
	   					'fid'    => $user[0]['FIRST_NAME'].' '.$user[0]['LAST_NAME'],
	   					'nickName'=>$user[0]['NICK_NAME'],
	   					'user_avatar'=>base_url().'uploads/users/images.png'
	   			));
	   		}
	   		else
	   		{
	   			$this->session->set_userdata(array(
	   					'login_ID'  => true,
	   					'userId'    => $user[0]['USER_ID'],
	   					'userName'    => $user[0]['USER_NAME'],
	   					'fid'    => $user[0]['FIRST_NAME'].' '.$user[0]['LAST_NAME'],
	   					'nickName'=>$user[0]['NICK_NAME'],
	   					'user_avatar'=>base_url().'uploads/users/'.$user[0]['USER_IMAGE']
	   			));
	   		}
	   		
	   		
	   		
			echo true;
	   	}
	   	else {
	   		echo false;
	   	}   		
	}
	
	public function user_register()
	{
		$activation=random_string('alnum', 10);
			$data = array(
					'USER_NAME'  => $this->input->post('email'),
					'ROLE_ID'    =>  '2' ,
					'PASSWORD'    =>  md5(trim($this->input->post('password'))) ,
					'INACTIVE'		=>'0',
					'ACTIVATION'		=>$activation,
					'USER_IMAGE'	=> ''
			);
			
			$row = $this->db->get_where('user_master',array('USER_NAME'=>$this->input->post('email')))->row();
			
			 if(count($row) == 1)
			 {
			 		echo "false";
			 }
			 else{
			
					#####################################
					
					$config['protocol']    	= 'smtp';
					$config['smtp_host']    = 'ssl://smtp.gmail.com';
					$config['smtp_port']    = '465';
					$config['smtp_timeout'] = '7';
					$config['smtp_user']    = 'haribhajan101@gmail.com';
					$config['smtp_pass']    = 'H2SO4H2O';
					$config['charset']    	= 'utf-8';
					$config['newline']   	= "\r\n";
					$config['mailtype'] 	= 'html'; // or html
					$config['validation'] 	= TRUE; // bool whether to validate email or not
						
					$this->data['PWD']=$this->input->post('password');
					$this->data['USER_NAME']=$this->input->post('email');
					$this->data['code']=$activation;
		
					$message = $this->load->view('emails/registration', $this->data,true);
						
					$this->load->library('email', $config);
						
					$this->email->from('noreply@proyectarte.org', 'Login Detail');
					$this->email->to($this->input->post('email'));
						
					$this->email->subject('Login Details');
					$this->email->message($message);
						
					$this->email->send();
					
					#####################################
					
					$this->db->insert('user_master',$data);
					
					echo true;
			 }
	}
	public function add()
	{
		redirect($_SERVER['HTTP_REFERER']);
	}
	public function fb_login()
	{
		$check=array('USER_NAME'=> $this->input->post('email'));
		
		$row = $this->db->get_where('user_master',$check)->row();
		
		if(count($row) == 0)
		{
			$arrContextOptions=array(
					"ssl"=>array(
							"verify_peer"=>false,
							"verify_peer_name"=>false,
					),
			);
			
			$fbprofileImage=md5(time()).'.jpg';
			$dest=FCPATH .'uploads/users/'.$fbprofileImage;
			copy($this->input->post('FbImage'), $dest,stream_context_create($arrContextOptions));
			
			
			$login = array(
					'USER_NAME'	=> $this->input->post('email'),
					'FIRST_NAME'=>$this->input->post('first_name'),
					'LAST_NAME'	=>$this->input->post('last_name:'),
					'NICK_NAME'	=>$this->input->post('nickName'),
					'INACTIVE'	=>'1',
					'ROLE_ID'	=>'2',
					'USER_IMAGE'=>$fbprofileImage
			);
			$this->db->insert('user_master',$login);
			
		}
		
		
			$row = $this->db->get_where('user_master',$check)->row();
			$this->session->set_userdata(array(
					'login_ID'  => true,
					'userId'    => $row->USER_ID,
					'userName'  => $row->USER_NAME,
					'fid'    	=> $row->FIRST_NAME.' '.$row->LAST_NAME,
					'nickName'	=>$row->NICK_NAME,
					'user_avatar'=>base_url().'uploads/users/'.$row->USER_IMAGE
					
			));
			echo true;
		
	}
	
	public function fb_register()
	{
		
		$this->load->helper('string');
		$password=random_string('alnum', 8);
		$arrContextOptions=array(
				"ssl"=>array(
						"verify_peer"=>false,
						"verify_peer_name"=>false,
				),
		);
		
		$fbprofileImage=md5(time()).'.jpg';
		$dest=FCPATH .'uploads/users/'.$fbprofileImage;
		copy($this->input->post('FbImage'), $dest,stream_context_create($arrContextOptions));
			
		$register = array(
				'USER_NAME'	=> $this->input->post('email'),
				'FIRST_NAME'=>$this->input->post('first_name'),
				'LAST_NAME'	=>$this->input->post('last_name:'),
				'NICK_NAME'	=>$this->input->post('nickName'),
				'DOB'		=>$this->input->post('dob'),
				'INACTIVE'	=>'1',
				'PASSWORD'	=>md5($password),
				'ROLE_ID'	=>'2',
				'USER_IMAGE'	=> $fbprofileImage
		);
		
		$check=array('USER_NAME'=> $this->input->post('email'));
		
		$row = $this->db->get_where('user_master',$check)->row();
		
		if(count($row) == 0)
		{
			
			
			$this->db->insert('user_master',$register);
			$id=$this->db->insert_id();
			
			$config['protocol']    	= 'smtp';
			$config['smtp_host']    = 'ssl://smtp.gmail.com';
			$config['smtp_port']    = '465';
			$config['smtp_timeout'] = '7';
			$config['smtp_user']    = 'haribhajan101@gmail.com';
			$config['smtp_pass']    = 'H2SO4H2O';
			$config['charset']    	= 'utf-8';
			$config['newline']   	= "\r\n";
			$config['mailtype'] 	= 'html'; // or html
			$config['validation'] 	= TRUE; // bool whether to validate email or not
			
		//	$this->data['PWD']=$password;
			$this->data=$register;
			$this->data['PWD']=$password;
			$message = $this->load->view('emails/fbregistration', $this->data,true);
			
			$this->load->library('email', $config);
			
			$this->email->from('noreply@proyectarte.org', 'Login Detail');
			$this->email->to($this->input->post('email'));
			
			$this->email->subject('Login Details');
			$this->email->message($message);
			
			$this->email->send();
			$this->session->set_userdata(array(
					'login_ID'  => true,
					'userId'    => $id,
					'userName'    => $this->input->post('nickName'),
					'fid'    => $this->input->post('first_name').' '.$this->input->post('last_name'),
					'nickName'=>$this->input->post('nickName'),
					'user_avatar'=>base_url().'uploads/users/'.$fbprofileImage
			));
			echo true;
		}
		else 
		{
			echo false;
		}
		
	}
	
	public function lang($lang)
	{
		$this->session->set_userdata('lang',$lang);
		redirect($_SERVER['HTTP_REFERER']);
	}
	
	public function logout()
	{
		$this->session->set_userdata(array(
	   				'login_ID'  => '',
	   				'userId'    => '',
	   				'userName'    => '',
	   				'fid'    => '',
	   				'nickName'=>'',
					'user_avatar'=>''
	   		));
		redirect();
	}
}
?>