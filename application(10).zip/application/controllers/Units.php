<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * @package     CodeIgniter
 * @author      Ikraftsolutions
 * @copyright   Copyright (c) Ikraftsolutions (http://ikraftsolutions.com)
 * @version 1.0
 */

class Units extends SB_Controller 
{
	protected $layout 	= "admin/layouts/main";
	public $module 		= 'unit';
	public $per_page	= '10';

	function __construct() {
		parent::__construct();
		
		$this->load->model('unitmodel');
		$this->model = $this->unitmodel;
	}
	
	function index()
	{
		show_404();
	}
	
	function view($page=null)
	{
		$result=$this->model->getunit($page);

		if(count($result)==0)
		{
			show_404();
		}
		else
		{
			
			/*echo "<pre>";
			print_r($result);
			echo "</pre>";
			
			exit;
			
			*/
			$this->data['row']=$result;
			$content=$this->model->getUnitcontent($page);
				
			$this->data['courseContent']=$content;
			
			$this->load->model('coursesmodel');
			
			
			
			$courses_count=$this->coursesmodel->courseCount($result[0]['COURSE_ID']);
			//$this->data['totalcourseUser']=$this->coursesmodel->totaluser($result[0]['COURSE_ID']);
			//$this->data['totalcourseUser']=$this->coursesmodel->totalvideo($result[0]['COURSE_ID']);
			
			/*echo "<pre>";
			print_r($courses_count);
			echo "</pre>";
			
			exit;*/
			
			$this->data['courses_count']=$courses_count;
			
			$this->data['category']=$this->model->getSelectbox('category_master');
			$this->data['software']=$this->model->getSelectbox('software_master');
			$this->data['area']=$this->model->getSelectbox('area_master');
			
			$this->data['content']= $this->load->view('frontend/unit/view',$this->data, TRUE);
			$this->load->view('frontend/layouts/main', $this->data );
		}
	}
}
