<?php 
$lang["core.norecord"] = "No Record Found";
$lang["core.create"] = "Create New";

// General , Login Info & Signup
$lang["core.home"] = "Home";
$lang["core.group"] = "Group";
$lang["core.username"] = "Username";
$lang["core.email"] = "Email Address";
$lang["core.password"] = "Password";
$lang["core.repassword"] = "Confirm Password";
$lang["core.forgotpassword"] = "Forgot Password";
$lang["core.newpassword"] = "New Password";
$lang["core.conewpassword"] = "Confirm Password";
$lang["core.notepassword"] = "Leave blank if you dont want to change current password ";
$lang["core.submit"] = "Submit";
$lang["core.signin"] = "Sign In";
$lang["core.signup"] = "Sign Up";
$lang["core.language"] = "Language";
$lang["core.firstname"] = "First Name";
$lang["core.lastname"] = "Last Name ";
$lang["core.lastlogin"] = "Last Login";
$lang["core.personalinfo"] = "Personal Info";
$lang["core.changepassword"] = "Change Password";
$lang["core.registernew"] = "Register New Account ";


?>