$(function ()  {	
	var InputsWrapper = $("#myForm"); 
    var area1;    
  /*  $("#media").click(function() {
		var counter=parseInt($('#hidden').val());
        $(InputsWrapper).append('<div class="div' + counter + '" id="InputsWrapper_' + counter + '">' 
        		+ '<div class="form-group  "><label for="Name" class=" control-label col-md-4 text-left"> Media :<span class="asterix"> * </span></label><div class="col-md-8">'
        		+ '<div class="col-md-10"><input class="form-control parsley-validated" type="text" name="mytext[' + counter + ']" id="field_' + counter + '" placeholder="http://"/></div>'
        		+ '<b><a id="' + counter + '" class="removeclass0" href="#"><span><i class="fa fa-trash-o fa-lg"></i><span></a>'           		
        		+ '<a href="#" id="' + counter + '" class="upclass"><span><i class="fa fa-arrow-up"></i></span></a>'
        		+ '<a href="#" id="' + counter + '" class="downclass"><span><i class="fa fa-arrow-down"></i></span></a></b><div class="col-md-10"><span><b>Available services : </b>Wistia</span><div>'
        		+ '<input type="hidden" name="type[]" value="Media" id="field_type' + counter + '">' 
        		+ '<br>' 
        		+ '</div></div>'
        );
        document.getElementById("hidden").value = counter+1;
    });
    $("#fileuplaod").click(function() {
    		var counter=parseInt($('#hidden').val());
            $(InputsWrapper).append( '<div class="div' + counter + '" id="InputsWrapper_' + counter + '">' 
            		+ '<div class="form-group  "><label for="Name" class=" control-label col-md-4 text-left"> File :<span class="asterix"> * </span></label><div class="col-md-8">'
	        		+ '<div class="col-md-10"><input type="file" class="form-control parsley-validated" name="mytext[' + counter + ']" multiple="multiple" id="field_' + counter + '" placeholder="Name ' + counter + '"/></div>'
            		+ '<a id="' + counter + '" class="removeclass0" href="#"><span><i class="fa fa-trash-o fa-lg"></i><span></a>'           		
            		+ '<a href="#" id="' + counter + '" class="upclass"><span><i class="fa fa-arrow-up"></i></span></a>'
            		+ '<a href="#" id="' + counter + '" class="downclass"><span><i class="fa fa-arrow-down"></i></span></a>'
            		+ '<input type="hidden" name="type[]" value="Image" id="field_type' + counter + '">' 
            		+ '<br>' 
            		+ '</div></div></div>'
            );
            document.getElementById("hidden").value = counter+1;
    });*
    $("#textbox").click(function(){
    	var counter=parseInt($('#hidden').val())+1;
	        $(InputsWrapper).append( '<div class="div' + counter + '" id="InputsWrapper_' + counter + '">' 
	        		+ '<div class="form-group  "><label for="Name" class=" control-label col-md-4 text-left"> Title<span class="asterix"> * </span></label><div class="col-md-8">'
	        		+ '<input type="text" name="mytextbox[]" id="field_' + counter + '" placeholder="Name ' + counter + '"/>'
	        		+ '<a id="' + counter + '" class="removeclass0" href="#"><span class="btn btn-danger"><i class="fa fa-trash-o fa-lg"></i><span></a>'            		
	        		+ '<span class="fa fa-arrow-up"><input type="button" id="' + counter + '" class="upclass" value=""/></span>'
	        		+ '<input type="button" id="' + counter + '" class="downclass" value="DOWN"/>' 
	        		+ '<input type="hidden" name="type[]" value="Image" id="field_type' + counter + '">' 
	        		+ '<br>' 
	        		+ '</div></div></div>'
	        );
	        document.getElementById("hidden").value = counter+1;
    });*/
    $("#texteditor").click(function(){
    	var counter=parseInt($('#hidden').val());
    	$(InputsWrapper).append( '<div class="div' + counter + '" id="InputsWrapper_' + counter + '">' 
    			+ '<div class="form-group  "><label for="Name" class=" control-label col-md-4 text-left"> Editor:<span class="asterix"> * </span></label><div class="col-md-8">'
        		+ '<div class="col-md-10"><textarea name="mytext[' + counter + ']" id="textarea_' + counter + '" class="form-control parsley-validated" rows="8"></textarea></div>'
        		+ '<a id="' + counter + '" class="removeclass0" href="#"><span><i class="fa fa-trash-o fa-lg"></i><span></a>'           		
        		+ '<a href="#" id="' + counter + '" class="upclass"><span><i class="fa fa-arrow-up"></i></span></a>'
        		+ '<a href="#" id="' + counter + '" class="downclass"><span><i class="fa fa-arrow-down"></i></span></a>'
        		+ '<input type="hidden" name="type[]" value="Text" id="field_type' + counter + '">' 
        		+ '<br>' 
        		+ '</div></div>'
        );
    	document.getElementById("hidden").value = counter+1;
    	var id='textarea_'+counter;
    	//$('textarea_'+counter).mooEditable();
    	area1 =  new MooEditable(id,{
		actions: 'bold italic underline toggleview'
		});
    });
   /* $("body").on("click", ".upclass", function() {
    	var click=this.id;
    	 $('.div'+click+':parent').insertBefore($('.div'+click+':parent').prev());
    });
    $("body").on("click", ".downclass", function() {
    	var downclick=this.id;
    	var demo=$('.div'+downclick+':parent');
    	 $(demo).insertAfter($(demo).next());
    });
    $("body").on("click", ".removeclass0", function() {
    	var downclick=this.id;
    	var demo=$('.div'+downclick).remove();
    });
});*/
/* clone 

var area;
var i = 1;
var btn = 1; // Global Variable for Name
function btnmedia() 
{
	var source = $('#courseForm'); 
	var y = document.createElement("INPUT");
	y.setAttribute("type", "text");
	y.setAttribute("Name", "Name_" + i);
	y.setAttribute("class", "form-control parsley-validated");
	
	var x=document.createElement("a");
	x.setAttribute("id", i);
	x.setAttribute("class", "removeclass0");
	x.setAttribute("Name", "Name"+i);
	
	clone = source.clone();
	clone.find('.col-sm-8').append(y);
	clone.find('label').attr('class','col-sm-4 text-right').html('Media:' + i);
	clone.attr("id", "courseForm"+ i);
	source.after(clone);
	i++;
}
function btnfile()
{
	var source = $('#courseForm'); 
	var y = document.createElement("INPUT");
	y.setAttribute("type", "file");
	y.setAttribute("Name", "Name_" + i);
	y.setAttribute("class", "form-control parsley-validated");	
	clone = source.clone();
	clone.find('.col-sm-8').append(y);
	clone.find('label').attr('class','col-sm-4 text-right').html('File:' + i);
	clone.attr("id", "courseForm"+ i);
	source.after(clone);
	i++;
}
function btneditor()
{
	var source = $('#courseForm'); 
	var y = document.createElement("textarea");
	y.setAttribute("Name", "Name_" + i);
	y.setAttribute("id","textarea_"+i);
	y.setAttribute("class", "form-control parsley-validated");	
	y.setAttribute("rows",'8');
	clone = source.clone();
	clone.find('.col-sm-8').append(y);
	clone.find('label').attr('class','col-sm-4 text-right').html('Editor:' + i);
	clone.attr("id", "courseForm"+ i);
	source.after(clone);
	area=new MooEditable(y.id,{
		actions: 'bold italic underline insertorderedlist insertunorderedlist'
		});
	i++;
}


function unitclone()
{
	var unitsource = $('#unit');
	clone = unitsource.clone();
	clone.attr('id', 'unit'+ i);
	
	var y = document.createElement("INPUT");
	y.setAttribute("type", "text");
	y.setAttribute("Name", "Name_" + i);
	y.setAttribute("class", "form-control parsley-validated");	
	
	clone.find('#courseForm').append(y);;
	
	//clone.find('label').attr('id','Unit').html('Unit');
	//clone.find('label').attr('id','Description').html('Description');
	//console.log(clone.find('label').attr('for','Unit'+i));
	
	console.log(clone);
	unitsource.after(clone); i++;
}
function btnUnitM(id) 
{
	var panel= $("#unit");
	var inputs = panel.find("div");
	
	
	
	console.log(inputs.length);
	
	/*for(i=0;i<inputs.length;i++)
	{
		console.log(input[i]);
	}
	
	/*
	var source = $('#courseForm'); 
	var y = document.createElement("INPUT");
	y.setAttribute("type", "text");
	y.setAttribute("Name", "Name_" + i);
	y.setAttribute("class", "form-control parsley-validated");	
	clone = source.clone();
	clone.find('.col-sm-8').append(y);
	clone.find('label').attr('class','col-sm-4 text-right').html('Media:' + i);
	clone.attr("id", "courseForm"+ i);
	source.after(clone);
	i++;
}
*/
/*
$(function ()  {
	
	
});*/
