$(function ()  {
	
	
	var InputsWrapper = $("#myForm"); 
    var area1;    
	//var area1;
	$("#texteditor").click(function(){
    	var counter=parseInt($('#hidden').val());
    	$(InputsWrapper).append(
    			'<div class="div' + counter + '" id="InputsWrapper_' + counter + '">' 
    			+'<div class="form-group  " >'
    			+ '<span id="' + counter + '" class="removeclass0" ><span><i class="fa fa-trash-o fa-lg"></i><span></span>'
        		+ '<span id="' + counter + '" class="downclass" ><span><i class="fa fa-arrow-down"></i><span></span>'
        		+ '<span id="' + counter + '" class="upclass" ><span><i class="fa fa-arrow-up"></i><span></span>'
    			+'<label for="Course Name" class=" control-label col-md-4 text-left"> Editor <span class="asterix"> * </span></label>'
    			+'<div class="col-md-8">'
    			+'<textarea name="COURSE_CONTENT[]" rows="5" id="editor_' + counter + '" class="form-control mceEditor "></textarea><br>'
    			+'<i> <small></small></i>'
    			+ '<input type="hidden" name="type[]" value="TEXT" id="field_type' + counter + '">'
				+' </div> '					
				+'</div> '
    			
        );
    	document.getElementById("hidden").value = counter+1;
    	var id='#editor_'+counter;
    	console.log(id);

    	 tinymce.init({
    		 selector: id,
    		  menubar:false,
    		  statusbar: false,
    		  height: 200,
    		  plugins: [
    		    '  lists  preview anchor',
    		    ' fullscreen',    
    		  ],
    		  toolbar: 'bold italic underline |  bullist numlist  ',
    			

    		});
    });
	
	$("#media").click(function() {
		var counter=parseInt($('#hidden').val());
        $(InputsWrapper).append('<div class="div' + counter + '" id="InputsWrapper_' + counter + '">' 
        		+'<div class="form-group" >'
        		+ '<a id="' + counter + '" class="removeclass0" ><span><i class="fa fa-trash-o fa-lg"></i><span></a>'
        		+ '<a id="' + counter + '" class="downclass" ><span><i class="fa fa-arrow-down"></i><span></a>'
        		+ '<a id="' + counter + '" class="upclass" ><span><i class="fa fa-arrow-up"></i><span></a>'
    			+'<label for="Course Name" class=" control-label col-md-4 text-left"> Media <span class="asterix"> * </span></label>'
    			+'<div class="col-md-8">'
    			+'<input class="form-control" type="url" name="COURSE_CONTENT[]" id="media_' + counter + '" placeholder="http://"  data-parsley-pattern="/^((http[s]?|ftp):)\/\/([a-z0-9_\.-]+)\.([\da-z\.-]+)\.([a-z\.]{2,6})\/(medias)\/([A-Za-z0-9_\.-]{10})/" required=""/><br>'
    			+'<i> <small></small></i>'
    			+ '<input type="hidden" name="type[]" value="MEDIA" id="field_type' + counter + '">'
				+' </div> '					
				+'</div> '
				
        		
        );
        document.getElementById("hidden").value = counter+1;
    });
	
	$("#textbox").click(function() {
		var counter=parseInt($('#hidden').val());
        $(InputsWrapper).append('<div class="div' + counter + '" id="InputsWrapper_' + counter + '">' 
        		+'<div class="form-group  " >'
        		+ '<a id="' + counter + '" class="removeclass0" ><span><i class="fa fa-trash-o fa-lg"></i><span></a>'
        		+ '<a id="' + counter + '" class="downclass" ><span><i class="fa fa-arrow-down"></i><span></a>'
        		+ '<a id="' + counter + '" class="upclass" ><span><i class="fa fa-arrow-up"></i><span></a>'
    			+'<label for="Course Name" class=" control-label col-md-4 text-left"> Textbox <span class="asterix"> * </span></label>'
    			+'<div class="col-md-8">'
    			+'<table>'
    			+'<tr>'
    			+'<td width="80%">'
    			+'<input class="form-control" type="text" name="COURSE_CONTENT[]" id="textbox_' + counter + '" required=""/>'
    			+'</td>'
    			+'<td width="3%">'
    			+'</td>'
    			+'<td width="15%">'
    			+'<input type="checkbox" name="assign[]"  id="check_' + counter + '" class="checkboxValue"/><input type="hidden" name="checkboxValue[]" value="0" id="link_check_' + counter + '" >'
    			+'</td>'
    			+'<td width="2%"><i class="fa fa-question-circle" data-placement="top" data-toggle="tooltip" title="If you want to add sub unit then add textbox control and check mark that textbox!"></i></td>'
    			+'</tr>'
    			+'</table>'
    			+'<br>'
    			+'<i> <small></small></i>'
    			+ '<input type="hidden" name="type[]" value="TEXTBOX" id="field_type' + counter + '">'
				+' </div> '					
				+'</div> '
				
        		
        );
        document.getElementById("hidden").value = counter+1;
    });
	
	$("#fileuplaod").click(function() {
		var counter=parseInt($('#hidden').val());
        $(InputsWrapper).append(
        		'<div class="div' + counter + '" id="InputsWrapper_' + counter + '">' 
        		+'<div class="form-group  " >'
        		+ '<a id="' + counter + '" class="removeclass0" ><span><i class="fa fa-trash-o fa-lg"></i><span></a>'
        		+ '<a id="' + counter + '" class="downclass" ><span><i class="fa fa-arrow-down"></i><span></a>'
        		+ '<a id="' + counter + '" class="upclass" ><span><i class="fa fa-arrow-up"></i><span></a>'
    			+'<label for="Course Name" class=" control-label col-md-4 text-left"> File <span class="asterix"> * </span></label>'
    			+'<div class="col-md-8">'
    			+'<input class="form-control coursefile" type="file" name="COURSE_CONTENT[]" id="file_' + counter + '" data-parsley-fileextension="jpg,png" required /><br>'
    			+'<i> <small></small></i>'
    			+ '<input type="hidden" name="type[]" value="FILEUPLOAD" id="field_type' + counter + '">'
				+' </div> '					
				+'</div> '
        		
        );
        document.getElementById("hidden").value = counter+1;
    });
	
	$("#soundupload").click(function() {
		var counter=parseInt($('#hidden').val());
        $(InputsWrapper).append(
        		'<div class="div' + counter + '" id="InputsWrapper_' + counter + '">' 
        		+'<div class="form-group  " >'
        		+ '<a id="' + counter + '" class="removeclass0" ><span><i class="fa fa-trash-o fa-lg"></i><span></a>'
        		+ '<a id="' + counter + '" class="downclass" ><span><i class="fa fa-arrow-down"></i><span></a>'
        		+ '<a id="' + counter + '" class="upclass" ><span><i class="fa fa-arrow-up"></i><span></a>'
    			+'<label for="Course Name" class=" control-label col-md-4 text-left"> Sound <span class="asterix"> * </span></label>'
    			+'<div class="col-md-8">'
    			+'<input class="form-control" type="file" name="COURSE_CONTENT[]" id="sound_' + counter + '" data-parsley-fileextension="mp3,mp4" required /><br>'
    			+'<i> <small></small></i>'
    			+ '<input type="hidden" name="type[]" value="SOUND" id="field_type' + counter + '">'
				+' </div> '					
				+'</div> '
        		
        );
        document.getElementById("hidden").value = counter+1;
        
    });
	
	
	 $("body").on("click", ".upclass", function() {
		 var click=this.id;
		 
		
		 
		 console.log(click);	
	 $('.div'+click+':parent').insertBefore($('.div'+click+':parent').prev());
	});
	 
	 $("body").on("click", ".downclass", function() {
		 
		var downclick=this.id;
		
		
		 
		var demo=$('.div'+downclick+':parent');
		 $(demo).insertAfter($(demo).next());
	});
	 
	$("body").on("click", ".removeclass0", function() {
		var downclick=this.id;
		var demo=$('.div'+downclick).remove();
	});
	
	$("body").on("change", ".checkboxValue", function() {
		var checkclick=this.id;
		console.log(checkclick);
		if($('#'+checkclick).is(':checked'))
		{
			$('#link_'+checkclick).val(1);	
			
		}
		else
		{
			$('#link_'+checkclick).val(0);	
			
		}    
	});

	

	
});




	
	
   
