		<div class="fixed-sidebar-left">
			<ul class="nav navbar-nav side-nav nicescroll-bar">
				<li><a href="<?php echo base_url('dashboard');?>"><i class="icon-picture mr-10"></i>Dashboard</a></li>
				<li><a href="<?php echo base_url('facility');?>"><i class="fa fa-wpforms mr-10"></i>Manage Facility</a></li>
				<li><a href="<?php echo base_url('kitchenette');?>"><i class="fa fa-shopping-basket mr-10"></i>Manage Kitchenette</a></li>
				<li><a href="<?php echo base_url('assets');?>"><i class="fa fa-mixcloud mr-10"></i>Manage Assets</a></li>
				<li><a href="<?php echo base_url('users')?>"><i class="icon-user mr-10"></i>Manage Users</a></li>
				<li><a href="manage_report.html"><i class="icon-user mr-10"></i>Manage Report</a></li>
			</ul>
		</div>