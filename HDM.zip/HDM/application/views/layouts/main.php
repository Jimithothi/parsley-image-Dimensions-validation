<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<title><?php echo $site_url;?></title>

<link href="<?php echo base_url();?>asset/lib/jasny-bootstrap/dist/css/jasny-bootstrap.min.css" rel="stylesheet" type="text/css" />
<link href="<?php echo base_url()?>asset/lib/datatables/media/css/jquery.dataTables.min.css" rel="stylesheet" type="text/css" />
<link href="<?php echo base_url()?>asset/lib/datatables.net-responsive/css/responsive.dataTables.min.css" rel="stylesheet" type="text/css" />
<link href="<?php echo base_url();?>asset/css/style.css" rel="stylesheet" type="text/css">

</head>

<body>
	<!-- Preloader -->
	<div class="preloader-it">
		<div class="la-anim-1"></div>
	</div>
	<!-- /Preloader -->
	
	<div class="wrapper">
		<?php $this->load->view('layouts/head');?>
		<?php $this->load->view('layouts/left_sidebar');?>
		<div class="page-wrapper">
			<?php echo $content;?>
			<?php $this->load->view('layouts/footer')?>
		</div>
	</div>
	
	<script src="<?php echo base_url();?>asset/lib/jquery/dist/jquery.min.js"></script>
	<script src="<?php echo base_url();?>asset/lib/bootstrap/dist/js/bootstrap.min.js"></script>
	
	<!-- Script -->
	<script src="<?php echo base_url('asset/lib/datatables/media/js/jquery.dataTables.min.js') ?>"></script>
	<script src="<?php echo base_url();?>asset/lib/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
	
	<!-- /Script -->
	
	<script src="<?php echo base_url();?>asset/js/jquery.slimscroll.js"></script>
	<script src="<?php echo base_url();?>asset/js/init.js"></script>
	
	<script src="<?php echo base_url();?>asset/js/main.js"></script>
</body>

</html>
