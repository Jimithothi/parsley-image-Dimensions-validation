<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<title>Login HDM</title>

<!-- <meta name="description" content="Kenny is a Dashboard & Admin Site Responsive Template by hencework." /> -->
<!-- <meta name="keywords" content="admin, admin dashboard, admin template, cms, crm, Kenny Admin, kennyadmin, premium admin templates, responsive admin, sass, panel, software, ui, visualization, web app, application" /> -->
<!-- <meta name="author" content="hencework" /> -->

<!-- <link rel="shortcut icon" href="favicon.ico"> -->
<!-- <link rel="icon" href="favicon.ico" type="image/x-icon"> -->

<link href="<?php echo base_url();?>asset/lib/jasny-bootstrap/dist/css/jasny-bootstrap.min.css" rel="stylesheet" type="text/css" />
<link href="<?php echo base_url();?>asset/css/style.css" rel="stylesheet" type="text/css">

</head>
<body>
	<div class="preloader-it">
		<div class="la-anim-1"></div>
	</div>

	<div class="wrapper pa-0">
		<div class="page-wrapper pa-0 ma-0">
			<div class="container-fluid">
				<div class="table-struct full-width full-height">
					<div class="table-cell vertical-align-middle">
						<div class="auth-form  ml-auto mr-auto no-float">
							<?php echo $content;?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	
	<script src="<?php echo base_url();?>asset/lib/jquery/dist/jquery.min.js"></script>
	<script src="<?php echo base_url();?>asset/lib/bootstrap/dist/js/bootstrap.min.js"></script>
	<script src="<?php echo base_url();?>asset/lib/jasny-bootstrap/dist/js/jasny-bootstrap.min.js"></script>
	<script src="<?php echo base_url();?>asset/js/jquery.slimscroll.js"></script>
	<script src="<?php echo base_url();?>asset/js/init.js"></script>
	
</body>
</html>
