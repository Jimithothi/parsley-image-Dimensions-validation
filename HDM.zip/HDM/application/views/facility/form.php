			<div class="container-fluid">
				<!-- Title -->
				<div class="row heading-bg bg-blue">
					<div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
						<h5 class="txt-light"><?php echo $title;?></h5>
					</div>
					<!-- Breadcrumb -->
					<div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
						<ol class="breadcrumb">
							<li><a href="<?php echo base_url('dashboard')?>">Dashboard</a></li>
							<li class="active"><a href="<?php echo base_url('facility')?>"><span>Facility</span></a></li>
						</ol>
					</div>
					<!-- /Breadcrumb -->
				</div>
				<!-- /Title -->
				<!-- Row -->
				<div class="row">
					<div class="col-md-12">
						<div class="panel panel-default card-view">
							<div class="panel-heading">
								<div class="pull-left">
								</div>
								<div class="clearfix"></div>
							</div>
							<div class="panel-wrapper collapse in">
								<div class="panel-body">
									<div class="row">
										<div class="col-md-12">
											<div class="form-wrap">
													<?php 
													$attributes = array('method' => 'post','class'=>'form-horizontal');
													
													echo form_open('facility/add', $attributes);
													?>

													<div class="form-body">

														<div class="row">
															<div class="col-md-12">
																<div class="form-group">
																	<?php echo form_label('Facility	Name*','facility_name',array('class'=>'control-label col-md-2'));?>
																	<div class="col-md-10">
																		<?php echo form_input($facility_name);?>
																		<?php echo form_error('facility_name','<div class="infoMessage">* ','</div>'); ?>
																	</div>
																</div>
															</div>

															<div class="col-md-12">
																<div class="form-group">
																	<?php echo form_label('First Name*','first_name',array('class'=>'control-label col-md-2'));?>
																	<div class="col-md-10">
																		<?php echo form_input($first_name);?>
																		<?php echo form_error('first_name','<div class="infoMessage">* ','</div>'); ?>
																	</div>
																</div>
															</div>

															<div class="col-md-12">
																<div class="form-group">
																	<?php echo form_label('Last	Name*','last_name',array('class'=>'control-label col-md-2'));?>
																	<div class="col-md-10">
																		<?php echo form_input($last_name);?>
																		<?php echo form_error('last_name','<div class="infoMessage">* ','</div>'); ?>
																	</div>
																</div>
															</div>

															<div class="col-md-12">
																<div class="form-group">
																	<?php echo form_label('Phone*','phone',array('class'=>'control-label col-md-2'));?>
																	<div class="col-md-10">
																		<?php echo form_input($phone);?>
																		<?php echo form_error('phone','<div class="infoMessage">* ','</div>'); ?>
																	</div>
																</div>
															</div>

															<div class="col-md-12">
																<div class="form-group">
																	<?php echo form_label('Email*','email',array('class'=>'control-label col-md-2'));?>
																	<div class="col-md-10">
																		<?php echo form_input($email);?>
																		<?php echo form_error('email','<div class="infoMessage">* ','</div>'); ?>
																	</div>
																</div>
															</div>

															<div class="col-md-12">
																<div class="form-group">
																	<?php echo form_label('Address*','address',array('class'=>'control-label col-md-2'));?>
																	<div class="col-md-10">
																	<?php echo form_textarea($address);?>
																	</div>
																</div>
															</div>

															<div class="col-md-12">
																<div class="form-group">
																	<?php echo form_label('Postcode*','postcode',array('class'=>'control-label col-md-2'));?>
																	<div class="col-md-10">
																		<?php echo form_input($postcode);?>
																		<?php echo form_error('postcode','<div class="infoMessage">* ','</div>'); ?>
																	</div>
																</div>
															</div>

															<div class="col-md-12">
																<div class="form-group">
																	<?php echo form_label('City*','city',array('class'=>'control-label col-md-2'));?>
																	<div class="col-md-10">
																		<?php echo form_input($city);?>
																		<?php echo form_error('city','<div class="infoMessage">* ','</div>'); ?>
																	</div>
																</div>
															</div>

															<div class="col-md-12">
																<div class="form-group">
																	<?php echo form_label('State*','state',array('class'=>'control-label col-md-2'));?>
																	<div class="col-md-10">
																		<?php echo form_input($state);?>
																		<?php echo form_error('state','<div class="infoMessage">* ','</div>'); ?>
																	</div>
																</div>
															</div>

															<div class="col-md-12">
																<div class="form-group">
																	<?php echo form_label('Country*','country',array('class'=>'control-label col-md-2'));?>
																	<div class="col-md-10">
																		<?php echo form_input($country);?>
																		<?php echo form_error('country','<div class="infoMessage">* ','</div>'); ?>
																	</div>
																</div>
															</div>

<!-- 															<div class="col-md-12"> -->
<!-- 																<div class="form-group"> -->
<!-- 																	<label class="control-label col-md-2">Logo</label> -->
<!-- 																	<div class="col-md-10"> -->
<!-- 																		<div class="fileinput fileinput-new input-group" -->
<!-- 																			data-provides="fileinput"> -->
<!-- 																			<div class="form-control" data-trigger="fileinput"> -->
<!-- 																				<i class="glyphicon glyphicon-file fileinput-exists"></i> -->
<!-- 																				<span class="fileinput-filename"></span> -->
<!-- 																			</div> -->
<!-- 																			<span -->
<!-- 																				class="input-group-addon fileupload btn btn-info btn-anim btn-file"><i -->
<!-- 																				class="fa fa-upload"></i> <span -->
<!-- 																				class="fileinput-new btn-text">Select file</span> <span -->
<!-- 																				class="fileinput-exists btn-text">Change</span> <input -->
<!-- 																				type="file" name="..."> </span> <a href="#" -->
<!-- 																				class="input-group-addon btn btn-danger btn-anim fileinput-exists" -->
<!-- 																				data-dismiss="fileinput"><i class="fa fa-trash"></i><span -->
<!-- 																				class="btn-text"> Remove</span></a> -->
<!-- 																		</div> -->
<!-- 																	</div> -->
<!-- 																</div> -->
<!-- 															</div> -->
														</div>
														<div class="seprator-block"></div>
													</div>
													<div class="parent">
														<div class="child" style="position: fixed;bottom: 2.5%;right: 2.2%;z-index: 1;">
															<div class="pull-right">
																<br>
																<?php echo form_submit('submit', 'Submit',array('class'=>'btn btn-info btn-anim')); ?>
																<?php //echo form_submit('button', 'Sign In',array('class'=>'btn btn-warning btn-anim','onclick'=>base_url('facility'))); ?>
															</div>
														</div>
													</div>
												<?php echo form_close();?>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
