<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<?php
$ci = new CI_Controller();
$ci =& get_instance();
$ci->load->helper('url');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<title>404 Page Not Found</title>

<link href="<?php echo base_url(); ?>asset/lib/jasny-bootstrap/dist/css/jasny-bootstrap.min.css" rel="stylesheet" type="text/css" />
<link href="<?php echo base_url(); ?>asset/css/style.css" rel="stylesheet" type="text/css">

</head>
<body>
	<div class="preloader-it">
		<div class="la-anim-1"></div>
	</div>
	<div class="wrapper pa-0">
		<div class="page-wrapper pa-0 ma-0">
			<div class="container-fluid">
				<div class="table-struct full-width full-height">
					<div class="table-cell vertical-align-middle">
						<div class="auth-form  ml-auto mr-auto no-float">
							<div class="panel panel-default card-view mb-0">
								<div class="panel-wrapper collapse in">
									<div class="panel-body">
										<div class="row">
											<div class="col-sm-12 col-xs-12 text-center">
												<h3 class="mb-20 txt-danger"><?php echo $heading; ?></h3>
												<p class="font-18 txt-dark mb-15"><?php echo $message; ?></p>
												<p>The URL may be misspelled or the page you're looking
													for is no longer available.</p>
												<a
													class="btn btn-success btn-icon right-icon btn-rounded mt-30"
													href="<?php echo base_url();?>"><span>back to home</span><i
													class="fa fa-space-shuttle"></i></a>
												<p class="font-12 mt-15">2016 &copy; HDS.</p>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<script src="<?php echo base_url(); ?>asset/lib/jquery/dist/jquery.min.js"></script>
	<script src="<?php echo base_url(); ?>asset/lib/bootstrap/dist/js/bootstrap.min.js"></script>
	<script src="<?php echo base_url(); ?>asset/lib/jasny-bootstrap/dist/js/jasny-bootstrap.min.js"></script>
	<script src="<?php echo base_url(); ?>asset/js/jquery.slimscroll.js"></script>
	<script src="<?php echo base_url(); ?>asset/js/init.js"></script>
</body>
</html>