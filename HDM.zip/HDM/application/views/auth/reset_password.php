							<div class="panel panel-default card-view mb-0">
								<div class="panel-heading">
									<div class="pull-left">
										<h6 class="panel-title txt-dark"><?php echo lang('reset_password_heading');?></h6>
									</div>
									<div class="clearfix"></div>
								</div>
								<div class="panel-wrapper collapse in">
									<div class="panel-body">
										<div class="row">
											<div class="col-sm-12 col-xs-12">
												<div class="form-wrap">
													
													<?php echo form_open('auth/reset_password/' . $code);?>
														<div class="form-group">
														<label for="new_password" class="control-label mb-10"><?php echo sprintf(lang('reset_password_new_password_label'), $min_password_length);?></label> <br />
															<div class="input-group">
																<?php echo form_input($new_password);?>
																<div class="input-group-addon">
																	<i class="icon-lock"></i>
																</div>
															</div>
															<?php echo form_error('new','<div class="infoMessage">* ','</div>');?>
														</div>
														<div class="form-group">
															<label for="new_password_confirm" class="control-label mb-10"><?php echo lang('reset_password_new_password_confirm_label', 'new_password_confirm');?></label>
															<div class="input-group">
																<?php echo form_input($new_password_confirm);?>
																<div class="input-group-addon">
																	<i class="icon-lock"></i>
																</div>
															</div>
															<?php echo form_error('new_confirm','<div class="infoMessage">* ','</div>');?>
														</div>
														
														<div class="form-group">
															<?php echo form_input($user_id);?>
															<?php echo form_hidden($csrf); ?>
														</div>

														
														<div class="form-group">
															<?php echo form_submit('submit', 'Sign In',array('class'=>'btn btn-success btn-block')); ?>
														</div>
													<?php echo form_close();?>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
							