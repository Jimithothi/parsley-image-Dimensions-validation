<html>
<body>
	<h1><?php echo sprintf(lang('email_activate_heading'), $identity);?></h1>
	
	<h5>Email Address:<?php echo $identity;?></h5>
	<h5>Password:<?php echo $password;?></h5>
	<p><?php echo anchor('auth/login','Login Here');?></p>
</body>
</html>