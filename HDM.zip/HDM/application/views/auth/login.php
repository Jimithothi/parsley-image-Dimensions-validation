							<div class="panel panel-default card-view mb-0">
								<div class="panel-heading">
									<div class="pull-left">
										<h6 class="panel-title txt-dark"><?php echo lang('login_heading');?></h6>
									</div>
									<div class="clearfix"></div>
								</div>
								<div class="panel-wrapper collapse in">
									<div class="panel-body">
									<div id="infoMessage" class="infoMessage" style="text-align: center;"><?php echo $message;?></div>
										<div class="row">
											<div class="col-sm-12 col-xs-12">
												<div class="form-wrap">
													<?php echo form_open("auth/login");?>
														<div class="form-group">
															<?php echo form_label('Email*','identity',array('class'=>'control-label mb-10'));?>
															<div class="input-group">
																<?php echo form_input($identity);?>
																<div class="input-group-addon">
																	<i class="icon-envelope-open"></i>
																</div>
															</div>
															<?php echo form_error('identity','<div class="infoMessage">* ','</div>');?>
														</div>
														<div class="form-group">
															<?php echo form_label('Password*','password',array('class'=>'control-label mb-10'));?>
															<div class="input-group">
																<?php echo form_input($password);?>
																<div class="input-group-addon">
																	<i class="icon-lock"></i>
																</div>
															</div>
															<?php echo form_error('password','<div class="infoMessage">* ','</div>');?>
														</div>

														<div class="form-group">
															<div class="checkbox checkbox-success pr-10 pull-left">
																<?php echo form_checkbox('remember', '1', FALSE, 'id="checkbox_2"');?>
																<label for="checkbox_2"> keep me logged in </label>
															</div>
															<a
																class="capitalize-font txt-danger block pt-5 pull-right"
																href="forgot_password"><?php echo lang('login_forgot_password');?></a>
															<div class="clearfix"></div>
														</div>
														<div class="form-group">
															<?php echo form_submit('submit', 'Sign In',array('class'=>'btn btn-success btn-block')); ?>
														</div>
													<?php echo form_close();?>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
							