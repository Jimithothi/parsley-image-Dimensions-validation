			<div class="container-fluid">
				<!-- Title -->
				<div class="row heading-bg bg-blue">
					<div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
						<h5 class="txt-light"><?php echo $title;?></h5>
					</div>
					<!-- Breadcrumb -->
					<div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
						<ol class="breadcrumb">
							<li><a href="<?php echo base_url('dashboard')?>">Dashboard</a></li>
							<li class="active"><a href="<?php echo base_url('users')?>"><span>Users</span></a></li>
						</ol>
					</div>
					<!-- /Breadcrumb -->
				</div>
				<!-- /Title -->
				<!-- Row -->
				<div class="row">
					<div class="col-md-12">
						<div class="panel panel-default card-view">
							<div class="panel-heading">
								<div class="pull-left">
								</div>
								<div class="clearfix"></div>
							</div>
							<div class="panel-wrapper collapse in">
								<div class="panel-body">
									<div class="row">
										<div class="col-md-12">
											<div class="form-wrap">
													<?php 
													$attributes = array('method' => 'post','class'=>'form-horizontal');
													
													echo form_open("users/register", $attributes);
													?>

													<div class="form-body">

														<div class="row">
															<div class="col-md-12">
																<div class="form-group">
																	<?php echo form_label('Users Level*','users',array('class'=>'control-label col-md-2'));?>
																	<div class="col-md-10">
																	
																	<?php 
																		$attributes = 'class="form-control" id="users"';
																		echo form_dropdown('users', $users, set_value('users'), $attributes); 
																	?>
		
																	
																		<?php //echo form_input($facility_name);?>
																		<?php  echo form_error('users','<div class="infoMessage">* ','</div>'); ?>
																	</div>
																</div>
															</div>
															
															<div class="col-md-12">
																<div class="form-group">
																	<?php echo form_label('First Name*','first_name',array('class'=>'control-label col-md-2'));?>
																	<div class="col-md-10">
																		<?php echo form_input($first_name);?>
																		<?php echo form_error('first_name','<div class="infoMessage">* ','</div>'); ?>
																	</div>
																</div>
															</div>

															<div class="col-md-12">
																<div class="form-group">
																	<?php echo form_label('Last	Name*','last_name',array('class'=>'control-label col-md-2'));?>
																	<div class="col-md-10">
																		<?php echo form_input($last_name);?>
																		<?php echo form_error('last_name','<div class="infoMessage">* ','</div>'); ?>
																	</div>
																</div>
															</div>
															
															 <?php
															      if($identity_column!=='email') {
															          echo '<p>';
															          echo lang('create_user_identity_label', 'identity');
															          echo '<br />';
															          echo form_error('identity');
															          echo form_input($identity);
															          echo '</p>';
															      }
     														 ?>
      

															
															<div class="col-md-12">
																<div class="form-group">
																	<?php echo form_label('Primary Email*','email',array('class'=>'control-label col-md-2'));?>
																	<div class="col-md-10">
																		<?php echo form_input($email);?>
																		<?php echo form_error('email','<div class="infoMessage">* ','</div>'); ?>
																	</div>
																</div>
															</div>
															
															<div class="col-md-12">
																<div class="form-group">
																	<?php echo form_label('Facility	Name*','facility',array('class'=>'control-label col-md-2'));?>
																	<div class="col-md-10">
																	
																	<?php $attributes = 'class="form-control" id="facility"';
																			echo form_dropdown('facility', $facility, set_value('facility'), $attributes); ?>
																	
																	
																		<?php //echo form_input($facility_name);?>
																		<?php  echo form_error('facility','<div class="infoMessage">* ','</div>'); ?>
																	</div>
																</div>
															</div>
															

														</div>
														<div class="seprator-block"></div>
													</div>
													<div class="parent">
														<div class="child" style="position: fixed;bottom: 2.5%;right: 2.2%;z-index: 1;">
															<div class="pull-right">
																<br>
																<?php echo form_submit('submit', 'Submit',array('class'=>'btn btn-info btn-anim')); ?>
																<?php //echo form_submit('button', 'Sign In',array('class'=>'btn btn-warning btn-anim','onclick'=>base_url('facility'))); ?>
															</div>
														</div>
													</div>
												<?php echo form_close();?>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>