			<div class="container-fluid">
				<!-- Title -->
				<div class="row heading-bg bg-blue">
					<div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
						<h5 class="txt-light"><?php echo $title;?></h5>
					</div>
					<!-- Breadcrumb -->
					<div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
						<ol class="breadcrumb">
							<li><a href="<?php echo base_url('dashboard')?>">Dashboard</a></li>
							<li class="active"><a href="<?php echo base_url('facility')?>"><span>Facility</span></a></li>
						</ol>
					</div>
					<!-- /Breadcrumb -->
				</div>
				<!-- /Title -->
				<!-- Row -->
				<div class="row">
					<div class="col-md-12">
						<div class="panel panel-default card-view">
							<div class="panel-heading">
								<div class="pull-left">
								</div>
								<div class="clearfix"></div>
							</div>
							<div class="panel-wrapper collapse in">
								<div class="panel-body">
									<div class="row">
										<div class="col-md-12">
											<div class="form-wrap">
													<?php 
													$attributes = array('method' => 'post','class'=>'form-horizontal');
													
													echo form_open('assets/add', $attributes);
													?>

													<div class="form-body">

														<div class="row">
															<div class="col-md-12">
																<div class="form-group">
																	<?php echo form_label('Facility	Name*','facility',array('class'=>'control-label col-md-2'));?>
																	<div class="col-md-10">
																	
																	<?php $attributes = 'class="form-control" id="facility"';
																			echo form_dropdown('facility', $facility, set_value('facility'), $attributes); ?>
																	
																	
																		<?php //echo form_input($facility_name);?>
																		<?php  echo form_error('facility','<div class="infoMessage">* ','</div>'); ?>
																	</div>
																</div>
															</div>
															
															<div class="col-md-12">
																<div class="form-group">
																	<?php echo form_label('Kitchenette	Name*','kitchenette',array('class'=>'control-label col-md-2'));?>
																	<div class="col-md-10">
																	
																	<?php $attributes = 'class="form-control" id="kitchenette"';
																			echo form_dropdown('kitchenette', $kitchenette, set_value('kitchenette'), $attributes); ?>
																	
																	
																		<?php //echo form_input($facility_name);?>
																		<?php  echo form_error('kitchenette','<div class="infoMessage">* ','</div>'); ?>
																	</div>
																</div>
															</div>


															<div class="col-md-12">
																<div class="form-group">
																		<?php echo form_label('Fridge / Freezer*','freezer_fridge',array('class'=>'control-label col-md-2'));?>
																		<div class="col-md-10">
																					
																			<?php
																					
																			$options = array (
																				'' => 'Select Fridge / Freezer',
																				'fridge' => 'fridge',
																				'freezer' => 'freezer' 
																			);
																			$attributes = 'class="form-control" id="freezer_fridge"';
																			echo form_dropdown ( 'freezer_fridge', $options, set_value ( 'freezer_fridge' ), $attributes );
																			?>
																					
																			<?php //echo form_input($facility_name);?>
																			<?php  echo form_error('freezer_fridge','<div class="infoMessage">* ','</div>'); ?>
																					</div>
																</div>
															</div>
															
															<div class="col-md-12">
																<div class="form-group">
																	<?php echo form_label('Assets Name*','assets_name',array('class'=>'control-label col-md-2'));?>
																	<div class="col-md-10">
																		<?php echo form_input($assets_name);?>
																		<?php echo form_error('assets_name','<div class="infoMessage">* ','</div>'); ?>
																	</div>
																</div>
															</div>

														</div>
														<div class="seprator-block"></div>
													</div>
													<div class="parent">
														<div class="child" style="position: fixed;bottom: 2.5%;right: 2.2%;z-index: 1;">
															<div class="pull-right">
																<br>
																<?php echo form_submit('submit', 'Submit',array('class'=>'btn btn-info btn-anim')); ?>
																<?php //echo form_submit('button', 'Sign In',array('class'=>'btn btn-warning btn-anim','onclick'=>base_url('facility'))); ?>
															</div>
														</div>
													</div>
												<?php echo form_close();?>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
