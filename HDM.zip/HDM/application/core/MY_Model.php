<?php defined('BASEPATH') OR exit('No direct script access allowed');

class MY_Model extends CI_Model
{
	function __construct()
	{
		parent::__construct();
	}
	
	public function insertData($data)
	{
		$table = $this->table;
		$this->db->insert( $table,$data);
	}
	
	
	function getFacility()
	{
		$query = $this->db->get('facility');
		$result = $query->result();
	
		$facility_id = array('');
		$facility_name = array('-Select Facility-');
	
		for ($i = 0; $i < count($result); $i++)
		{
			array_push($facility_id, $result[$i]->facility_id);
			array_push($facility_name, $result[$i]->facility_name);
		}
		return array_combine($facility_id, $facility_name);
	}
	
	function getKitchenette()
	{
		$query = $this->db->get('kitchenette');
		$result = $query->result();
	
		$kitchenette_id = array('');
		$kitchenette_name = array('-Select Kitchenette-');
	
		for ($i = 0; $i < count($result); $i++)
		{
			array_push($kitchenette_id, $result[$i]->kitchenette_id);
			array_push($kitchenette_name, $result[$i]->kitchenette_name);
		}
		return array_combine($kitchenette_id, $kitchenette_name);
	}
	
	function getRole()
	{
		
		$query = $this->db->get('groups');
		$result = $query->result();
		
		$id = array('');
		$name = array('-Select User Level-');
		
		for ($i = 0; $i < count($result); $i++)
		{
			array_push($id, $result[$i]->id);
			array_push($name, $result[$i]->name);
		}
		return array_combine($id, $name);
		
	}
	
}
