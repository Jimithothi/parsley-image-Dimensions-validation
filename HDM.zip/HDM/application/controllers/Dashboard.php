<?php defined('BASEPATH') OR exit('No Direct access this script');

class Dashboard extends MY_Controller
{
	function __construct()
	{
		parent::__construct();
		
		if (!$this->ion_auth->logged_in())
		{
			redirect('auth/login', 'refresh');
		}
		$this->load->model('dashboardmodel');
		$this->model=$this->dashboardmodel;
		
		$this->data['site_url']="Dashboard - HDM";
		
	}
	public function index()
	{
		$this->data['title']="Dashboard";
		$this->data['facility']=$this->model->countRecord('facility');
		$this->data['kitchenette']=$this->model->countRecord('kitchenette');
		$this->data['assets']=$this->model->countRecord('assets');
		$this->data['users']=$this->model->countRecord('users');
		
		$this->data['content']=$this->_render_page('dashboard/index',$this->data,TRUE);
		$this->_render_page('layouts/main',$this->data);
	}
}
