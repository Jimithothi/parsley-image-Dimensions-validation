<?php defined('BASEPATH') OR exit('No direct this script');

class Facility extends MY_Controller
{
	function __construct()
	{
		parent::__construct();
		
		if (!$this->ion_auth->logged_in())
		{
			redirect('auth/login', 'refresh');
		}
		
		$this->load->model('facilitymodel');
		$this->model=$this->facilitymodel;
		
		$this->data['site_url']="Facility - HDM";
		
	}
	
	public function index()
	{
		$this->data['title']="Manage Facility";
		
		$this->data['content']=$this->_render_page('facility/index',$this->data,TRUE);
		$this->_render_page('layouts/main',$this->data);
		
	}
	
	public function get()
	{
	
		$result = $this->getData('facility', array( 'facility_id', 'facility_name', 'first_name', 'last_name', 'email'), 'facility_id', true);
	
		echo $result;
	}
	
	public function add()
	{
		$this->data['title']="Add Facility";
		if (!$this->ion_auth->logged_in())
		{
			redirect('auth', 'refresh');
		}
		
		$this->form_validation->set_rules('facility_name', 'facility_name', 'required');
		$this->form_validation->set_rules('first_name', 'first_name', 'required');
		$this->form_validation->set_rules('last_name', 'last_name', 'required');
		$this->form_validation->set_rules('phone', 'phone', 'required');
		$this->form_validation->set_rules('email', 'email', 'required');
		$this->form_validation->set_rules('address', 'address', 'required');
		$this->form_validation->set_rules('postcode', 'postcode', 'required');
		$this->form_validation->set_rules('city', 'city', 'required');
		$this->form_validation->set_rules('state', 'state', 'required');
		$this->form_validation->set_rules('country', 'country', 'required');
		
		if ($this->form_validation->run() == TRUE)
		{
			$data=array(
					'facility_name'=>$this->input->post('facility_name'),
					'first_name'=>$this->input->post('first_name'),
					'last_name'=>$this->input->post('last_name'),
					'phone'=>$this->input->post('phone'),
					'email'=>$this->input->post('email'),
					'address'=>$this->input->post('address'),
					'postcode'=>$this->input->post('postcode'),
					'city'=>$this->input->post('city'),
					'state'=>$this->input->post('state'),
					'country'=>$this->input->post('country')
			);
			
			$this->model->insertData($data);
			redirect('facility','refresh');
		}
		else
		{
			$this->data['facility_name'] = array(
					'name'  => 'facility_name',
					'id'    => 'facility_name',
					'type'  => 'text',
					'value' => $this->form_validation->set_value('facility_name'),
					'placeholder'=>'Facility Name',
					'class'=>'form-control'
			);
			$this->data['first_name'] = array(
					'name'  => 'first_name',
					'id'    => 'first_name',
					'type'  => 'text',
					'value' => $this->form_validation->set_value('first_name'),
					'placeholder'=>'First Name',
					'class'=>'form-control'
			);
			$this->data['last_name'] = array(
					'name'  => 'last_name',
					'id'    => 'last_name',
					'type'  => 'text',
					'value' => $this->form_validation->set_value('last_name'),
					'placeholder'=>'Last Name',
					'class'=>'form-control'
			);
			$this->data['phone'] = array(
					'name'  => 'phone',
					'id'    => 'phone',
					'type'  => 'text',
					'value' => $this->form_validation->set_value('phone'),
					'placeholder'=>'Phone',
					'class'=>'form-control'
			);
			$this->data['email'] = array(
					'name'  => 'email',
					'id'    => 'email',
					'type'  => 'text',
					'value' => $this->form_validation->set_value('email'),
					'placeholder'=>'Email',
					'class'=>'form-control'
			);
			$this->data['address'] = array(
					'name'  => 'address',
					'id'    => 'address',
					'type'  => 'textarea',
					'value' => $this->form_validation->set_value('address'),
					'class'	=> 'form-control',
					'rows'	=>3
			);
			$this->data['postcode'] = array(
					'name'  => 'postcode',
					'id'    => 'postcode',
					'type'  => 'text',
					'value' => $this->form_validation->set_value('postcode'),
					'placeholder'=>'Postcode',
					'class'=>'form-control'
			);
			$this->data['city'] = array(
					'name'  => 'city',
					'id'    => 'city',
					'type'  => 'text',
					'value' => $this->form_validation->set_value('city'),
					'placeholder'=>'City',
					'class'=>'form-control'
			);
			$this->data['state'] = array(
					'name'  => 'state',
					'id'    => 'state',
					'type'  => 'text',
					'value' => $this->form_validation->set_value('state'),
					'placeholder'=>'State',
					'class'=>'form-control'
			);
			$this->data['country'] = array(
					'name'  => 'country',
					'id'    => 'country',
					'type'  => 'text',
					'value' => $this->form_validation->set_value('country'),
					'placeholder'=>'Country',
					'class'=>'form-control'
			);
			$this->data['content']=$this->_render_page('facility/form',$this->data,TRUE);
			$this->_render_page('layouts/main',$this->data);
		
		}
	}
}