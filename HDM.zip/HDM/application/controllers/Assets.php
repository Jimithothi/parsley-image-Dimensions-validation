<?php defined('BASEPATH') OR exit('No direct this script');

class Assets extends MY_Controller
{
	function __construct()
	{
		parent::__construct();
		
		if (!$this->ion_auth->logged_in())
		{
			redirect('auth/login', 'refresh');
		}
		
		$this->load->model('assetsmodel');
		$this->model=$this->assetsmodel;
		
		$this->data['site_url']="Assets - HDM";
		
	}
	
	public function get()
	{
	
		$result = $this->getData('assets', array( 'assets_id', 'assets_name', 'kitchenette_id','fridge_freezer'), 'assets_id', true);
	
		echo $result;
	}
	
	public function index()
	{
		$this->data['title']="Manage Assets";
		$this->data['content']=$this->_render_page('assets/index',$this->data,TRUE);
		$this->_render_page('layouts/main',$this->data);
	}
	
	public function add()
	{
		$this->data['title']="Add Assets";
		if (!$this->ion_auth->logged_in())
		{
			redirect('auth', 'refresh');
		}
		$this->data['facility'] = $this->model->getFacility();
		$this->data['kitchenette']= $this->model->getKitchenette();
		
		$this->form_validation->set_rules('facility', 'Facility', 'required');
		$this->form_validation->set_rules('kitchenette', 'Kitchenette Name', 'required');
		$this->form_validation->set_rules('assets_name', 'Assets Name', 'required');
		$this->form_validation->set_rules('freezer_fridge', 'Fridge / Freezer', 'required');
		
		
		if ($this->form_validation->run() == TRUE)
		{
			$data=array(
					'facility_id'=>$this->input->post('facility'),
					'kitchenette_id'=>$this->input->post('kitchenette'),
					'fridge_freezer'=>$this->input->post('freezer_fridge'),
					'assets_name'=>$this->input->post('assets_name'),
			);
		
			$this->model->insertData($data);
			redirect('assets','refresh');
		}
		else
		{
			$this->data['assets_name'] = array(
					'name'  => 'assets_name',
					'id'    => 'assets_name',
					'type'  => 'text',
					'value' => $this->form_validation->set_value('assets_name'),
					'placeholder'=>'Assets Name',
					'class'=>'form-control'
			);
				
			$this->data['content']=$this->_render_page('assets/form',$this->data,TRUE);
			$this->_render_page('layouts/main',$this->data);
		
		}
		
	}
}