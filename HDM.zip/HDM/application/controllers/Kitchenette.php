<?php defined('BASEPATH') OR exit('No direct this script');

class Kitchenette extends MY_Controller
{
	function __construct()
	{
		parent::__construct();
		
		if (!$this->ion_auth->logged_in())
		{
			redirect('auth/login', 'refresh');
		}
		
		$this->load->model('kitchenettemodel');
		$this->model=$this->kitchenettemodel;
		
		$this->data['site_url']="Kitchenette - HDM";
	}
	
	public function index()
	{
		$this->data['title']="Manage Kitchenette";
		
		$this->data['content']=$this->_render_page('kitchenette/index',$this->data,TRUE);
		$this->_render_page('layouts/main',$this->data);
	}
	
	public function get()
	{
		
		$result = $this->getData('kitchenette', array( 'kitchenette_id', 'kitchenette_name', 'facility_id'), 'kitchenette_id', true);
	
		echo $result;
	}
	
	public function add()
	{
		$this->data['title']="Add Kitchenette";
		
		if (!$this->ion_auth->logged_in())
		{
			redirect('auth', 'refresh');
		}
		$this->data['facility'] = $this->model->getFacility();
		
		$this->form_validation->set_rules('facility', 'Facility', 'required');
		$this->form_validation->set_rules('kitchenette_name', 'Kitchenette Name', 'required');
		
		if ($this->form_validation->run() == TRUE)
		{
			$data=array(
					'kitchenette_name'=>$this->input->post('kitchenette_name'),
					'facility_id'=>$this->input->post('facility'),
			);
				
			$this->model->insertData($data);
			redirect('kitchenette','refresh');
		}
		else
		{
			$this->data['kitchenette_name'] = array(
					'name'  => 'kitchenette_name',
					'id'    => 'kitchenette_name',
					'type'  => 'text',
					'value' => $this->form_validation->set_value('kitchenette_name'),
					'placeholder'=>'Kitchenette Name',
					'class'=>'form-control'
			);
			
			$this->data['content']=$this->_render_page('kitchenette/form',$this->data,TRUE);
			$this->_render_page('layouts/main',$this->data);
		
		}
	}
	
	
}




