<?php defined('BASEPATH') OR exit('No Direct Access');

class Usersmodel extends MY_Model
{
	
	function __construct()
	{
		parent::__construct();
		
	}
	
}