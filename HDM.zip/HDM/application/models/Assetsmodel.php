<?php defined('BASEPATH') OR exit('No direct this script');

class Assetsmodel extends MY_Model
{
	var $table="assets";
	var $primaryKey ="assets_id";
	
	function __construct()
	{
		parent::__construct();
		
	}
}