<?php defined('BASEPATH') OR exit('No direct access this file');

class Dashboardmodel extends MY_Model
{
	function __construct()
	{
		parent::__construct();
	}
	
	public function countRecord($table)
	{
		$query = $this->db->select('*')->get($table);
		
		$result = $query->result();

		return count($result);
	}
	
}