<?php defined('BASEPATH') OR exit('No direct this script');

class Kitchenettemodel extends MY_Model
{
	var $table="kitchenette";
	var $primaryKey ="kitchenette_id";
	
	function __construct()
	{
		parent::__construct();
	}
	
}