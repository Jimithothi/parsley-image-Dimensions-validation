<?php defined('BASEPATH') OR exit('No direct this script');

class Facilitymodel extends MY_Model
{
	var $table='facility';
	var $primaryKey ='facility_id';
	
	function __construct()
	{
		parent::__construct();
	}
	
	
}