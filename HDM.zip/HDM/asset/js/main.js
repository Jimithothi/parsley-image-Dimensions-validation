$(document).ready(function() {
	
	$.fn.dataTable.ext.errMode = 'none';
	
	var productTable = $("#kitchenette").dataTable({
		"bSortClasses": false,
		responsive: true,
		"bProcessing": false,
		"bServerSide": true,
		"sAjaxSource": "kitchenette/get",
		"aaSorting": [[1, "asc"]], // Set default sort by "code" column
		"aLengthMenu": [[5, 10, 15, 25, 50, 100 , -1], [5, 10, 15, 25, 50, 100, "All"]],
		"iDisplayLength" : 5,
		"bInfo" : false,
		"dom": '<"pull-left"><"pull-right"l>tip<"bottom">',
		"aoColumns": [
			{ "sClass": "num center", "mData": 0, "bSortable": false, "bSearchable": false, "sWidth": "50px" },
			{ "sClass": "kitchenette_name", "mData": 1 },
			{ "sClass": "facility_id", "mData": 2 },
		],
	});
	
	var assetsTable=$("#assets").dataTable({
		"bSortClasses": false,
		responsive: true,
		"bProcessing": false,
		"bServerSide": true,
		"sAjaxSource": "assets/get",
		"aaSorting": [[1, "asc"]], // Set default sort by "code" column
		"aLengthMenu": [[5, 10, 15, 25, 50, 100 , -1], [5, 10, 15, 25, 50, 100, "All"]],
		"iDisplayLength" : 5,
		"bInfo" : false,
		"dom": '<"pull-left"><"pull-right"l>tip<"bottom">',
		"aoColumns": [
			{ "sClass": "num center", "mData": 0, "bSortable": false, "bSearchable": false, "sWidth": "50px" },
			{ "sClass": "assets_name", "mData": 1 },
			{ "sClass": "kitchenette_id", "mData": 2 },
			{ "sClass": "fridge_freezer", "mData": 3}
		],
	});
	
	var facilityTable=$("#facility").dataTable({
		"bSortClasses": false,
		responsive: true,
		"bProcessing": false,
		"bServerSide": true,
		"sAjaxSource": "facility/get",
		"aaSorting": [[1, "asc"]], // Set default sort by "code" column
		"aLengthMenu": [[5, 10, 15, 25, 50, 100 , -1], [5, 10, 15, 25, 50, 100, "All"]],
		"iDisplayLength" : 5,
		"bInfo" : false,
//		"bFilter": false,  // search bar 
		"dom": '<"pull-left"><"pull-right"l>tip<"bottom">',
		"aoColumns": [
			{ "sClass": "num center", "mData": 0, "bSortable": false, "bSearchable": false, "sWidth": "50px" },
			{ "sClass": "facility_name", "mData": 1 },
			{ "sClass": "first_name", "mData": 2 },
			{ "sClass": "last_name", "mData": 3},
			{ "sClass": "email", "mData": 4}
		],
	});
	
	
	var userssTable=$("#users").dataTable({
		"bSortClasses": false,
		responsive: true,
		"bProcessing": false,
		"bServerSide": true,
		"sAjaxSource": "users/get",
		"aaSorting": [[1, "asc"]], // Set default sort by "code" column
		"aLengthMenu": [[5, 10, 15, 25, 50, 100 , -1], [5, 10, 15, 25, 50, 100, "All"]],
		"iDisplayLength" : 5,
		"bInfo" : false,
		"dom": '<"pull-left"><"pull-right"l>tip<"bottom">',
		"aoColumns": [
			{ "sClass": "num center", "mData": 0, "bSortable": false, "bSearchable": false, "sWidth": "50px" },
			{ "sClass": "first_name", "mData": 1 },
			{ "sClass": "facility_id", "mData": 2 },
			{ "sClass": "email", "mData": 3}
		],
	});
	
	$.fn.dataTable.ext.errMode = 'none';
	$("#usersSearch").keypress(function (e) {
		   //e.preventDefault();
		if(e.which == 13) {
	        $('#users').DataTable().search($(this).val()).draw();
	    }
	});
	$( "#usersSearchbtn" ).click(function() {
		var fv=$("#usersSearch").val();
		$('#users').DataTable().search(fv).draw();
	});
	
	
	
	$("#facilitySearch").keypress(function (e) {
		   //e.preventDefault();
		if(e.which == 13) {
	        $('#facility').DataTable().search($(this).val()).draw();
	    }
	});
	$( "#facilitySearchbtn" ).click(function() {
		var fv=$("#facilitySearch").val();
		$('#facility').DataTable().search(fv).draw();
	});
	$("#assetsSearch").keypress(function (e) {
		if(e.which == 13) {
		   $('#assets').DataTable().search($(this).val()).draw();
		}
	});
	$( "#assetsSearchbtn" ).click(function() {
		var av=$("#assetsSearch").val();
		$('#assets').DataTable().search(av).draw();
	});
	$("#kitchenetteSearch").keypress(function (e) {
		   //e.preventDefault();
		if(e.which == 13) {
			$('#kitchenette').DataTable().search($(this).val()).draw();
		}
	});
	$( "#kitchenetteSearchbtn" ).click(function() {
		var kv=$("#kitchenetteSearch").val();
		$('#kitchenette').DataTable().search(kv).draw();
	});
});

