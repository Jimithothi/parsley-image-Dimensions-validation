<?php 

define('CNF_EMAIL','jimit@ikraftsolutions.com',true);

define('CNF_ACTIVATION','auto');
define('FB_PAGE','https://facebook.com/');
define('GOOGLE_PLUS','https://plus.google.com/');
define('TWITTER','https://www.twitter.com/');
define('CONTACT_MAIL','contacto@grupoproyectarte.com');
define('PHONE_CONTACT','01(55) 5286-6272');




?>