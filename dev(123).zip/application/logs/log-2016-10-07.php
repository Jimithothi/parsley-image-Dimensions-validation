<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-10-07 14:14:25 --> Config Class Initialized
INFO - 2016-10-07 14:14:25 --> Hooks Class Initialized
DEBUG - 2016-10-07 14:14:25 --> UTF-8 Support Enabled
INFO - 2016-10-07 14:14:25 --> Utf8 Class Initialized
INFO - 2016-10-07 14:14:25 --> URI Class Initialized
INFO - 2016-10-07 14:14:25 --> Router Class Initialized
INFO - 2016-10-07 14:14:25 --> Output Class Initialized
INFO - 2016-10-07 14:14:25 --> Security Class Initialized
DEBUG - 2016-10-07 14:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-07 14:14:25 --> Input Class Initialized
INFO - 2016-10-07 14:14:25 --> Language Class Initialized
INFO - 2016-10-07 14:14:25 --> Loader Class Initialized
DEBUG - 2016-10-07 14:14:25 --> Config file loaded: D:\xampp\htdocs\dev-proyectarte\application\config/pagination.php
INFO - 2016-10-07 14:14:25 --> Helper loaded: url_helper
INFO - 2016-10-07 14:14:25 --> Helper loaded: site_helper
INFO - 2016-10-07 14:14:25 --> Helper loaded: form_helper
INFO - 2016-10-07 14:14:25 --> Helper loaded: date_helper
INFO - 2016-10-07 14:14:25 --> Helper loaded: string_helper
INFO - 2016-10-07 14:14:25 --> Helper loaded: file_helper
INFO - 2016-10-07 14:14:25 --> Helper loaded: frontend_helper
INFO - 2016-10-07 14:14:25 --> Helper loaded: text_helper
INFO - 2016-10-07 14:14:25 --> Database Driver Class Initialized
DEBUG - 2016-10-07 14:14:25 --> Session Class Initialized
INFO - 2016-10-07 14:14:25 --> Encrypt Class Initialized
DEBUG - 2016-10-07 14:14:25 --> Session routines successfully run
INFO - 2016-10-07 14:14:25 --> Parser Class Initialized
INFO - 2016-10-07 14:14:25 --> Language file loaded: language/en/pagination_lang.php
INFO - 2016-10-07 14:14:25 --> Pagination Class Initialized
INFO - 2016-10-07 14:14:25 --> User Agent Class Initialized
INFO - 2016-10-07 14:14:25 --> Form Validation Class Initialized
INFO - 2016-10-07 14:14:25 --> Upload Class Initialized
INFO - 2016-10-07 14:14:25 --> Controller Class Initialized
INFO - 2016-10-07 14:14:25 --> Config Class Initialized
INFO - 2016-10-07 14:14:25 --> Hooks Class Initialized
DEBUG - 2016-10-07 14:14:25 --> UTF-8 Support Enabled
INFO - 2016-10-07 14:14:25 --> Utf8 Class Initialized
INFO - 2016-10-07 14:14:25 --> URI Class Initialized
INFO - 2016-10-07 14:14:25 --> Router Class Initialized
INFO - 2016-10-07 14:14:25 --> Output Class Initialized
INFO - 2016-10-07 14:14:25 --> Security Class Initialized
DEBUG - 2016-10-07 14:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-07 14:14:25 --> Input Class Initialized
INFO - 2016-10-07 14:14:25 --> Language Class Initialized
INFO - 2016-10-07 14:14:25 --> Loader Class Initialized
DEBUG - 2016-10-07 14:14:25 --> Config file loaded: D:\xampp\htdocs\dev-proyectarte\application\config/pagination.php
INFO - 2016-10-07 14:14:25 --> Helper loaded: url_helper
INFO - 2016-10-07 14:14:25 --> Helper loaded: site_helper
INFO - 2016-10-07 14:14:25 --> Helper loaded: form_helper
INFO - 2016-10-07 14:14:25 --> Helper loaded: date_helper
INFO - 2016-10-07 14:14:25 --> Helper loaded: string_helper
INFO - 2016-10-07 14:14:25 --> Helper loaded: file_helper
INFO - 2016-10-07 14:14:25 --> Helper loaded: frontend_helper
INFO - 2016-10-07 14:14:25 --> Helper loaded: text_helper
INFO - 2016-10-07 14:14:25 --> Database Driver Class Initialized
DEBUG - 2016-10-07 14:14:25 --> Session Class Initialized
INFO - 2016-10-07 14:14:25 --> Encrypt Class Initialized
DEBUG - 2016-10-07 14:14:25 --> Session routines successfully run
INFO - 2016-10-07 14:14:25 --> Parser Class Initialized
INFO - 2016-10-07 14:14:25 --> Language file loaded: language/en/pagination_lang.php
INFO - 2016-10-07 14:14:25 --> Pagination Class Initialized
INFO - 2016-10-07 14:14:25 --> User Agent Class Initialized
INFO - 2016-10-07 14:14:25 --> Form Validation Class Initialized
INFO - 2016-10-07 14:14:25 --> Upload Class Initialized
INFO - 2016-10-07 14:14:25 --> Controller Class Initialized
INFO - 2016-10-07 14:14:25 --> Language file loaded: language/en/core_lang.php
DEBUG - 2016-10-07 14:14:25 --> Upload class already loaded. Second attempt ignored.
INFO - 2016-10-07 14:14:25 --> Image Lib Class Initialized
INFO - 2016-10-07 14:14:25 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\dashboard.php
INFO - 2016-10-07 14:14:25 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\admin/layouts/sidemenu.php
INFO - 2016-10-07 14:14:25 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\admin/layouts/headmenu.php
INFO - 2016-10-07 14:14:25 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\admin/layouts/main.php
INFO - 2016-10-07 14:14:25 --> Final output sent to browser
DEBUG - 2016-10-07 14:14:25 --> Total execution time: 0.0930
INFO - 2016-10-07 14:14:28 --> Config Class Initialized
INFO - 2016-10-07 14:14:28 --> Hooks Class Initialized
DEBUG - 2016-10-07 14:14:28 --> UTF-8 Support Enabled
INFO - 2016-10-07 14:14:28 --> Utf8 Class Initialized
INFO - 2016-10-07 14:14:28 --> URI Class Initialized
INFO - 2016-10-07 14:14:28 --> Router Class Initialized
INFO - 2016-10-07 14:14:28 --> Output Class Initialized
INFO - 2016-10-07 14:14:28 --> Security Class Initialized
DEBUG - 2016-10-07 14:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-07 14:14:28 --> Input Class Initialized
INFO - 2016-10-07 14:14:28 --> Language Class Initialized
INFO - 2016-10-07 14:14:28 --> Loader Class Initialized
DEBUG - 2016-10-07 14:14:28 --> Config file loaded: D:\xampp\htdocs\dev-proyectarte\application\config/pagination.php
INFO - 2016-10-07 14:14:28 --> Helper loaded: url_helper
INFO - 2016-10-07 14:14:28 --> Helper loaded: site_helper
INFO - 2016-10-07 14:14:28 --> Helper loaded: form_helper
INFO - 2016-10-07 14:14:28 --> Helper loaded: date_helper
INFO - 2016-10-07 14:14:28 --> Helper loaded: string_helper
INFO - 2016-10-07 14:14:28 --> Helper loaded: file_helper
INFO - 2016-10-07 14:14:28 --> Helper loaded: frontend_helper
INFO - 2016-10-07 14:14:28 --> Helper loaded: text_helper
INFO - 2016-10-07 14:14:28 --> Database Driver Class Initialized
DEBUG - 2016-10-07 14:14:28 --> Session Class Initialized
INFO - 2016-10-07 14:14:28 --> Encrypt Class Initialized
DEBUG - 2016-10-07 14:14:28 --> Session routines successfully run
INFO - 2016-10-07 14:14:28 --> Parser Class Initialized
INFO - 2016-10-07 14:14:28 --> Language file loaded: language/en/pagination_lang.php
INFO - 2016-10-07 14:14:28 --> Pagination Class Initialized
INFO - 2016-10-07 14:14:28 --> User Agent Class Initialized
INFO - 2016-10-07 14:14:28 --> Form Validation Class Initialized
INFO - 2016-10-07 14:14:28 --> Upload Class Initialized
INFO - 2016-10-07 14:14:28 --> Controller Class Initialized
INFO - 2016-10-07 14:14:28 --> Language file loaded: language/en/core_lang.php
DEBUG - 2016-10-07 14:14:28 --> Upload class already loaded. Second attempt ignored.
INFO - 2016-10-07 14:14:28 --> Image Lib Class Initialized
INFO - 2016-10-07 14:14:28 --> Model Class Initialized
INFO - 2016-10-07 14:14:28 --> Model Class Initialized
INFO - 2016-10-07 14:14:28 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\footer.php
INFO - 2016-10-07 14:14:28 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\admin/area/index.php
INFO - 2016-10-07 14:14:28 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\admin/layouts/sidemenu.php
INFO - 2016-10-07 14:14:28 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\admin/layouts/headmenu.php
INFO - 2016-10-07 14:14:28 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\admin/layouts/main.php
INFO - 2016-10-07 14:14:28 --> Final output sent to browser
DEBUG - 2016-10-07 14:14:28 --> Total execution time: 0.0970
INFO - 2016-10-07 14:14:29 --> Config Class Initialized
INFO - 2016-10-07 14:14:29 --> Hooks Class Initialized
DEBUG - 2016-10-07 14:14:29 --> UTF-8 Support Enabled
INFO - 2016-10-07 14:14:29 --> Utf8 Class Initialized
INFO - 2016-10-07 14:14:29 --> URI Class Initialized
INFO - 2016-10-07 14:14:29 --> Router Class Initialized
INFO - 2016-10-07 14:14:29 --> Output Class Initialized
INFO - 2016-10-07 14:14:29 --> Security Class Initialized
DEBUG - 2016-10-07 14:14:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-07 14:14:29 --> Input Class Initialized
INFO - 2016-10-07 14:14:29 --> Language Class Initialized
INFO - 2016-10-07 14:14:29 --> Loader Class Initialized
DEBUG - 2016-10-07 14:14:29 --> Config file loaded: D:\xampp\htdocs\dev-proyectarte\application\config/pagination.php
INFO - 2016-10-07 14:14:29 --> Helper loaded: url_helper
INFO - 2016-10-07 14:14:29 --> Helper loaded: site_helper
INFO - 2016-10-07 14:14:29 --> Helper loaded: form_helper
INFO - 2016-10-07 14:14:29 --> Helper loaded: date_helper
INFO - 2016-10-07 14:14:29 --> Helper loaded: string_helper
INFO - 2016-10-07 14:14:29 --> Helper loaded: file_helper
INFO - 2016-10-07 14:14:29 --> Helper loaded: frontend_helper
INFO - 2016-10-07 14:14:29 --> Helper loaded: text_helper
INFO - 2016-10-07 14:14:29 --> Database Driver Class Initialized
DEBUG - 2016-10-07 14:14:29 --> Session Class Initialized
INFO - 2016-10-07 14:14:29 --> Encrypt Class Initialized
DEBUG - 2016-10-07 14:14:29 --> Session routines successfully run
INFO - 2016-10-07 14:14:29 --> Parser Class Initialized
INFO - 2016-10-07 14:14:29 --> Language file loaded: language/en/pagination_lang.php
INFO - 2016-10-07 14:14:29 --> Pagination Class Initialized
INFO - 2016-10-07 14:14:29 --> User Agent Class Initialized
INFO - 2016-10-07 14:14:29 --> Form Validation Class Initialized
INFO - 2016-10-07 14:14:29 --> Upload Class Initialized
INFO - 2016-10-07 14:14:29 --> Controller Class Initialized
INFO - 2016-10-07 14:14:29 --> Language file loaded: language/en/core_lang.php
DEBUG - 2016-10-07 14:14:29 --> Upload class already loaded. Second attempt ignored.
INFO - 2016-10-07 14:14:29 --> Image Lib Class Initialized
INFO - 2016-10-07 14:14:29 --> Model Class Initialized
INFO - 2016-10-07 14:14:29 --> Model Class Initialized
INFO - 2016-10-07 14:14:29 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\footer.php
INFO - 2016-10-07 14:14:29 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\admin/banner/index.php
INFO - 2016-10-07 14:14:29 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\admin/layouts/sidemenu.php
INFO - 2016-10-07 14:14:29 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\admin/layouts/headmenu.php
INFO - 2016-10-07 14:14:29 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\admin/layouts/main.php
INFO - 2016-10-07 14:14:29 --> Final output sent to browser
DEBUG - 2016-10-07 14:14:29 --> Total execution time: 0.0890
INFO - 2016-10-07 14:14:30 --> Config Class Initialized
INFO - 2016-10-07 14:14:30 --> Hooks Class Initialized
DEBUG - 2016-10-07 14:14:30 --> UTF-8 Support Enabled
INFO - 2016-10-07 14:14:30 --> Utf8 Class Initialized
INFO - 2016-10-07 14:14:30 --> URI Class Initialized
INFO - 2016-10-07 14:14:30 --> Router Class Initialized
INFO - 2016-10-07 14:14:30 --> Output Class Initialized
INFO - 2016-10-07 14:14:30 --> Security Class Initialized
DEBUG - 2016-10-07 14:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-07 14:14:30 --> Input Class Initialized
INFO - 2016-10-07 14:14:30 --> Language Class Initialized
INFO - 2016-10-07 14:14:30 --> Loader Class Initialized
DEBUG - 2016-10-07 14:14:30 --> Config file loaded: D:\xampp\htdocs\dev-proyectarte\application\config/pagination.php
INFO - 2016-10-07 14:14:30 --> Helper loaded: url_helper
INFO - 2016-10-07 14:14:30 --> Helper loaded: site_helper
INFO - 2016-10-07 14:14:30 --> Helper loaded: form_helper
INFO - 2016-10-07 14:14:30 --> Helper loaded: date_helper
INFO - 2016-10-07 14:14:30 --> Helper loaded: string_helper
INFO - 2016-10-07 14:14:30 --> Helper loaded: file_helper
INFO - 2016-10-07 14:14:30 --> Helper loaded: frontend_helper
INFO - 2016-10-07 14:14:30 --> Helper loaded: text_helper
INFO - 2016-10-07 14:14:30 --> Database Driver Class Initialized
DEBUG - 2016-10-07 14:14:30 --> Session Class Initialized
INFO - 2016-10-07 14:14:30 --> Encrypt Class Initialized
DEBUG - 2016-10-07 14:14:30 --> Session routines successfully run
INFO - 2016-10-07 14:14:30 --> Parser Class Initialized
INFO - 2016-10-07 14:14:30 --> Language file loaded: language/en/pagination_lang.php
INFO - 2016-10-07 14:14:30 --> Pagination Class Initialized
INFO - 2016-10-07 14:14:30 --> User Agent Class Initialized
INFO - 2016-10-07 14:14:30 --> Form Validation Class Initialized
INFO - 2016-10-07 14:14:30 --> Upload Class Initialized
INFO - 2016-10-07 14:14:30 --> Controller Class Initialized
INFO - 2016-10-07 14:14:30 --> Language file loaded: language/en/core_lang.php
DEBUG - 2016-10-07 14:14:30 --> Upload class already loaded. Second attempt ignored.
INFO - 2016-10-07 14:14:30 --> Image Lib Class Initialized
INFO - 2016-10-07 14:14:30 --> Model Class Initialized
INFO - 2016-10-07 14:14:30 --> Model Class Initialized
INFO - 2016-10-07 14:14:30 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\footer.php
INFO - 2016-10-07 14:14:30 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\admin/category/index.php
INFO - 2016-10-07 14:14:30 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\admin/layouts/sidemenu.php
INFO - 2016-10-07 14:14:30 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\admin/layouts/headmenu.php
INFO - 2016-10-07 14:14:30 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\admin/layouts/main.php
INFO - 2016-10-07 14:14:30 --> Final output sent to browser
DEBUG - 2016-10-07 14:14:30 --> Total execution time: 0.0950
INFO - 2016-10-07 14:14:31 --> Config Class Initialized
INFO - 2016-10-07 14:14:31 --> Hooks Class Initialized
DEBUG - 2016-10-07 14:14:31 --> UTF-8 Support Enabled
INFO - 2016-10-07 14:14:31 --> Utf8 Class Initialized
INFO - 2016-10-07 14:14:31 --> URI Class Initialized
INFO - 2016-10-07 14:14:31 --> Router Class Initialized
INFO - 2016-10-07 14:14:31 --> Output Class Initialized
INFO - 2016-10-07 14:14:31 --> Security Class Initialized
DEBUG - 2016-10-07 14:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-07 14:14:31 --> Input Class Initialized
INFO - 2016-10-07 14:14:31 --> Language Class Initialized
INFO - 2016-10-07 14:14:31 --> Loader Class Initialized
DEBUG - 2016-10-07 14:14:31 --> Config file loaded: D:\xampp\htdocs\dev-proyectarte\application\config/pagination.php
INFO - 2016-10-07 14:14:31 --> Helper loaded: url_helper
INFO - 2016-10-07 14:14:31 --> Helper loaded: site_helper
INFO - 2016-10-07 14:14:31 --> Helper loaded: form_helper
INFO - 2016-10-07 14:14:31 --> Helper loaded: date_helper
INFO - 2016-10-07 14:14:31 --> Helper loaded: string_helper
INFO - 2016-10-07 14:14:31 --> Helper loaded: file_helper
INFO - 2016-10-07 14:14:31 --> Helper loaded: frontend_helper
INFO - 2016-10-07 14:14:31 --> Helper loaded: text_helper
INFO - 2016-10-07 14:14:31 --> Database Driver Class Initialized
DEBUG - 2016-10-07 14:14:31 --> Session Class Initialized
INFO - 2016-10-07 14:14:31 --> Encrypt Class Initialized
DEBUG - 2016-10-07 14:14:31 --> Session routines successfully run
INFO - 2016-10-07 14:14:31 --> Parser Class Initialized
INFO - 2016-10-07 14:14:31 --> Language file loaded: language/en/pagination_lang.php
INFO - 2016-10-07 14:14:31 --> Pagination Class Initialized
INFO - 2016-10-07 14:14:31 --> User Agent Class Initialized
INFO - 2016-10-07 14:14:31 --> Form Validation Class Initialized
INFO - 2016-10-07 14:14:31 --> Upload Class Initialized
INFO - 2016-10-07 14:14:31 --> Controller Class Initialized
INFO - 2016-10-07 14:14:31 --> Language file loaded: language/en/core_lang.php
DEBUG - 2016-10-07 14:14:31 --> Upload class already loaded. Second attempt ignored.
INFO - 2016-10-07 14:14:31 --> Image Lib Class Initialized
INFO - 2016-10-07 14:14:31 --> Model Class Initialized
INFO - 2016-10-07 14:14:31 --> Model Class Initialized
INFO - 2016-10-07 14:14:31 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\footer.php
INFO - 2016-10-07 14:14:31 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\admin/managecms/index.php
INFO - 2016-10-07 14:14:31 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\admin/layouts/sidemenu.php
INFO - 2016-10-07 14:14:31 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\admin/layouts/headmenu.php
INFO - 2016-10-07 14:14:31 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\admin/layouts/main.php
INFO - 2016-10-07 14:14:31 --> Final output sent to browser
DEBUG - 2016-10-07 14:14:31 --> Total execution time: 0.1240
INFO - 2016-10-07 14:14:32 --> Config Class Initialized
INFO - 2016-10-07 14:14:32 --> Hooks Class Initialized
DEBUG - 2016-10-07 14:14:32 --> UTF-8 Support Enabled
INFO - 2016-10-07 14:14:32 --> Utf8 Class Initialized
INFO - 2016-10-07 14:14:32 --> URI Class Initialized
INFO - 2016-10-07 14:14:32 --> Router Class Initialized
INFO - 2016-10-07 14:14:32 --> Output Class Initialized
INFO - 2016-10-07 14:14:32 --> Security Class Initialized
DEBUG - 2016-10-07 14:14:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-07 14:14:32 --> Input Class Initialized
INFO - 2016-10-07 14:14:32 --> Language Class Initialized
INFO - 2016-10-07 14:14:32 --> Loader Class Initialized
DEBUG - 2016-10-07 14:14:32 --> Config file loaded: D:\xampp\htdocs\dev-proyectarte\application\config/pagination.php
INFO - 2016-10-07 14:14:32 --> Helper loaded: url_helper
INFO - 2016-10-07 14:14:32 --> Helper loaded: site_helper
INFO - 2016-10-07 14:14:32 --> Helper loaded: form_helper
INFO - 2016-10-07 14:14:32 --> Helper loaded: date_helper
INFO - 2016-10-07 14:14:32 --> Helper loaded: string_helper
INFO - 2016-10-07 14:14:32 --> Helper loaded: file_helper
INFO - 2016-10-07 14:14:32 --> Helper loaded: frontend_helper
INFO - 2016-10-07 14:14:32 --> Helper loaded: text_helper
INFO - 2016-10-07 14:14:32 --> Database Driver Class Initialized
DEBUG - 2016-10-07 14:14:32 --> Session Class Initialized
INFO - 2016-10-07 14:14:32 --> Encrypt Class Initialized
DEBUG - 2016-10-07 14:14:32 --> Session routines successfully run
INFO - 2016-10-07 14:14:32 --> Parser Class Initialized
INFO - 2016-10-07 14:14:32 --> Language file loaded: language/en/pagination_lang.php
INFO - 2016-10-07 14:14:32 --> Pagination Class Initialized
INFO - 2016-10-07 14:14:32 --> User Agent Class Initialized
INFO - 2016-10-07 14:14:32 --> Form Validation Class Initialized
INFO - 2016-10-07 14:14:32 --> Upload Class Initialized
INFO - 2016-10-07 14:14:32 --> Controller Class Initialized
INFO - 2016-10-07 14:14:32 --> Language file loaded: language/en/core_lang.php
DEBUG - 2016-10-07 14:14:32 --> Upload class already loaded. Second attempt ignored.
INFO - 2016-10-07 14:14:32 --> Image Lib Class Initialized
INFO - 2016-10-07 14:14:32 --> Model Class Initialized
INFO - 2016-10-07 14:14:32 --> Model Class Initialized
INFO - 2016-10-07 14:14:32 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\footer.php
INFO - 2016-10-07 14:14:32 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\admin/software/index.php
INFO - 2016-10-07 14:14:32 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\admin/layouts/sidemenu.php
INFO - 2016-10-07 14:14:32 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\admin/layouts/headmenu.php
INFO - 2016-10-07 14:14:32 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\admin/layouts/main.php
INFO - 2016-10-07 14:14:32 --> Final output sent to browser
DEBUG - 2016-10-07 14:14:32 --> Total execution time: 0.1010
INFO - 2016-10-07 14:14:33 --> Config Class Initialized
INFO - 2016-10-07 14:14:33 --> Hooks Class Initialized
DEBUG - 2016-10-07 14:14:33 --> UTF-8 Support Enabled
INFO - 2016-10-07 14:14:33 --> Utf8 Class Initialized
INFO - 2016-10-07 14:14:33 --> URI Class Initialized
INFO - 2016-10-07 14:14:33 --> Router Class Initialized
INFO - 2016-10-07 14:14:33 --> Output Class Initialized
INFO - 2016-10-07 14:14:33 --> Security Class Initialized
DEBUG - 2016-10-07 14:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-07 14:14:33 --> Input Class Initialized
INFO - 2016-10-07 14:14:33 --> Language Class Initialized
INFO - 2016-10-07 14:14:33 --> Loader Class Initialized
DEBUG - 2016-10-07 14:14:33 --> Config file loaded: D:\xampp\htdocs\dev-proyectarte\application\config/pagination.php
INFO - 2016-10-07 14:14:33 --> Helper loaded: url_helper
INFO - 2016-10-07 14:14:33 --> Helper loaded: site_helper
INFO - 2016-10-07 14:14:33 --> Helper loaded: form_helper
INFO - 2016-10-07 14:14:33 --> Helper loaded: date_helper
INFO - 2016-10-07 14:14:33 --> Helper loaded: string_helper
INFO - 2016-10-07 14:14:33 --> Helper loaded: file_helper
INFO - 2016-10-07 14:14:33 --> Helper loaded: frontend_helper
INFO - 2016-10-07 14:14:33 --> Helper loaded: text_helper
INFO - 2016-10-07 14:14:33 --> Database Driver Class Initialized
DEBUG - 2016-10-07 14:14:33 --> Session Class Initialized
INFO - 2016-10-07 14:14:33 --> Encrypt Class Initialized
DEBUG - 2016-10-07 14:14:33 --> Session routines successfully run
INFO - 2016-10-07 14:14:33 --> Parser Class Initialized
INFO - 2016-10-07 14:14:33 --> Language file loaded: language/en/pagination_lang.php
INFO - 2016-10-07 14:14:33 --> Pagination Class Initialized
INFO - 2016-10-07 14:14:33 --> User Agent Class Initialized
INFO - 2016-10-07 14:14:33 --> Form Validation Class Initialized
INFO - 2016-10-07 14:14:33 --> Upload Class Initialized
INFO - 2016-10-07 14:14:33 --> Controller Class Initialized
INFO - 2016-10-07 14:14:33 --> Language file loaded: language/en/core_lang.php
DEBUG - 2016-10-07 14:14:33 --> Upload class already loaded. Second attempt ignored.
INFO - 2016-10-07 14:14:33 --> Image Lib Class Initialized
INFO - 2016-10-07 14:14:33 --> Model Class Initialized
INFO - 2016-10-07 14:14:33 --> Model Class Initialized
INFO - 2016-10-07 14:14:33 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\footer.php
INFO - 2016-10-07 14:14:33 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\admin/course/index.php
INFO - 2016-10-07 14:14:33 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\admin/layouts/sidemenu.php
INFO - 2016-10-07 14:14:33 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\admin/layouts/headmenu.php
INFO - 2016-10-07 14:14:33 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\admin/layouts/main.php
INFO - 2016-10-07 14:14:33 --> Final output sent to browser
DEBUG - 2016-10-07 14:14:33 --> Total execution time: 0.0860
INFO - 2016-10-07 14:14:34 --> Config Class Initialized
INFO - 2016-10-07 14:14:34 --> Hooks Class Initialized
DEBUG - 2016-10-07 14:14:34 --> UTF-8 Support Enabled
INFO - 2016-10-07 14:14:34 --> Utf8 Class Initialized
INFO - 2016-10-07 14:14:34 --> URI Class Initialized
INFO - 2016-10-07 14:14:34 --> Router Class Initialized
INFO - 2016-10-07 14:14:34 --> Output Class Initialized
INFO - 2016-10-07 14:14:34 --> Security Class Initialized
DEBUG - 2016-10-07 14:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-07 14:14:34 --> Input Class Initialized
INFO - 2016-10-07 14:14:34 --> Language Class Initialized
INFO - 2016-10-07 14:14:34 --> Loader Class Initialized
DEBUG - 2016-10-07 14:14:34 --> Config file loaded: D:\xampp\htdocs\dev-proyectarte\application\config/pagination.php
INFO - 2016-10-07 14:14:34 --> Helper loaded: url_helper
INFO - 2016-10-07 14:14:34 --> Helper loaded: site_helper
INFO - 2016-10-07 14:14:34 --> Helper loaded: form_helper
INFO - 2016-10-07 14:14:34 --> Helper loaded: date_helper
INFO - 2016-10-07 14:14:34 --> Helper loaded: string_helper
INFO - 2016-10-07 14:14:34 --> Helper loaded: file_helper
INFO - 2016-10-07 14:14:34 --> Helper loaded: frontend_helper
INFO - 2016-10-07 14:14:34 --> Helper loaded: text_helper
INFO - 2016-10-07 14:14:34 --> Database Driver Class Initialized
DEBUG - 2016-10-07 14:14:34 --> Session Class Initialized
INFO - 2016-10-07 14:14:34 --> Encrypt Class Initialized
DEBUG - 2016-10-07 14:14:34 --> Session routines successfully run
INFO - 2016-10-07 14:14:34 --> Parser Class Initialized
INFO - 2016-10-07 14:14:34 --> Language file loaded: language/en/pagination_lang.php
INFO - 2016-10-07 14:14:34 --> Pagination Class Initialized
INFO - 2016-10-07 14:14:34 --> User Agent Class Initialized
INFO - 2016-10-07 14:14:34 --> Form Validation Class Initialized
INFO - 2016-10-07 14:14:34 --> Upload Class Initialized
INFO - 2016-10-07 14:14:34 --> Controller Class Initialized
INFO - 2016-10-07 14:14:34 --> Language file loaded: language/en/core_lang.php
DEBUG - 2016-10-07 14:14:34 --> Upload class already loaded. Second attempt ignored.
INFO - 2016-10-07 14:14:34 --> Image Lib Class Initialized
INFO - 2016-10-07 14:14:34 --> Model Class Initialized
INFO - 2016-10-07 14:14:34 --> Model Class Initialized
INFO - 2016-10-07 14:14:34 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\admin/course/form.php
INFO - 2016-10-07 14:14:34 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\admin/layouts/sidemenu.php
INFO - 2016-10-07 14:14:34 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\admin/layouts/headmenu.php
INFO - 2016-10-07 14:14:34 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\admin/layouts/main.php
INFO - 2016-10-07 14:14:34 --> Final output sent to browser
DEBUG - 2016-10-07 14:14:34 --> Total execution time: 0.1480
INFO - 2016-10-07 14:32:00 --> Config Class Initialized
INFO - 2016-10-07 14:32:00 --> Hooks Class Initialized
DEBUG - 2016-10-07 14:32:00 --> UTF-8 Support Enabled
INFO - 2016-10-07 14:32:00 --> Utf8 Class Initialized
INFO - 2016-10-07 14:32:00 --> URI Class Initialized
INFO - 2016-10-07 14:32:00 --> Router Class Initialized
INFO - 2016-10-07 14:32:00 --> Output Class Initialized
INFO - 2016-10-07 14:32:00 --> Security Class Initialized
DEBUG - 2016-10-07 14:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-07 14:32:00 --> Input Class Initialized
INFO - 2016-10-07 14:32:00 --> Language Class Initialized
INFO - 2016-10-07 14:32:00 --> Loader Class Initialized
DEBUG - 2016-10-07 14:32:00 --> Config file loaded: D:\xampp\htdocs\dev-proyectarte\application\config/pagination.php
INFO - 2016-10-07 14:32:00 --> Helper loaded: url_helper
INFO - 2016-10-07 14:32:00 --> Helper loaded: site_helper
INFO - 2016-10-07 14:32:00 --> Helper loaded: form_helper
INFO - 2016-10-07 14:32:00 --> Helper loaded: date_helper
INFO - 2016-10-07 14:32:00 --> Helper loaded: string_helper
INFO - 2016-10-07 14:32:00 --> Helper loaded: file_helper
INFO - 2016-10-07 14:32:00 --> Helper loaded: frontend_helper
INFO - 2016-10-07 14:32:00 --> Helper loaded: text_helper
INFO - 2016-10-07 14:32:00 --> Database Driver Class Initialized
DEBUG - 2016-10-07 14:32:00 --> Session Class Initialized
INFO - 2016-10-07 14:32:00 --> Encrypt Class Initialized
DEBUG - 2016-10-07 14:32:00 --> Session routines successfully run
INFO - 2016-10-07 14:32:00 --> Parser Class Initialized
INFO - 2016-10-07 14:32:00 --> Language file loaded: language/en/pagination_lang.php
INFO - 2016-10-07 14:32:00 --> Pagination Class Initialized
INFO - 2016-10-07 14:32:00 --> User Agent Class Initialized
INFO - 2016-10-07 14:32:00 --> Form Validation Class Initialized
INFO - 2016-10-07 14:32:00 --> Upload Class Initialized
INFO - 2016-10-07 14:32:00 --> Controller Class Initialized
INFO - 2016-10-07 14:32:00 --> Language file loaded: language/en/core_lang.php
DEBUG - 2016-10-07 14:32:00 --> Upload class already loaded. Second attempt ignored.
INFO - 2016-10-07 14:32:00 --> Image Lib Class Initialized
INFO - 2016-10-07 14:32:00 --> Model Class Initialized
INFO - 2016-10-07 14:32:00 --> Model Class Initialized
INFO - 2016-10-07 14:32:00 --> Model Class Initialized
INFO - 2016-10-07 14:32:00 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\frontend/courses/search.php
INFO - 2016-10-07 14:32:00 --> Model Class Initialized
INFO - 2016-10-07 14:32:00 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\frontend/layouts/footerlang.php
INFO - 2016-10-07 14:32:00 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\frontend/courses/view.php
INFO - 2016-10-07 14:32:00 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\frontend/layouts/header.php
INFO - 2016-10-07 14:32:00 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\frontend/layouts/main.php
INFO - 2016-10-07 14:32:00 --> Final output sent to browser
DEBUG - 2016-10-07 14:32:00 --> Total execution time: 0.0990
INFO - 2016-10-07 14:32:00 --> Config Class Initialized
INFO - 2016-10-07 14:32:00 --> Hooks Class Initialized
DEBUG - 2016-10-07 14:32:00 --> UTF-8 Support Enabled
INFO - 2016-10-07 14:32:00 --> Utf8 Class Initialized
INFO - 2016-10-07 14:32:00 --> URI Class Initialized
INFO - 2016-10-07 14:32:00 --> Router Class Initialized
INFO - 2016-10-07 14:32:00 --> Output Class Initialized
INFO - 2016-10-07 14:32:00 --> Security Class Initialized
DEBUG - 2016-10-07 14:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-07 14:32:00 --> Input Class Initialized
INFO - 2016-10-07 14:32:00 --> Language Class Initialized
INFO - 2016-10-07 14:32:00 --> Loader Class Initialized
DEBUG - 2016-10-07 14:32:00 --> Config file loaded: D:\xampp\htdocs\dev-proyectarte\application\config/pagination.php
INFO - 2016-10-07 14:32:00 --> Helper loaded: url_helper
INFO - 2016-10-07 14:32:00 --> Helper loaded: site_helper
INFO - 2016-10-07 14:32:00 --> Helper loaded: form_helper
INFO - 2016-10-07 14:32:00 --> Helper loaded: date_helper
INFO - 2016-10-07 14:32:00 --> Helper loaded: string_helper
INFO - 2016-10-07 14:32:00 --> Helper loaded: file_helper
INFO - 2016-10-07 14:32:00 --> Helper loaded: frontend_helper
INFO - 2016-10-07 14:32:00 --> Helper loaded: text_helper
INFO - 2016-10-07 14:32:00 --> Database Driver Class Initialized
DEBUG - 2016-10-07 14:32:00 --> Session Class Initialized
INFO - 2016-10-07 14:32:00 --> Encrypt Class Initialized
DEBUG - 2016-10-07 14:32:00 --> Session routines successfully run
INFO - 2016-10-07 14:32:00 --> Parser Class Initialized
INFO - 2016-10-07 14:32:00 --> Language file loaded: language/en/pagination_lang.php
INFO - 2016-10-07 14:32:00 --> Pagination Class Initialized
INFO - 2016-10-07 14:32:00 --> User Agent Class Initialized
INFO - 2016-10-07 14:32:00 --> Form Validation Class Initialized
INFO - 2016-10-07 14:32:00 --> Upload Class Initialized
INFO - 2016-10-07 14:32:00 --> Controller Class Initialized
INFO - 2016-10-07 14:32:00 --> Language file loaded: language/en/core_lang.php
DEBUG - 2016-10-07 14:32:00 --> Upload class already loaded. Second attempt ignored.
INFO - 2016-10-07 14:32:00 --> Image Lib Class Initialized
INFO - 2016-10-07 14:32:00 --> Model Class Initialized
INFO - 2016-10-07 14:32:00 --> Model Class Initialized
INFO - 2016-10-07 14:32:00 --> Model Class Initialized
INFO - 2016-10-07 14:32:00 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\frontend/courses/search.php
INFO - 2016-10-07 14:32:00 --> Model Class Initialized
INFO - 2016-10-07 14:32:00 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\frontend/layouts/footerlang.php
INFO - 2016-10-07 14:32:00 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\frontend/courses/view.php
INFO - 2016-10-07 14:32:00 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\frontend/layouts/header.php
INFO - 2016-10-07 14:32:00 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\frontend/layouts/main.php
INFO - 2016-10-07 14:32:00 --> Final output sent to browser
DEBUG - 2016-10-07 14:32:00 --> Total execution time: 0.0810
INFO - 2016-10-07 14:32:01 --> Config Class Initialized
INFO - 2016-10-07 14:32:01 --> Hooks Class Initialized
DEBUG - 2016-10-07 14:32:01 --> UTF-8 Support Enabled
INFO - 2016-10-07 14:32:01 --> Utf8 Class Initialized
INFO - 2016-10-07 14:32:01 --> URI Class Initialized
INFO - 2016-10-07 14:32:01 --> Router Class Initialized
INFO - 2016-10-07 14:32:01 --> Output Class Initialized
INFO - 2016-10-07 14:32:01 --> Security Class Initialized
DEBUG - 2016-10-07 14:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-07 14:32:01 --> Input Class Initialized
INFO - 2016-10-07 14:32:01 --> Language Class Initialized
INFO - 2016-10-07 14:32:01 --> Loader Class Initialized
DEBUG - 2016-10-07 14:32:01 --> Config file loaded: D:\xampp\htdocs\dev-proyectarte\application\config/pagination.php
INFO - 2016-10-07 14:32:01 --> Helper loaded: url_helper
INFO - 2016-10-07 14:32:01 --> Helper loaded: site_helper
INFO - 2016-10-07 14:32:01 --> Helper loaded: form_helper
INFO - 2016-10-07 14:32:01 --> Helper loaded: date_helper
INFO - 2016-10-07 14:32:01 --> Helper loaded: string_helper
INFO - 2016-10-07 14:32:01 --> Helper loaded: file_helper
INFO - 2016-10-07 14:32:01 --> Helper loaded: frontend_helper
INFO - 2016-10-07 14:32:01 --> Helper loaded: text_helper
INFO - 2016-10-07 14:32:01 --> Database Driver Class Initialized
DEBUG - 2016-10-07 14:32:01 --> Session Class Initialized
INFO - 2016-10-07 14:32:01 --> Encrypt Class Initialized
DEBUG - 2016-10-07 14:32:01 --> Session routines successfully run
INFO - 2016-10-07 14:32:01 --> Parser Class Initialized
INFO - 2016-10-07 14:32:01 --> Language file loaded: language/en/pagination_lang.php
INFO - 2016-10-07 14:32:01 --> Pagination Class Initialized
INFO - 2016-10-07 14:32:01 --> User Agent Class Initialized
INFO - 2016-10-07 14:32:01 --> Form Validation Class Initialized
INFO - 2016-10-07 14:32:01 --> Upload Class Initialized
INFO - 2016-10-07 14:32:01 --> Controller Class Initialized
INFO - 2016-10-07 14:32:01 --> Language file loaded: language/en/core_lang.php
DEBUG - 2016-10-07 14:32:01 --> Upload class already loaded. Second attempt ignored.
INFO - 2016-10-07 14:32:01 --> Image Lib Class Initialized
INFO - 2016-10-07 14:32:01 --> Model Class Initialized
INFO - 2016-10-07 14:32:01 --> Model Class Initialized
INFO - 2016-10-07 14:32:01 --> Model Class Initialized
INFO - 2016-10-07 14:32:01 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\frontend/courses/search.php
INFO - 2016-10-07 14:32:01 --> Model Class Initialized
INFO - 2016-10-07 14:32:01 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\frontend/layouts/footerlang.php
INFO - 2016-10-07 14:32:01 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\frontend/courses/view.php
INFO - 2016-10-07 14:32:01 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\frontend/layouts/header.php
INFO - 2016-10-07 14:32:01 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\frontend/layouts/main.php
INFO - 2016-10-07 14:32:01 --> Final output sent to browser
DEBUG - 2016-10-07 14:32:01 --> Total execution time: 0.0810
INFO - 2016-10-07 14:37:02 --> Config Class Initialized
INFO - 2016-10-07 14:37:02 --> Hooks Class Initialized
DEBUG - 2016-10-07 14:37:02 --> UTF-8 Support Enabled
INFO - 2016-10-07 14:37:02 --> Utf8 Class Initialized
INFO - 2016-10-07 14:37:02 --> URI Class Initialized
DEBUG - 2016-10-07 14:37:02 --> No URI present. Default controller set.
INFO - 2016-10-07 14:37:02 --> Router Class Initialized
INFO - 2016-10-07 14:37:02 --> Output Class Initialized
INFO - 2016-10-07 14:37:02 --> Security Class Initialized
DEBUG - 2016-10-07 14:37:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-07 14:37:02 --> Input Class Initialized
INFO - 2016-10-07 14:37:02 --> Language Class Initialized
INFO - 2016-10-07 14:37:02 --> Loader Class Initialized
DEBUG - 2016-10-07 14:37:02 --> Config file loaded: D:\xampp\htdocs\dev-proyectarte\application\config/pagination.php
INFO - 2016-10-07 14:37:02 --> Helper loaded: url_helper
INFO - 2016-10-07 14:37:02 --> Helper loaded: site_helper
INFO - 2016-10-07 14:37:02 --> Helper loaded: form_helper
INFO - 2016-10-07 14:37:02 --> Helper loaded: date_helper
INFO - 2016-10-07 14:37:02 --> Helper loaded: string_helper
INFO - 2016-10-07 14:37:02 --> Helper loaded: file_helper
INFO - 2016-10-07 14:37:02 --> Helper loaded: frontend_helper
INFO - 2016-10-07 14:37:02 --> Helper loaded: text_helper
INFO - 2016-10-07 14:37:02 --> Database Driver Class Initialized
DEBUG - 2016-10-07 14:37:02 --> Session Class Initialized
INFO - 2016-10-07 14:37:02 --> Encrypt Class Initialized
DEBUG - 2016-10-07 14:37:02 --> Session routines successfully run
INFO - 2016-10-07 14:37:02 --> Parser Class Initialized
INFO - 2016-10-07 14:37:02 --> Language file loaded: language/en/pagination_lang.php
INFO - 2016-10-07 14:37:02 --> Pagination Class Initialized
INFO - 2016-10-07 14:37:02 --> User Agent Class Initialized
INFO - 2016-10-07 14:37:02 --> Form Validation Class Initialized
INFO - 2016-10-07 14:37:02 --> Upload Class Initialized
INFO - 2016-10-07 14:37:02 --> Controller Class Initialized
INFO - 2016-10-07 14:37:02 --> Language file loaded: language/en/core_lang.php
DEBUG - 2016-10-07 14:37:02 --> Upload class already loaded. Second attempt ignored.
INFO - 2016-10-07 14:37:02 --> Image Lib Class Initialized
INFO - 2016-10-07 14:37:02 --> Model Class Initialized
INFO - 2016-10-07 14:37:02 --> Model Class Initialized
INFO - 2016-10-07 14:37:03 --> Model Class Initialized
INFO - 2016-10-07 14:37:03 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\frontend/layouts/banner.php
INFO - 2016-10-07 14:37:03 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\frontend/layouts/annoucement.php
INFO - 2016-10-07 14:37:03 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\frontend/layouts/latestnews.php
INFO - 2016-10-07 14:37:03 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\frontend/layouts/footer.php
INFO - 2016-10-07 14:37:03 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\frontend/layouts/contact.php
INFO - 2016-10-07 14:37:03 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\frontend/home/index.php
INFO - 2016-10-07 14:37:03 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\frontend/layouts/header.php
INFO - 2016-10-07 14:37:03 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\frontend/layouts/main.php
INFO - 2016-10-07 14:37:03 --> Final output sent to browser
DEBUG - 2016-10-07 14:37:03 --> Total execution time: 0.1770
INFO - 2016-10-07 14:57:00 --> Config Class Initialized
INFO - 2016-10-07 14:57:00 --> Hooks Class Initialized
DEBUG - 2016-10-07 14:57:00 --> UTF-8 Support Enabled
INFO - 2016-10-07 14:57:00 --> Utf8 Class Initialized
INFO - 2016-10-07 14:57:00 --> URI Class Initialized
INFO - 2016-10-07 14:57:00 --> Router Class Initialized
INFO - 2016-10-07 14:57:00 --> Output Class Initialized
INFO - 2016-10-07 14:57:00 --> Security Class Initialized
DEBUG - 2016-10-07 14:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-07 14:57:00 --> Input Class Initialized
INFO - 2016-10-07 14:57:00 --> Language Class Initialized
INFO - 2016-10-07 14:57:00 --> Loader Class Initialized
DEBUG - 2016-10-07 14:57:00 --> Config file loaded: D:\xampp\htdocs\dev-proyectarte\application\config/pagination.php
INFO - 2016-10-07 14:57:00 --> Helper loaded: url_helper
INFO - 2016-10-07 14:57:00 --> Helper loaded: site_helper
INFO - 2016-10-07 14:57:00 --> Helper loaded: form_helper
INFO - 2016-10-07 14:57:00 --> Helper loaded: date_helper
INFO - 2016-10-07 14:57:00 --> Helper loaded: string_helper
INFO - 2016-10-07 14:57:00 --> Helper loaded: file_helper
INFO - 2016-10-07 14:57:00 --> Helper loaded: frontend_helper
INFO - 2016-10-07 14:57:00 --> Helper loaded: text_helper
INFO - 2016-10-07 14:57:00 --> Database Driver Class Initialized
DEBUG - 2016-10-07 14:57:00 --> Session Class Initialized
INFO - 2016-10-07 14:57:00 --> Encrypt Class Initialized
DEBUG - 2016-10-07 14:57:00 --> Session routines successfully run
INFO - 2016-10-07 14:57:00 --> Parser Class Initialized
INFO - 2016-10-07 14:57:00 --> Language file loaded: language/en/pagination_lang.php
INFO - 2016-10-07 14:57:00 --> Pagination Class Initialized
INFO - 2016-10-07 14:57:00 --> User Agent Class Initialized
INFO - 2016-10-07 14:57:00 --> Form Validation Class Initialized
INFO - 2016-10-07 14:57:00 --> Upload Class Initialized
INFO - 2016-10-07 14:57:00 --> Controller Class Initialized
INFO - 2016-10-07 14:57:00 --> Language file loaded: language/en/core_lang.php
DEBUG - 2016-10-07 14:57:00 --> Upload class already loaded. Second attempt ignored.
INFO - 2016-10-07 14:57:00 --> Image Lib Class Initialized
INFO - 2016-10-07 14:57:00 --> Model Class Initialized
INFO - 2016-10-07 14:57:00 --> Model Class Initialized
INFO - 2016-10-07 14:57:00 --> Model Class Initialized
INFO - 2016-10-07 14:57:00 --> CATEGORY :::::: 
INFO - 2016-10-07 14:57:00 --> AREA ::::: 
INFO - 2016-10-07 14:57:00 --> SOFTWARE ::::::: 
INFO - 2016-10-07 14:57:00 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\frontend/courses/search.php
INFO - 2016-10-07 14:57:00 --> Model Class Initialized
INFO - 2016-10-07 14:57:00 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\frontend/layouts/footerlang.php
INFO - 2016-10-07 14:57:00 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\frontend/courses/index.php
INFO - 2016-10-07 14:57:00 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\frontend/layouts/header.php
INFO - 2016-10-07 14:57:00 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\frontend/layouts/main.php
INFO - 2016-10-07 14:57:00 --> Final output sent to browser
DEBUG - 2016-10-07 14:57:00 --> Total execution time: 0.0790
INFO - 2016-10-07 14:57:04 --> Config Class Initialized
INFO - 2016-10-07 14:57:04 --> Hooks Class Initialized
DEBUG - 2016-10-07 14:57:04 --> UTF-8 Support Enabled
INFO - 2016-10-07 14:57:04 --> Utf8 Class Initialized
INFO - 2016-10-07 14:57:04 --> URI Class Initialized
INFO - 2016-10-07 14:57:04 --> Router Class Initialized
INFO - 2016-10-07 14:57:04 --> Output Class Initialized
INFO - 2016-10-07 14:57:04 --> Security Class Initialized
DEBUG - 2016-10-07 14:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-07 14:57:04 --> Input Class Initialized
INFO - 2016-10-07 14:57:04 --> Language Class Initialized
INFO - 2016-10-07 14:57:04 --> Loader Class Initialized
DEBUG - 2016-10-07 14:57:04 --> Config file loaded: D:\xampp\htdocs\dev-proyectarte\application\config/pagination.php
INFO - 2016-10-07 14:57:04 --> Helper loaded: url_helper
INFO - 2016-10-07 14:57:04 --> Helper loaded: site_helper
INFO - 2016-10-07 14:57:04 --> Helper loaded: form_helper
INFO - 2016-10-07 14:57:04 --> Helper loaded: date_helper
INFO - 2016-10-07 14:57:04 --> Helper loaded: string_helper
INFO - 2016-10-07 14:57:04 --> Helper loaded: file_helper
INFO - 2016-10-07 14:57:04 --> Helper loaded: frontend_helper
INFO - 2016-10-07 14:57:04 --> Helper loaded: text_helper
INFO - 2016-10-07 14:57:04 --> Database Driver Class Initialized
DEBUG - 2016-10-07 14:57:04 --> Session Class Initialized
INFO - 2016-10-07 14:57:04 --> Encrypt Class Initialized
DEBUG - 2016-10-07 14:57:04 --> Session routines successfully run
INFO - 2016-10-07 14:57:04 --> Parser Class Initialized
INFO - 2016-10-07 14:57:04 --> Language file loaded: language/en/pagination_lang.php
INFO - 2016-10-07 14:57:04 --> Pagination Class Initialized
INFO - 2016-10-07 14:57:04 --> User Agent Class Initialized
INFO - 2016-10-07 14:57:04 --> Form Validation Class Initialized
INFO - 2016-10-07 14:57:04 --> Upload Class Initialized
INFO - 2016-10-07 14:57:04 --> Controller Class Initialized
INFO - 2016-10-07 14:57:04 --> Language file loaded: language/en/core_lang.php
DEBUG - 2016-10-07 14:57:04 --> Upload class already loaded. Second attempt ignored.
INFO - 2016-10-07 14:57:04 --> Image Lib Class Initialized
INFO - 2016-10-07 14:57:04 --> Model Class Initialized
INFO - 2016-10-07 14:57:04 --> Model Class Initialized
INFO - 2016-10-07 14:57:04 --> Model Class Initialized
INFO - 2016-10-07 14:57:04 --> CATEGORY :::::: 
INFO - 2016-10-07 14:57:04 --> AREA ::::: 
INFO - 2016-10-07 14:57:04 --> SOFTWARE ::::::: 
INFO - 2016-10-07 14:57:04 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\frontend/courses/search.php
INFO - 2016-10-07 14:57:04 --> Model Class Initialized
INFO - 2016-10-07 14:57:04 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\frontend/layouts/footerlang.php
INFO - 2016-10-07 14:57:04 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\frontend/courses/index.php
INFO - 2016-10-07 14:57:04 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\frontend/layouts/header.php
INFO - 2016-10-07 14:57:04 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\frontend/layouts/main.php
INFO - 2016-10-07 14:57:04 --> Final output sent to browser
DEBUG - 2016-10-07 14:57:04 --> Total execution time: 0.1170
INFO - 2016-10-07 15:06:21 --> Config Class Initialized
INFO - 2016-10-07 15:06:21 --> Hooks Class Initialized
DEBUG - 2016-10-07 15:06:21 --> UTF-8 Support Enabled
INFO - 2016-10-07 15:06:21 --> Utf8 Class Initialized
INFO - 2016-10-07 15:06:21 --> URI Class Initialized
INFO - 2016-10-07 15:06:21 --> Router Class Initialized
INFO - 2016-10-07 15:06:21 --> Output Class Initialized
INFO - 2016-10-07 15:06:21 --> Security Class Initialized
DEBUG - 2016-10-07 15:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-07 15:06:21 --> Input Class Initialized
INFO - 2016-10-07 15:06:21 --> Language Class Initialized
INFO - 2016-10-07 15:06:21 --> Loader Class Initialized
DEBUG - 2016-10-07 15:06:21 --> Config file loaded: D:\xampp\htdocs\dev-proyectarte\application\config/pagination.php
INFO - 2016-10-07 15:06:21 --> Helper loaded: url_helper
INFO - 2016-10-07 15:06:21 --> Helper loaded: site_helper
INFO - 2016-10-07 15:06:21 --> Helper loaded: form_helper
INFO - 2016-10-07 15:06:21 --> Helper loaded: date_helper
INFO - 2016-10-07 15:06:21 --> Helper loaded: string_helper
INFO - 2016-10-07 15:06:21 --> Helper loaded: file_helper
INFO - 2016-10-07 15:06:21 --> Helper loaded: frontend_helper
INFO - 2016-10-07 15:06:21 --> Helper loaded: text_helper
INFO - 2016-10-07 15:06:21 --> Database Driver Class Initialized
DEBUG - 2016-10-07 15:06:21 --> Session Class Initialized
INFO - 2016-10-07 15:06:21 --> Encrypt Class Initialized
DEBUG - 2016-10-07 15:06:21 --> Session routines successfully run
INFO - 2016-10-07 15:06:21 --> Parser Class Initialized
INFO - 2016-10-07 15:06:21 --> Language file loaded: language/en/pagination_lang.php
INFO - 2016-10-07 15:06:21 --> Pagination Class Initialized
INFO - 2016-10-07 15:06:21 --> User Agent Class Initialized
INFO - 2016-10-07 15:06:21 --> Form Validation Class Initialized
INFO - 2016-10-07 15:06:21 --> Upload Class Initialized
INFO - 2016-10-07 15:06:21 --> Controller Class Initialized
INFO - 2016-10-07 15:06:21 --> Language file loaded: language/en/core_lang.php
DEBUG - 2016-10-07 15:06:21 --> Upload class already loaded. Second attempt ignored.
INFO - 2016-10-07 15:06:21 --> Image Lib Class Initialized
INFO - 2016-10-07 15:06:21 --> Model Class Initialized
INFO - 2016-10-07 15:06:21 --> Model Class Initialized
INFO - 2016-10-07 15:06:21 --> Model Class Initialized
INFO - 2016-10-07 15:06:21 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\frontend/layouts/footerlang.php
INFO - 2016-10-07 15:06:21 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\frontend/my_courses/index.php
INFO - 2016-10-07 15:06:21 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\frontend/layouts/header.php
INFO - 2016-10-07 15:06:21 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\frontend/layouts/main.php
INFO - 2016-10-07 15:06:21 --> Final output sent to browser
DEBUG - 2016-10-07 15:06:21 --> Total execution time: 0.1190
INFO - 2016-10-07 15:07:04 --> Config Class Initialized
INFO - 2016-10-07 15:07:04 --> Hooks Class Initialized
DEBUG - 2016-10-07 15:07:04 --> UTF-8 Support Enabled
INFO - 2016-10-07 15:07:04 --> Utf8 Class Initialized
INFO - 2016-10-07 15:07:04 --> URI Class Initialized
INFO - 2016-10-07 15:07:04 --> Router Class Initialized
INFO - 2016-10-07 15:07:04 --> Output Class Initialized
INFO - 2016-10-07 15:07:04 --> Security Class Initialized
DEBUG - 2016-10-07 15:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-07 15:07:04 --> Input Class Initialized
INFO - 2016-10-07 15:07:04 --> Language Class Initialized
INFO - 2016-10-07 15:07:04 --> Loader Class Initialized
DEBUG - 2016-10-07 15:07:04 --> Config file loaded: D:\xampp\htdocs\dev-proyectarte\application\config/pagination.php
INFO - 2016-10-07 15:07:04 --> Helper loaded: url_helper
INFO - 2016-10-07 15:07:04 --> Helper loaded: site_helper
INFO - 2016-10-07 15:07:04 --> Helper loaded: form_helper
INFO - 2016-10-07 15:07:04 --> Helper loaded: date_helper
INFO - 2016-10-07 15:07:04 --> Helper loaded: string_helper
INFO - 2016-10-07 15:07:04 --> Helper loaded: file_helper
INFO - 2016-10-07 15:07:04 --> Helper loaded: frontend_helper
INFO - 2016-10-07 15:07:04 --> Helper loaded: text_helper
INFO - 2016-10-07 15:07:04 --> Database Driver Class Initialized
DEBUG - 2016-10-07 15:07:04 --> Session Class Initialized
INFO - 2016-10-07 15:07:04 --> Encrypt Class Initialized
DEBUG - 2016-10-07 15:07:04 --> Session routines successfully run
INFO - 2016-10-07 15:07:04 --> Parser Class Initialized
INFO - 2016-10-07 15:07:04 --> Language file loaded: language/en/pagination_lang.php
INFO - 2016-10-07 15:07:04 --> Pagination Class Initialized
INFO - 2016-10-07 15:07:04 --> User Agent Class Initialized
INFO - 2016-10-07 15:07:04 --> Form Validation Class Initialized
INFO - 2016-10-07 15:07:04 --> Upload Class Initialized
INFO - 2016-10-07 15:07:04 --> Controller Class Initialized
INFO - 2016-10-07 15:07:04 --> Language file loaded: language/en/core_lang.php
DEBUG - 2016-10-07 15:07:04 --> Upload class already loaded. Second attempt ignored.
INFO - 2016-10-07 15:07:04 --> Image Lib Class Initialized
INFO - 2016-10-07 15:07:04 --> Model Class Initialized
INFO - 2016-10-07 15:07:04 --> Model Class Initialized
INFO - 2016-10-07 15:07:04 --> User ID :::::::::::::::::::::.9
INFO - 2016-10-07 15:07:04 --> Model Class Initialized
INFO - 2016-10-07 15:07:04 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\frontend/layouts/footer.php
INFO - 2016-10-07 15:07:04 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\frontend/account/index.php
INFO - 2016-10-07 15:07:04 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\frontend/layouts/header.php
INFO - 2016-10-07 15:07:04 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\frontend/layouts/main.php
INFO - 2016-10-07 15:07:04 --> Final output sent to browser
DEBUG - 2016-10-07 15:07:04 --> Total execution time: 0.0850
INFO - 2016-10-07 15:15:26 --> Config Class Initialized
INFO - 2016-10-07 15:15:26 --> Hooks Class Initialized
DEBUG - 2016-10-07 15:15:26 --> UTF-8 Support Enabled
INFO - 2016-10-07 15:15:26 --> Utf8 Class Initialized
INFO - 2016-10-07 15:15:26 --> URI Class Initialized
INFO - 2016-10-07 15:15:26 --> Router Class Initialized
INFO - 2016-10-07 15:15:26 --> Output Class Initialized
INFO - 2016-10-07 15:15:26 --> Security Class Initialized
DEBUG - 2016-10-07 15:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-07 15:15:26 --> Input Class Initialized
INFO - 2016-10-07 15:15:26 --> Language Class Initialized
INFO - 2016-10-07 15:15:26 --> Loader Class Initialized
DEBUG - 2016-10-07 15:15:26 --> Config file loaded: D:\xampp\htdocs\dev-proyectarte\application\config/pagination.php
INFO - 2016-10-07 15:15:26 --> Helper loaded: url_helper
INFO - 2016-10-07 15:15:26 --> Helper loaded: site_helper
INFO - 2016-10-07 15:15:26 --> Helper loaded: form_helper
INFO - 2016-10-07 15:15:26 --> Helper loaded: date_helper
INFO - 2016-10-07 15:15:26 --> Helper loaded: string_helper
INFO - 2016-10-07 15:15:26 --> Helper loaded: file_helper
INFO - 2016-10-07 15:15:26 --> Helper loaded: frontend_helper
INFO - 2016-10-07 15:15:26 --> Helper loaded: text_helper
INFO - 2016-10-07 15:15:26 --> Database Driver Class Initialized
DEBUG - 2016-10-07 15:15:26 --> Session Class Initialized
INFO - 2016-10-07 15:15:26 --> Encrypt Class Initialized
DEBUG - 2016-10-07 15:15:26 --> Session routines successfully run
INFO - 2016-10-07 15:15:26 --> Parser Class Initialized
INFO - 2016-10-07 15:15:26 --> Language file loaded: language/en/pagination_lang.php
INFO - 2016-10-07 15:15:26 --> Pagination Class Initialized
INFO - 2016-10-07 15:15:26 --> User Agent Class Initialized
INFO - 2016-10-07 15:15:26 --> Form Validation Class Initialized
INFO - 2016-10-07 15:15:26 --> Upload Class Initialized
INFO - 2016-10-07 15:15:26 --> Controller Class Initialized
INFO - 2016-10-07 15:15:26 --> Language file loaded: language/en/core_lang.php
DEBUG - 2016-10-07 15:15:26 --> Upload class already loaded. Second attempt ignored.
INFO - 2016-10-07 15:15:26 --> Image Lib Class Initialized
INFO - 2016-10-07 15:15:26 --> Model Class Initialized
INFO - 2016-10-07 15:15:26 --> Model Class Initialized
INFO - 2016-10-07 15:15:26 --> Model Class Initialized
INFO - 2016-10-07 15:15:26 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\frontend/layouts/footerlang.php
INFO - 2016-10-07 15:15:26 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\frontend/my_courses/index.php
INFO - 2016-10-07 15:15:26 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\frontend/layouts/header.php
INFO - 2016-10-07 15:15:26 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\frontend/layouts/main.php
INFO - 2016-10-07 15:15:26 --> Final output sent to browser
DEBUG - 2016-10-07 15:15:26 --> Total execution time: 0.0750
INFO - 2016-10-07 15:27:01 --> Config Class Initialized
INFO - 2016-10-07 15:27:01 --> Hooks Class Initialized
DEBUG - 2016-10-07 15:27:01 --> UTF-8 Support Enabled
INFO - 2016-10-07 15:27:01 --> Utf8 Class Initialized
INFO - 2016-10-07 15:27:01 --> URI Class Initialized
DEBUG - 2016-10-07 15:27:01 --> No URI present. Default controller set.
INFO - 2016-10-07 15:27:01 --> Router Class Initialized
INFO - 2016-10-07 15:27:01 --> Output Class Initialized
INFO - 2016-10-07 15:27:01 --> Security Class Initialized
DEBUG - 2016-10-07 15:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-07 15:27:01 --> Input Class Initialized
INFO - 2016-10-07 15:27:01 --> Language Class Initialized
INFO - 2016-10-07 15:27:01 --> Loader Class Initialized
DEBUG - 2016-10-07 15:27:01 --> Config file loaded: D:\xampp\htdocs\dev-proyectarte\application\config/pagination.php
INFO - 2016-10-07 15:27:01 --> Helper loaded: url_helper
INFO - 2016-10-07 15:27:01 --> Helper loaded: site_helper
INFO - 2016-10-07 15:27:01 --> Helper loaded: form_helper
INFO - 2016-10-07 15:27:01 --> Helper loaded: date_helper
INFO - 2016-10-07 15:27:01 --> Helper loaded: string_helper
INFO - 2016-10-07 15:27:01 --> Helper loaded: file_helper
INFO - 2016-10-07 15:27:01 --> Helper loaded: frontend_helper
INFO - 2016-10-07 15:27:01 --> Helper loaded: text_helper
INFO - 2016-10-07 15:27:01 --> Database Driver Class Initialized
DEBUG - 2016-10-07 15:27:01 --> Session Class Initialized
INFO - 2016-10-07 15:27:01 --> Encrypt Class Initialized
DEBUG - 2016-10-07 15:27:01 --> Session routines successfully run
INFO - 2016-10-07 15:27:01 --> Parser Class Initialized
INFO - 2016-10-07 15:27:01 --> Language file loaded: language/en/pagination_lang.php
INFO - 2016-10-07 15:27:01 --> Pagination Class Initialized
INFO - 2016-10-07 15:27:01 --> User Agent Class Initialized
INFO - 2016-10-07 15:27:01 --> Form Validation Class Initialized
INFO - 2016-10-07 15:27:01 --> Upload Class Initialized
INFO - 2016-10-07 15:27:01 --> Controller Class Initialized
INFO - 2016-10-07 15:27:01 --> Language file loaded: language/en/core_lang.php
DEBUG - 2016-10-07 15:27:01 --> Upload class already loaded. Second attempt ignored.
INFO - 2016-10-07 15:27:01 --> Image Lib Class Initialized
INFO - 2016-10-07 15:27:01 --> Model Class Initialized
INFO - 2016-10-07 15:27:01 --> Model Class Initialized
INFO - 2016-10-07 15:27:01 --> Model Class Initialized
INFO - 2016-10-07 15:27:01 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\frontend/layouts/banner.php
INFO - 2016-10-07 15:27:01 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\frontend/layouts/annoucement.php
INFO - 2016-10-07 15:27:01 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\frontend/layouts/latestnews.php
INFO - 2016-10-07 15:27:01 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\frontend/layouts/footer.php
INFO - 2016-10-07 15:27:01 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\frontend/layouts/contact.php
INFO - 2016-10-07 15:27:01 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\frontend/home/index.php
INFO - 2016-10-07 15:27:01 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\frontend/layouts/header.php
INFO - 2016-10-07 15:27:01 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\frontend/layouts/main.php
INFO - 2016-10-07 15:27:01 --> Final output sent to browser
DEBUG - 2016-10-07 15:27:01 --> Total execution time: 0.0990
INFO - 2016-10-07 15:27:07 --> Config Class Initialized
INFO - 2016-10-07 15:27:07 --> Hooks Class Initialized
DEBUG - 2016-10-07 15:27:07 --> UTF-8 Support Enabled
INFO - 2016-10-07 15:27:07 --> Utf8 Class Initialized
INFO - 2016-10-07 15:27:07 --> URI Class Initialized
INFO - 2016-10-07 15:27:07 --> Router Class Initialized
INFO - 2016-10-07 15:27:07 --> Output Class Initialized
INFO - 2016-10-07 15:27:07 --> Security Class Initialized
DEBUG - 2016-10-07 15:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-07 15:27:07 --> Input Class Initialized
INFO - 2016-10-07 15:27:07 --> Language Class Initialized
INFO - 2016-10-07 15:27:07 --> Loader Class Initialized
DEBUG - 2016-10-07 15:27:07 --> Config file loaded: D:\xampp\htdocs\dev-proyectarte\application\config/pagination.php
INFO - 2016-10-07 15:27:07 --> Helper loaded: url_helper
INFO - 2016-10-07 15:27:07 --> Helper loaded: site_helper
INFO - 2016-10-07 15:27:07 --> Helper loaded: form_helper
INFO - 2016-10-07 15:27:07 --> Helper loaded: date_helper
INFO - 2016-10-07 15:27:07 --> Helper loaded: string_helper
INFO - 2016-10-07 15:27:07 --> Helper loaded: file_helper
INFO - 2016-10-07 15:27:07 --> Helper loaded: frontend_helper
INFO - 2016-10-07 15:27:07 --> Helper loaded: text_helper
INFO - 2016-10-07 15:27:07 --> Database Driver Class Initialized
DEBUG - 2016-10-07 15:27:07 --> Session Class Initialized
INFO - 2016-10-07 15:27:07 --> Encrypt Class Initialized
DEBUG - 2016-10-07 15:27:07 --> Session routines successfully run
INFO - 2016-10-07 15:27:07 --> Parser Class Initialized
INFO - 2016-10-07 15:27:07 --> Language file loaded: language/en/pagination_lang.php
INFO - 2016-10-07 15:27:07 --> Pagination Class Initialized
INFO - 2016-10-07 15:27:07 --> User Agent Class Initialized
INFO - 2016-10-07 15:27:07 --> Form Validation Class Initialized
INFO - 2016-10-07 15:27:07 --> Upload Class Initialized
INFO - 2016-10-07 15:27:07 --> Controller Class Initialized
INFO - 2016-10-07 15:27:07 --> Config Class Initialized
INFO - 2016-10-07 15:27:07 --> Hooks Class Initialized
DEBUG - 2016-10-07 15:27:07 --> UTF-8 Support Enabled
INFO - 2016-10-07 15:27:07 --> Utf8 Class Initialized
INFO - 2016-10-07 15:27:07 --> URI Class Initialized
INFO - 2016-10-07 15:27:07 --> Router Class Initialized
INFO - 2016-10-07 15:27:07 --> Output Class Initialized
INFO - 2016-10-07 15:27:07 --> Security Class Initialized
DEBUG - 2016-10-07 15:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-07 15:27:07 --> Input Class Initialized
INFO - 2016-10-07 15:27:07 --> Language Class Initialized
INFO - 2016-10-07 15:27:07 --> Loader Class Initialized
DEBUG - 2016-10-07 15:27:07 --> Config file loaded: D:\xampp\htdocs\dev-proyectarte\application\config/pagination.php
INFO - 2016-10-07 15:27:07 --> Helper loaded: url_helper
INFO - 2016-10-07 15:27:07 --> Helper loaded: site_helper
INFO - 2016-10-07 15:27:07 --> Helper loaded: form_helper
INFO - 2016-10-07 15:27:07 --> Helper loaded: date_helper
INFO - 2016-10-07 15:27:07 --> Helper loaded: string_helper
INFO - 2016-10-07 15:27:07 --> Helper loaded: file_helper
INFO - 2016-10-07 15:27:07 --> Helper loaded: frontend_helper
INFO - 2016-10-07 15:27:07 --> Helper loaded: text_helper
INFO - 2016-10-07 15:27:07 --> Database Driver Class Initialized
DEBUG - 2016-10-07 15:27:07 --> Session Class Initialized
INFO - 2016-10-07 15:27:07 --> Encrypt Class Initialized
DEBUG - 2016-10-07 15:27:07 --> Session routines successfully run
INFO - 2016-10-07 15:27:07 --> Parser Class Initialized
INFO - 2016-10-07 15:27:07 --> Language file loaded: language/en/pagination_lang.php
INFO - 2016-10-07 15:27:07 --> Pagination Class Initialized
INFO - 2016-10-07 15:27:07 --> User Agent Class Initialized
INFO - 2016-10-07 15:27:07 --> Form Validation Class Initialized
INFO - 2016-10-07 15:27:07 --> Upload Class Initialized
INFO - 2016-10-07 15:27:07 --> Controller Class Initialized
INFO - 2016-10-07 15:27:07 --> Language file loaded: language/en/core_lang.php
DEBUG - 2016-10-07 15:27:07 --> Upload class already loaded. Second attempt ignored.
INFO - 2016-10-07 15:27:07 --> Image Lib Class Initialized
INFO - 2016-10-07 15:27:07 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\dashboard.php
INFO - 2016-10-07 15:27:07 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\admin/layouts/sidemenu.php
INFO - 2016-10-07 15:27:07 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\admin/layouts/headmenu.php
INFO - 2016-10-07 15:27:07 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\admin/layouts/main.php
INFO - 2016-10-07 15:27:07 --> Final output sent to browser
DEBUG - 2016-10-07 15:27:07 --> Total execution time: 0.0600
INFO - 2016-10-07 15:27:11 --> Config Class Initialized
INFO - 2016-10-07 15:27:11 --> Hooks Class Initialized
DEBUG - 2016-10-07 15:27:11 --> UTF-8 Support Enabled
INFO - 2016-10-07 15:27:11 --> Utf8 Class Initialized
INFO - 2016-10-07 15:27:11 --> URI Class Initialized
INFO - 2016-10-07 15:27:11 --> Router Class Initialized
INFO - 2016-10-07 15:27:11 --> Output Class Initialized
INFO - 2016-10-07 15:27:11 --> Security Class Initialized
DEBUG - 2016-10-07 15:27:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-07 15:27:11 --> Input Class Initialized
INFO - 2016-10-07 15:27:11 --> Language Class Initialized
INFO - 2016-10-07 15:27:11 --> Loader Class Initialized
DEBUG - 2016-10-07 15:27:11 --> Config file loaded: D:\xampp\htdocs\dev-proyectarte\application\config/pagination.php
INFO - 2016-10-07 15:27:11 --> Helper loaded: url_helper
INFO - 2016-10-07 15:27:11 --> Helper loaded: site_helper
INFO - 2016-10-07 15:27:11 --> Helper loaded: form_helper
INFO - 2016-10-07 15:27:11 --> Helper loaded: date_helper
INFO - 2016-10-07 15:27:11 --> Helper loaded: string_helper
INFO - 2016-10-07 15:27:11 --> Helper loaded: file_helper
INFO - 2016-10-07 15:27:11 --> Helper loaded: frontend_helper
INFO - 2016-10-07 15:27:11 --> Helper loaded: text_helper
INFO - 2016-10-07 15:27:11 --> Database Driver Class Initialized
DEBUG - 2016-10-07 15:27:11 --> Session Class Initialized
INFO - 2016-10-07 15:27:11 --> Encrypt Class Initialized
DEBUG - 2016-10-07 15:27:11 --> Session routines successfully run
INFO - 2016-10-07 15:27:11 --> Parser Class Initialized
INFO - 2016-10-07 15:27:11 --> Language file loaded: language/en/pagination_lang.php
INFO - 2016-10-07 15:27:11 --> Pagination Class Initialized
INFO - 2016-10-07 15:27:11 --> User Agent Class Initialized
INFO - 2016-10-07 15:27:11 --> Form Validation Class Initialized
INFO - 2016-10-07 15:27:11 --> Upload Class Initialized
INFO - 2016-10-07 15:27:11 --> Controller Class Initialized
INFO - 2016-10-07 15:27:11 --> Language file loaded: language/en/core_lang.php
DEBUG - 2016-10-07 15:27:11 --> Upload class already loaded. Second attempt ignored.
INFO - 2016-10-07 15:27:11 --> Image Lib Class Initialized
INFO - 2016-10-07 15:27:11 --> Model Class Initialized
INFO - 2016-10-07 15:27:11 --> Model Class Initialized
INFO - 2016-10-07 15:27:11 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\footer.php
INFO - 2016-10-07 15:27:11 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\admin/course/index.php
INFO - 2016-10-07 15:27:11 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\admin/layouts/sidemenu.php
INFO - 2016-10-07 15:27:11 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\admin/layouts/headmenu.php
INFO - 2016-10-07 15:27:11 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\admin/layouts/main.php
INFO - 2016-10-07 15:27:11 --> Final output sent to browser
DEBUG - 2016-10-07 15:27:11 --> Total execution time: 0.1030
INFO - 2016-10-07 15:27:12 --> Config Class Initialized
INFO - 2016-10-07 15:27:12 --> Hooks Class Initialized
DEBUG - 2016-10-07 15:27:12 --> UTF-8 Support Enabled
INFO - 2016-10-07 15:27:12 --> Utf8 Class Initialized
INFO - 2016-10-07 15:27:12 --> URI Class Initialized
INFO - 2016-10-07 15:27:12 --> Router Class Initialized
INFO - 2016-10-07 15:27:12 --> Output Class Initialized
INFO - 2016-10-07 15:27:12 --> Security Class Initialized
DEBUG - 2016-10-07 15:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-07 15:27:12 --> Input Class Initialized
INFO - 2016-10-07 15:27:12 --> Language Class Initialized
INFO - 2016-10-07 15:27:12 --> Loader Class Initialized
DEBUG - 2016-10-07 15:27:12 --> Config file loaded: D:\xampp\htdocs\dev-proyectarte\application\config/pagination.php
INFO - 2016-10-07 15:27:12 --> Helper loaded: url_helper
INFO - 2016-10-07 15:27:12 --> Helper loaded: site_helper
INFO - 2016-10-07 15:27:12 --> Helper loaded: form_helper
INFO - 2016-10-07 15:27:12 --> Helper loaded: date_helper
INFO - 2016-10-07 15:27:12 --> Helper loaded: string_helper
INFO - 2016-10-07 15:27:12 --> Helper loaded: file_helper
INFO - 2016-10-07 15:27:12 --> Helper loaded: frontend_helper
INFO - 2016-10-07 15:27:12 --> Helper loaded: text_helper
INFO - 2016-10-07 15:27:12 --> Database Driver Class Initialized
DEBUG - 2016-10-07 15:27:12 --> Session Class Initialized
INFO - 2016-10-07 15:27:12 --> Encrypt Class Initialized
DEBUG - 2016-10-07 15:27:12 --> Session routines successfully run
INFO - 2016-10-07 15:27:12 --> Parser Class Initialized
INFO - 2016-10-07 15:27:12 --> Language file loaded: language/en/pagination_lang.php
INFO - 2016-10-07 15:27:12 --> Pagination Class Initialized
INFO - 2016-10-07 15:27:12 --> User Agent Class Initialized
INFO - 2016-10-07 15:27:12 --> Form Validation Class Initialized
INFO - 2016-10-07 15:27:12 --> Upload Class Initialized
INFO - 2016-10-07 15:27:12 --> Controller Class Initialized
INFO - 2016-10-07 15:27:12 --> Language file loaded: language/en/core_lang.php
DEBUG - 2016-10-07 15:27:12 --> Upload class already loaded. Second attempt ignored.
INFO - 2016-10-07 15:27:12 --> Image Lib Class Initialized
INFO - 2016-10-07 15:27:12 --> Model Class Initialized
INFO - 2016-10-07 15:27:12 --> Model Class Initialized
INFO - 2016-10-07 15:27:12 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\admin/course/form.php
INFO - 2016-10-07 15:27:12 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\admin/layouts/sidemenu.php
INFO - 2016-10-07 15:27:12 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\admin/layouts/headmenu.php
INFO - 2016-10-07 15:27:12 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\admin/layouts/main.php
INFO - 2016-10-07 15:27:12 --> Final output sent to browser
DEBUG - 2016-10-07 15:27:12 --> Total execution time: 0.0700
INFO - 2016-10-07 15:27:21 --> Config Class Initialized
INFO - 2016-10-07 15:27:21 --> Hooks Class Initialized
DEBUG - 2016-10-07 15:27:21 --> UTF-8 Support Enabled
INFO - 2016-10-07 15:27:21 --> Utf8 Class Initialized
INFO - 2016-10-07 15:27:21 --> URI Class Initialized
INFO - 2016-10-07 15:27:21 --> Router Class Initialized
INFO - 2016-10-07 15:27:21 --> Output Class Initialized
INFO - 2016-10-07 15:27:21 --> Security Class Initialized
DEBUG - 2016-10-07 15:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-07 15:27:21 --> Input Class Initialized
INFO - 2016-10-07 15:27:21 --> Language Class Initialized
INFO - 2016-10-07 15:27:21 --> Loader Class Initialized
DEBUG - 2016-10-07 15:27:21 --> Config file loaded: D:\xampp\htdocs\dev-proyectarte\application\config/pagination.php
INFO - 2016-10-07 15:27:21 --> Helper loaded: url_helper
INFO - 2016-10-07 15:27:21 --> Helper loaded: site_helper
INFO - 2016-10-07 15:27:21 --> Helper loaded: form_helper
INFO - 2016-10-07 15:27:21 --> Helper loaded: date_helper
INFO - 2016-10-07 15:27:21 --> Helper loaded: string_helper
INFO - 2016-10-07 15:27:21 --> Helper loaded: file_helper
INFO - 2016-10-07 15:27:21 --> Helper loaded: frontend_helper
INFO - 2016-10-07 15:27:21 --> Helper loaded: text_helper
INFO - 2016-10-07 15:27:21 --> Database Driver Class Initialized
DEBUG - 2016-10-07 15:27:21 --> Session Class Initialized
INFO - 2016-10-07 15:27:21 --> Encrypt Class Initialized
DEBUG - 2016-10-07 15:27:21 --> Session routines successfully run
INFO - 2016-10-07 15:27:21 --> Parser Class Initialized
INFO - 2016-10-07 15:27:21 --> Language file loaded: language/en/pagination_lang.php
INFO - 2016-10-07 15:27:21 --> Pagination Class Initialized
INFO - 2016-10-07 15:27:21 --> User Agent Class Initialized
INFO - 2016-10-07 15:27:21 --> Form Validation Class Initialized
INFO - 2016-10-07 15:27:21 --> Upload Class Initialized
INFO - 2016-10-07 15:27:21 --> Controller Class Initialized
INFO - 2016-10-07 15:27:21 --> Language file loaded: language/en/core_lang.php
DEBUG - 2016-10-07 15:27:21 --> Upload class already loaded. Second attempt ignored.
INFO - 2016-10-07 15:27:21 --> Image Lib Class Initialized
INFO - 2016-10-07 15:27:21 --> Model Class Initialized
INFO - 2016-10-07 15:27:21 --> Model Class Initialized
INFO - 2016-10-07 15:27:21 --> Language file loaded: language/en/form_validation_lang.php
ERROR - 2016-10-07 15:27:21 --> Severity: Notice --> Undefined index: COURSE_CONTENT D:\xampp\htdocs\dev-proyectarte\application\controllers\admin\Course.php 271
DEBUG - 2016-10-07 15:27:21 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2016-10-07 15:27:21 --> Image_lib class already loaded. Second attempt ignored.
ERROR - 2016-10-07 15:27:21 --> Severity: Notice --> Undefined index: COURSE_CONTENT D:\xampp\htdocs\dev-proyectarte\application\controllers\admin\Course.php 292
INFO - 2016-10-07 15:27:22 --> Config Class Initialized
INFO - 2016-10-07 15:27:22 --> Hooks Class Initialized
DEBUG - 2016-10-07 15:27:22 --> UTF-8 Support Enabled
INFO - 2016-10-07 15:27:22 --> Utf8 Class Initialized
INFO - 2016-10-07 15:27:22 --> URI Class Initialized
INFO - 2016-10-07 15:27:22 --> Router Class Initialized
INFO - 2016-10-07 15:27:22 --> Output Class Initialized
INFO - 2016-10-07 15:27:22 --> Security Class Initialized
DEBUG - 2016-10-07 15:27:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-07 15:27:22 --> Input Class Initialized
INFO - 2016-10-07 15:27:22 --> Language Class Initialized
INFO - 2016-10-07 15:27:22 --> Loader Class Initialized
DEBUG - 2016-10-07 15:27:22 --> Config file loaded: D:\xampp\htdocs\dev-proyectarte\application\config/pagination.php
INFO - 2016-10-07 15:27:22 --> Helper loaded: url_helper
INFO - 2016-10-07 15:27:22 --> Helper loaded: site_helper
INFO - 2016-10-07 15:27:22 --> Helper loaded: form_helper
INFO - 2016-10-07 15:27:22 --> Helper loaded: date_helper
INFO - 2016-10-07 15:27:22 --> Helper loaded: string_helper
INFO - 2016-10-07 15:27:22 --> Helper loaded: file_helper
INFO - 2016-10-07 15:27:22 --> Helper loaded: frontend_helper
INFO - 2016-10-07 15:27:22 --> Helper loaded: text_helper
INFO - 2016-10-07 15:27:22 --> Database Driver Class Initialized
DEBUG - 2016-10-07 15:27:22 --> Session Class Initialized
INFO - 2016-10-07 15:27:22 --> Encrypt Class Initialized
DEBUG - 2016-10-07 15:27:22 --> Session routines successfully run
INFO - 2016-10-07 15:27:22 --> Parser Class Initialized
INFO - 2016-10-07 15:27:22 --> Language file loaded: language/en/pagination_lang.php
INFO - 2016-10-07 15:27:22 --> Pagination Class Initialized
INFO - 2016-10-07 15:27:22 --> User Agent Class Initialized
INFO - 2016-10-07 15:27:22 --> Form Validation Class Initialized
INFO - 2016-10-07 15:27:22 --> Upload Class Initialized
INFO - 2016-10-07 15:27:22 --> Controller Class Initialized
INFO - 2016-10-07 15:27:22 --> Language file loaded: language/en/core_lang.php
DEBUG - 2016-10-07 15:27:22 --> Upload class already loaded. Second attempt ignored.
INFO - 2016-10-07 15:27:22 --> Image Lib Class Initialized
INFO - 2016-10-07 15:27:22 --> Model Class Initialized
INFO - 2016-10-07 15:27:22 --> Model Class Initialized
INFO - 2016-10-07 15:27:22 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\admin/unit/form.php
INFO - 2016-10-07 15:27:22 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\admin/layouts/sidemenu.php
INFO - 2016-10-07 15:27:22 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\admin/layouts/headmenu.php
INFO - 2016-10-07 15:27:22 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\admin/layouts/main.php
INFO - 2016-10-07 15:27:22 --> Final output sent to browser
DEBUG - 2016-10-07 15:27:22 --> Total execution time: 0.0940
INFO - 2016-10-07 15:30:23 --> Config Class Initialized
INFO - 2016-10-07 15:30:23 --> Hooks Class Initialized
DEBUG - 2016-10-07 15:30:23 --> UTF-8 Support Enabled
INFO - 2016-10-07 15:30:23 --> Utf8 Class Initialized
INFO - 2016-10-07 15:30:23 --> URI Class Initialized
INFO - 2016-10-07 15:30:23 --> Router Class Initialized
INFO - 2016-10-07 15:30:23 --> Output Class Initialized
INFO - 2016-10-07 15:30:23 --> Security Class Initialized
DEBUG - 2016-10-07 15:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-07 15:30:23 --> Input Class Initialized
INFO - 2016-10-07 15:30:23 --> Language Class Initialized
INFO - 2016-10-07 15:30:23 --> Loader Class Initialized
DEBUG - 2016-10-07 15:30:23 --> Config file loaded: D:\xampp\htdocs\dev-proyectarte\application\config/pagination.php
INFO - 2016-10-07 15:30:23 --> Helper loaded: url_helper
INFO - 2016-10-07 15:30:23 --> Helper loaded: site_helper
INFO - 2016-10-07 15:30:23 --> Helper loaded: form_helper
INFO - 2016-10-07 15:30:23 --> Helper loaded: date_helper
INFO - 2016-10-07 15:30:23 --> Helper loaded: string_helper
INFO - 2016-10-07 15:30:23 --> Helper loaded: file_helper
INFO - 2016-10-07 15:30:23 --> Helper loaded: frontend_helper
INFO - 2016-10-07 15:30:23 --> Helper loaded: text_helper
INFO - 2016-10-07 15:30:23 --> Database Driver Class Initialized
DEBUG - 2016-10-07 15:30:23 --> Session Class Initialized
INFO - 2016-10-07 15:30:23 --> Encrypt Class Initialized
DEBUG - 2016-10-07 15:30:23 --> Session routines successfully run
INFO - 2016-10-07 15:30:23 --> Parser Class Initialized
INFO - 2016-10-07 15:30:23 --> Language file loaded: language/en/pagination_lang.php
INFO - 2016-10-07 15:30:23 --> Pagination Class Initialized
INFO - 2016-10-07 15:30:23 --> User Agent Class Initialized
INFO - 2016-10-07 15:30:23 --> Form Validation Class Initialized
INFO - 2016-10-07 15:30:23 --> Upload Class Initialized
INFO - 2016-10-07 15:30:23 --> Controller Class Initialized
INFO - 2016-10-07 15:30:23 --> Language file loaded: language/en/core_lang.php
DEBUG - 2016-10-07 15:30:23 --> Upload class already loaded. Second attempt ignored.
INFO - 2016-10-07 15:30:23 --> Image Lib Class Initialized
INFO - 2016-10-07 15:30:23 --> Model Class Initialized
INFO - 2016-10-07 15:30:23 --> Model Class Initialized
INFO - 2016-10-07 15:30:23 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\footer.php
INFO - 2016-10-07 15:30:23 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\admin/course/index.php
INFO - 2016-10-07 15:30:23 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\admin/layouts/sidemenu.php
INFO - 2016-10-07 15:30:23 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\admin/layouts/headmenu.php
INFO - 2016-10-07 15:30:23 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\admin/layouts/main.php
INFO - 2016-10-07 15:30:23 --> Final output sent to browser
DEBUG - 2016-10-07 15:30:23 --> Total execution time: 0.0770
INFO - 2016-10-07 15:30:27 --> Config Class Initialized
INFO - 2016-10-07 15:30:27 --> Hooks Class Initialized
DEBUG - 2016-10-07 15:30:27 --> UTF-8 Support Enabled
INFO - 2016-10-07 15:30:27 --> Utf8 Class Initialized
INFO - 2016-10-07 15:30:27 --> URI Class Initialized
INFO - 2016-10-07 15:30:27 --> Router Class Initialized
INFO - 2016-10-07 15:30:27 --> Output Class Initialized
INFO - 2016-10-07 15:30:27 --> Security Class Initialized
DEBUG - 2016-10-07 15:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-07 15:30:27 --> Input Class Initialized
INFO - 2016-10-07 15:30:27 --> Language Class Initialized
INFO - 2016-10-07 15:30:27 --> Loader Class Initialized
DEBUG - 2016-10-07 15:30:27 --> Config file loaded: D:\xampp\htdocs\dev-proyectarte\application\config/pagination.php
INFO - 2016-10-07 15:30:27 --> Helper loaded: url_helper
INFO - 2016-10-07 15:30:27 --> Helper loaded: site_helper
INFO - 2016-10-07 15:30:27 --> Helper loaded: form_helper
INFO - 2016-10-07 15:30:27 --> Helper loaded: date_helper
INFO - 2016-10-07 15:30:27 --> Helper loaded: string_helper
INFO - 2016-10-07 15:30:27 --> Helper loaded: file_helper
INFO - 2016-10-07 15:30:27 --> Helper loaded: frontend_helper
INFO - 2016-10-07 15:30:27 --> Helper loaded: text_helper
INFO - 2016-10-07 15:30:27 --> Database Driver Class Initialized
DEBUG - 2016-10-07 15:30:27 --> Session Class Initialized
INFO - 2016-10-07 15:30:27 --> Encrypt Class Initialized
DEBUG - 2016-10-07 15:30:27 --> Session routines successfully run
INFO - 2016-10-07 15:30:27 --> Parser Class Initialized
INFO - 2016-10-07 15:30:27 --> Language file loaded: language/en/pagination_lang.php
INFO - 2016-10-07 15:30:27 --> Pagination Class Initialized
INFO - 2016-10-07 15:30:27 --> User Agent Class Initialized
INFO - 2016-10-07 15:30:27 --> Form Validation Class Initialized
INFO - 2016-10-07 15:30:27 --> Upload Class Initialized
INFO - 2016-10-07 15:30:27 --> Controller Class Initialized
INFO - 2016-10-07 15:30:27 --> Language file loaded: language/en/core_lang.php
DEBUG - 2016-10-07 15:30:27 --> Upload class already loaded. Second attempt ignored.
INFO - 2016-10-07 15:30:27 --> Image Lib Class Initialized
INFO - 2016-10-07 15:30:27 --> Model Class Initialized
INFO - 2016-10-07 15:30:27 --> Model Class Initialized
INFO - 2016-10-07 15:30:27 --> Config Class Initialized
INFO - 2016-10-07 15:30:27 --> Hooks Class Initialized
DEBUG - 2016-10-07 15:30:27 --> UTF-8 Support Enabled
INFO - 2016-10-07 15:30:27 --> Utf8 Class Initialized
INFO - 2016-10-07 15:30:27 --> URI Class Initialized
INFO - 2016-10-07 15:30:27 --> Router Class Initialized
INFO - 2016-10-07 15:30:27 --> Output Class Initialized
INFO - 2016-10-07 15:30:27 --> Security Class Initialized
DEBUG - 2016-10-07 15:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-07 15:30:27 --> Input Class Initialized
INFO - 2016-10-07 15:30:27 --> Language Class Initialized
INFO - 2016-10-07 15:30:27 --> Loader Class Initialized
DEBUG - 2016-10-07 15:30:27 --> Config file loaded: D:\xampp\htdocs\dev-proyectarte\application\config/pagination.php
INFO - 2016-10-07 15:30:27 --> Helper loaded: url_helper
INFO - 2016-10-07 15:30:27 --> Helper loaded: site_helper
INFO - 2016-10-07 15:30:27 --> Helper loaded: form_helper
INFO - 2016-10-07 15:30:27 --> Helper loaded: date_helper
INFO - 2016-10-07 15:30:27 --> Helper loaded: string_helper
INFO - 2016-10-07 15:30:27 --> Helper loaded: file_helper
INFO - 2016-10-07 15:30:27 --> Helper loaded: frontend_helper
INFO - 2016-10-07 15:30:27 --> Helper loaded: text_helper
INFO - 2016-10-07 15:30:27 --> Database Driver Class Initialized
DEBUG - 2016-10-07 15:30:27 --> Session Class Initialized
INFO - 2016-10-07 15:30:27 --> Encrypt Class Initialized
DEBUG - 2016-10-07 15:30:27 --> Session routines successfully run
INFO - 2016-10-07 15:30:27 --> Parser Class Initialized
INFO - 2016-10-07 15:30:27 --> Language file loaded: language/en/pagination_lang.php
INFO - 2016-10-07 15:30:27 --> Pagination Class Initialized
INFO - 2016-10-07 15:30:27 --> User Agent Class Initialized
INFO - 2016-10-07 15:30:27 --> Form Validation Class Initialized
INFO - 2016-10-07 15:30:27 --> Upload Class Initialized
INFO - 2016-10-07 15:30:27 --> Controller Class Initialized
INFO - 2016-10-07 15:30:27 --> Language file loaded: language/en/core_lang.php
DEBUG - 2016-10-07 15:30:27 --> Upload class already loaded. Second attempt ignored.
INFO - 2016-10-07 15:30:27 --> Image Lib Class Initialized
INFO - 2016-10-07 15:30:27 --> Model Class Initialized
INFO - 2016-10-07 15:30:27 --> Model Class Initialized
INFO - 2016-10-07 15:30:27 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\footer.php
INFO - 2016-10-07 15:30:27 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\admin/course/index.php
INFO - 2016-10-07 15:30:27 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\admin/layouts/sidemenu.php
INFO - 2016-10-07 15:30:27 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\admin/layouts/headmenu.php
INFO - 2016-10-07 15:30:27 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\admin/layouts/main.php
INFO - 2016-10-07 15:30:27 --> Final output sent to browser
DEBUG - 2016-10-07 15:30:27 --> Total execution time: 0.0710
INFO - 2016-10-07 15:30:28 --> Config Class Initialized
INFO - 2016-10-07 15:30:28 --> Hooks Class Initialized
DEBUG - 2016-10-07 15:30:28 --> UTF-8 Support Enabled
INFO - 2016-10-07 15:30:28 --> Utf8 Class Initialized
INFO - 2016-10-07 15:30:28 --> URI Class Initialized
INFO - 2016-10-07 15:30:28 --> Router Class Initialized
INFO - 2016-10-07 15:30:28 --> Output Class Initialized
INFO - 2016-10-07 15:30:28 --> Security Class Initialized
DEBUG - 2016-10-07 15:30:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-07 15:30:28 --> Input Class Initialized
INFO - 2016-10-07 15:30:28 --> Language Class Initialized
INFO - 2016-10-07 15:30:28 --> Loader Class Initialized
DEBUG - 2016-10-07 15:30:28 --> Config file loaded: D:\xampp\htdocs\dev-proyectarte\application\config/pagination.php
INFO - 2016-10-07 15:30:28 --> Helper loaded: url_helper
INFO - 2016-10-07 15:30:28 --> Helper loaded: site_helper
INFO - 2016-10-07 15:30:28 --> Helper loaded: form_helper
INFO - 2016-10-07 15:30:28 --> Helper loaded: date_helper
INFO - 2016-10-07 15:30:28 --> Helper loaded: string_helper
INFO - 2016-10-07 15:30:28 --> Helper loaded: file_helper
INFO - 2016-10-07 15:30:28 --> Helper loaded: frontend_helper
INFO - 2016-10-07 15:30:28 --> Helper loaded: text_helper
INFO - 2016-10-07 15:30:28 --> Database Driver Class Initialized
DEBUG - 2016-10-07 15:30:28 --> Session Class Initialized
INFO - 2016-10-07 15:30:28 --> Encrypt Class Initialized
DEBUG - 2016-10-07 15:30:28 --> Session routines successfully run
INFO - 2016-10-07 15:30:28 --> Parser Class Initialized
INFO - 2016-10-07 15:30:28 --> Language file loaded: language/en/pagination_lang.php
INFO - 2016-10-07 15:30:28 --> Pagination Class Initialized
INFO - 2016-10-07 15:30:28 --> User Agent Class Initialized
INFO - 2016-10-07 15:30:28 --> Form Validation Class Initialized
INFO - 2016-10-07 15:30:28 --> Upload Class Initialized
INFO - 2016-10-07 15:30:28 --> Controller Class Initialized
INFO - 2016-10-07 15:30:28 --> Language file loaded: language/en/core_lang.php
DEBUG - 2016-10-07 15:30:28 --> Upload class already loaded. Second attempt ignored.
INFO - 2016-10-07 15:30:28 --> Image Lib Class Initialized
INFO - 2016-10-07 15:30:28 --> Model Class Initialized
INFO - 2016-10-07 15:30:28 --> Model Class Initialized
INFO - 2016-10-07 15:30:28 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\admin/course/form.php
INFO - 2016-10-07 15:30:28 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\admin/layouts/sidemenu.php
INFO - 2016-10-07 15:30:28 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\admin/layouts/headmenu.php
INFO - 2016-10-07 15:30:28 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\admin/layouts/main.php
INFO - 2016-10-07 15:30:28 --> Final output sent to browser
DEBUG - 2016-10-07 15:30:28 --> Total execution time: 0.1170
INFO - 2016-10-07 15:30:34 --> Config Class Initialized
INFO - 2016-10-07 15:30:34 --> Hooks Class Initialized
DEBUG - 2016-10-07 15:30:34 --> UTF-8 Support Enabled
INFO - 2016-10-07 15:30:34 --> Utf8 Class Initialized
INFO - 2016-10-07 15:30:34 --> URI Class Initialized
INFO - 2016-10-07 15:30:34 --> Router Class Initialized
INFO - 2016-10-07 15:30:34 --> Output Class Initialized
INFO - 2016-10-07 15:30:34 --> Security Class Initialized
DEBUG - 2016-10-07 15:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-07 15:30:34 --> Input Class Initialized
INFO - 2016-10-07 15:30:34 --> Language Class Initialized
INFO - 2016-10-07 15:30:34 --> Loader Class Initialized
DEBUG - 2016-10-07 15:30:34 --> Config file loaded: D:\xampp\htdocs\dev-proyectarte\application\config/pagination.php
INFO - 2016-10-07 15:30:34 --> Helper loaded: url_helper
INFO - 2016-10-07 15:30:34 --> Helper loaded: site_helper
INFO - 2016-10-07 15:30:34 --> Helper loaded: form_helper
INFO - 2016-10-07 15:30:34 --> Helper loaded: date_helper
INFO - 2016-10-07 15:30:34 --> Helper loaded: string_helper
INFO - 2016-10-07 15:30:34 --> Helper loaded: file_helper
INFO - 2016-10-07 15:30:34 --> Helper loaded: frontend_helper
INFO - 2016-10-07 15:30:34 --> Helper loaded: text_helper
INFO - 2016-10-07 15:30:34 --> Database Driver Class Initialized
DEBUG - 2016-10-07 15:30:34 --> Session Class Initialized
INFO - 2016-10-07 15:30:34 --> Encrypt Class Initialized
DEBUG - 2016-10-07 15:30:34 --> Session routines successfully run
INFO - 2016-10-07 15:30:34 --> Parser Class Initialized
INFO - 2016-10-07 15:30:34 --> Language file loaded: language/en/pagination_lang.php
INFO - 2016-10-07 15:30:34 --> Pagination Class Initialized
INFO - 2016-10-07 15:30:34 --> User Agent Class Initialized
INFO - 2016-10-07 15:30:34 --> Form Validation Class Initialized
INFO - 2016-10-07 15:30:34 --> Upload Class Initialized
INFO - 2016-10-07 15:30:34 --> Controller Class Initialized
INFO - 2016-10-07 15:30:34 --> Language file loaded: language/en/core_lang.php
DEBUG - 2016-10-07 15:30:34 --> Upload class already loaded. Second attempt ignored.
INFO - 2016-10-07 15:30:34 --> Image Lib Class Initialized
INFO - 2016-10-07 15:30:34 --> Model Class Initialized
INFO - 2016-10-07 15:30:34 --> Model Class Initialized
INFO - 2016-10-07 15:30:34 --> Language file loaded: language/en/form_validation_lang.php
ERROR - 2016-10-07 15:30:34 --> Severity: Notice --> Undefined index: COURSE_CONTENT D:\xampp\htdocs\dev-proyectarte\application\controllers\admin\Course.php 271
DEBUG - 2016-10-07 15:30:34 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2016-10-07 15:30:34 --> Image_lib class already loaded. Second attempt ignored.
ERROR - 2016-10-07 15:30:34 --> Severity: Notice --> Undefined index: COURSE_CONTENT D:\xampp\htdocs\dev-proyectarte\application\controllers\admin\Course.php 292
INFO - 2016-10-07 15:30:34 --> Config Class Initialized
INFO - 2016-10-07 15:30:34 --> Hooks Class Initialized
DEBUG - 2016-10-07 15:30:34 --> UTF-8 Support Enabled
INFO - 2016-10-07 15:30:34 --> Utf8 Class Initialized
INFO - 2016-10-07 15:30:34 --> URI Class Initialized
INFO - 2016-10-07 15:30:34 --> Router Class Initialized
INFO - 2016-10-07 15:30:34 --> Output Class Initialized
INFO - 2016-10-07 15:30:34 --> Security Class Initialized
DEBUG - 2016-10-07 15:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-07 15:30:34 --> Input Class Initialized
INFO - 2016-10-07 15:30:34 --> Language Class Initialized
INFO - 2016-10-07 15:30:34 --> Loader Class Initialized
DEBUG - 2016-10-07 15:30:34 --> Config file loaded: D:\xampp\htdocs\dev-proyectarte\application\config/pagination.php
INFO - 2016-10-07 15:30:34 --> Helper loaded: url_helper
INFO - 2016-10-07 15:30:34 --> Helper loaded: site_helper
INFO - 2016-10-07 15:30:34 --> Helper loaded: form_helper
INFO - 2016-10-07 15:30:34 --> Helper loaded: date_helper
INFO - 2016-10-07 15:30:34 --> Helper loaded: string_helper
INFO - 2016-10-07 15:30:34 --> Helper loaded: file_helper
INFO - 2016-10-07 15:30:34 --> Helper loaded: frontend_helper
INFO - 2016-10-07 15:30:34 --> Helper loaded: text_helper
INFO - 2016-10-07 15:30:34 --> Database Driver Class Initialized
DEBUG - 2016-10-07 15:30:34 --> Session Class Initialized
INFO - 2016-10-07 15:30:34 --> Encrypt Class Initialized
DEBUG - 2016-10-07 15:30:34 --> Session routines successfully run
INFO - 2016-10-07 15:30:34 --> Parser Class Initialized
INFO - 2016-10-07 15:30:34 --> Language file loaded: language/en/pagination_lang.php
INFO - 2016-10-07 15:30:34 --> Pagination Class Initialized
INFO - 2016-10-07 15:30:34 --> User Agent Class Initialized
INFO - 2016-10-07 15:30:34 --> Form Validation Class Initialized
INFO - 2016-10-07 15:30:34 --> Upload Class Initialized
INFO - 2016-10-07 15:30:34 --> Controller Class Initialized
INFO - 2016-10-07 15:30:34 --> Language file loaded: language/en/core_lang.php
DEBUG - 2016-10-07 15:30:34 --> Upload class already loaded. Second attempt ignored.
INFO - 2016-10-07 15:30:34 --> Image Lib Class Initialized
INFO - 2016-10-07 15:30:34 --> Model Class Initialized
INFO - 2016-10-07 15:30:34 --> Model Class Initialized
INFO - 2016-10-07 15:30:34 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\admin/unit/form.php
INFO - 2016-10-07 15:30:34 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\admin/layouts/sidemenu.php
INFO - 2016-10-07 15:30:34 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\admin/layouts/headmenu.php
INFO - 2016-10-07 15:30:34 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\admin/layouts/main.php
INFO - 2016-10-07 15:30:34 --> Final output sent to browser
DEBUG - 2016-10-07 15:30:34 --> Total execution time: 0.0810
INFO - 2016-10-07 15:32:49 --> Config Class Initialized
INFO - 2016-10-07 15:32:49 --> Hooks Class Initialized
DEBUG - 2016-10-07 15:32:49 --> UTF-8 Support Enabled
INFO - 2016-10-07 15:32:49 --> Utf8 Class Initialized
INFO - 2016-10-07 15:32:49 --> URI Class Initialized
INFO - 2016-10-07 15:32:49 --> Router Class Initialized
INFO - 2016-10-07 15:32:49 --> Output Class Initialized
INFO - 2016-10-07 15:32:49 --> Security Class Initialized
DEBUG - 2016-10-07 15:32:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-07 15:32:49 --> Input Class Initialized
INFO - 2016-10-07 15:32:49 --> Language Class Initialized
INFO - 2016-10-07 15:32:49 --> Loader Class Initialized
DEBUG - 2016-10-07 15:32:49 --> Config file loaded: D:\xampp\htdocs\dev-proyectarte\application\config/pagination.php
INFO - 2016-10-07 15:32:49 --> Helper loaded: url_helper
INFO - 2016-10-07 15:32:49 --> Helper loaded: site_helper
INFO - 2016-10-07 15:32:49 --> Helper loaded: form_helper
INFO - 2016-10-07 15:32:49 --> Helper loaded: date_helper
INFO - 2016-10-07 15:32:49 --> Helper loaded: string_helper
INFO - 2016-10-07 15:32:49 --> Helper loaded: file_helper
INFO - 2016-10-07 15:32:49 --> Helper loaded: frontend_helper
INFO - 2016-10-07 15:32:49 --> Helper loaded: text_helper
INFO - 2016-10-07 15:32:49 --> Database Driver Class Initialized
DEBUG - 2016-10-07 15:32:49 --> Session Class Initialized
INFO - 2016-10-07 15:32:49 --> Encrypt Class Initialized
DEBUG - 2016-10-07 15:32:49 --> Session routines successfully run
INFO - 2016-10-07 15:32:49 --> Parser Class Initialized
INFO - 2016-10-07 15:32:49 --> Language file loaded: language/en/pagination_lang.php
INFO - 2016-10-07 15:32:49 --> Pagination Class Initialized
INFO - 2016-10-07 15:32:49 --> User Agent Class Initialized
INFO - 2016-10-07 15:32:49 --> Form Validation Class Initialized
INFO - 2016-10-07 15:32:49 --> Upload Class Initialized
INFO - 2016-10-07 15:32:49 --> Controller Class Initialized
INFO - 2016-10-07 15:32:49 --> Language file loaded: language/en/core_lang.php
DEBUG - 2016-10-07 15:32:49 --> Upload class already loaded. Second attempt ignored.
INFO - 2016-10-07 15:32:49 --> Image Lib Class Initialized
INFO - 2016-10-07 15:32:49 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\dashboard.php
INFO - 2016-10-07 15:32:49 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\admin/layouts/sidemenu.php
INFO - 2016-10-07 15:32:49 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\admin/layouts/headmenu.php
INFO - 2016-10-07 15:32:49 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\admin/layouts/main.php
INFO - 2016-10-07 15:32:49 --> Final output sent to browser
DEBUG - 2016-10-07 15:32:49 --> Total execution time: 0.0880
INFO - 2016-10-07 15:32:50 --> Config Class Initialized
INFO - 2016-10-07 15:32:50 --> Hooks Class Initialized
DEBUG - 2016-10-07 15:32:50 --> UTF-8 Support Enabled
INFO - 2016-10-07 15:32:50 --> Utf8 Class Initialized
INFO - 2016-10-07 15:32:50 --> URI Class Initialized
INFO - 2016-10-07 15:32:50 --> Router Class Initialized
INFO - 2016-10-07 15:32:50 --> Output Class Initialized
INFO - 2016-10-07 15:32:50 --> Security Class Initialized
DEBUG - 2016-10-07 15:32:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-07 15:32:50 --> Input Class Initialized
INFO - 2016-10-07 15:32:50 --> Language Class Initialized
INFO - 2016-10-07 15:32:50 --> Loader Class Initialized
DEBUG - 2016-10-07 15:32:50 --> Config file loaded: D:\xampp\htdocs\dev-proyectarte\application\config/pagination.php
INFO - 2016-10-07 15:32:50 --> Helper loaded: url_helper
INFO - 2016-10-07 15:32:50 --> Helper loaded: site_helper
INFO - 2016-10-07 15:32:50 --> Helper loaded: form_helper
INFO - 2016-10-07 15:32:50 --> Helper loaded: date_helper
INFO - 2016-10-07 15:32:50 --> Helper loaded: string_helper
INFO - 2016-10-07 15:32:50 --> Helper loaded: file_helper
INFO - 2016-10-07 15:32:50 --> Helper loaded: frontend_helper
INFO - 2016-10-07 15:32:50 --> Helper loaded: text_helper
INFO - 2016-10-07 15:32:50 --> Database Driver Class Initialized
DEBUG - 2016-10-07 15:32:50 --> Session Class Initialized
INFO - 2016-10-07 15:32:50 --> Encrypt Class Initialized
DEBUG - 2016-10-07 15:32:50 --> Session routines successfully run
INFO - 2016-10-07 15:32:50 --> Parser Class Initialized
INFO - 2016-10-07 15:32:50 --> Language file loaded: language/en/pagination_lang.php
INFO - 2016-10-07 15:32:50 --> Pagination Class Initialized
INFO - 2016-10-07 15:32:50 --> User Agent Class Initialized
INFO - 2016-10-07 15:32:50 --> Form Validation Class Initialized
INFO - 2016-10-07 15:32:50 --> Upload Class Initialized
INFO - 2016-10-07 15:32:50 --> Controller Class Initialized
INFO - 2016-10-07 15:32:50 --> Language file loaded: language/en/core_lang.php
DEBUG - 2016-10-07 15:32:50 --> Upload class already loaded. Second attempt ignored.
INFO - 2016-10-07 15:32:50 --> Image Lib Class Initialized
INFO - 2016-10-07 15:32:50 --> Model Class Initialized
INFO - 2016-10-07 15:32:50 --> Model Class Initialized
INFO - 2016-10-07 15:32:50 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\footer.php
INFO - 2016-10-07 15:32:50 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\admin/course/index.php
INFO - 2016-10-07 15:32:50 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\admin/layouts/sidemenu.php
INFO - 2016-10-07 15:32:50 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\admin/layouts/headmenu.php
INFO - 2016-10-07 15:32:50 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\admin/layouts/main.php
INFO - 2016-10-07 15:32:50 --> Final output sent to browser
DEBUG - 2016-10-07 15:32:50 --> Total execution time: 0.0680
INFO - 2016-10-07 15:32:54 --> Config Class Initialized
INFO - 2016-10-07 15:32:54 --> Hooks Class Initialized
DEBUG - 2016-10-07 15:32:54 --> UTF-8 Support Enabled
INFO - 2016-10-07 15:32:54 --> Utf8 Class Initialized
INFO - 2016-10-07 15:32:54 --> URI Class Initialized
INFO - 2016-10-07 15:32:54 --> Router Class Initialized
INFO - 2016-10-07 15:32:54 --> Output Class Initialized
INFO - 2016-10-07 15:32:54 --> Security Class Initialized
DEBUG - 2016-10-07 15:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-07 15:32:54 --> Input Class Initialized
INFO - 2016-10-07 15:32:54 --> Language Class Initialized
INFO - 2016-10-07 15:32:54 --> Loader Class Initialized
DEBUG - 2016-10-07 15:32:54 --> Config file loaded: D:\xampp\htdocs\dev-proyectarte\application\config/pagination.php
INFO - 2016-10-07 15:32:54 --> Helper loaded: url_helper
INFO - 2016-10-07 15:32:54 --> Helper loaded: site_helper
INFO - 2016-10-07 15:32:54 --> Helper loaded: form_helper
INFO - 2016-10-07 15:32:54 --> Helper loaded: date_helper
INFO - 2016-10-07 15:32:54 --> Helper loaded: string_helper
INFO - 2016-10-07 15:32:54 --> Helper loaded: file_helper
INFO - 2016-10-07 15:32:54 --> Helper loaded: frontend_helper
INFO - 2016-10-07 15:32:54 --> Helper loaded: text_helper
INFO - 2016-10-07 15:32:54 --> Database Driver Class Initialized
DEBUG - 2016-10-07 15:32:54 --> Session Class Initialized
INFO - 2016-10-07 15:32:54 --> Encrypt Class Initialized
DEBUG - 2016-10-07 15:32:54 --> Session routines successfully run
INFO - 2016-10-07 15:32:54 --> Parser Class Initialized
INFO - 2016-10-07 15:32:54 --> Language file loaded: language/en/pagination_lang.php
INFO - 2016-10-07 15:32:54 --> Pagination Class Initialized
INFO - 2016-10-07 15:32:54 --> User Agent Class Initialized
INFO - 2016-10-07 15:32:54 --> Form Validation Class Initialized
INFO - 2016-10-07 15:32:54 --> Upload Class Initialized
INFO - 2016-10-07 15:32:54 --> Controller Class Initialized
INFO - 2016-10-07 15:32:54 --> Language file loaded: language/en/core_lang.php
DEBUG - 2016-10-07 15:32:54 --> Upload class already loaded. Second attempt ignored.
INFO - 2016-10-07 15:32:54 --> Image Lib Class Initialized
INFO - 2016-10-07 15:32:54 --> Model Class Initialized
INFO - 2016-10-07 15:32:54 --> Model Class Initialized
INFO - 2016-10-07 15:32:54 --> Config Class Initialized
INFO - 2016-10-07 15:32:54 --> Hooks Class Initialized
DEBUG - 2016-10-07 15:32:54 --> UTF-8 Support Enabled
INFO - 2016-10-07 15:32:54 --> Utf8 Class Initialized
INFO - 2016-10-07 15:32:54 --> URI Class Initialized
INFO - 2016-10-07 15:32:54 --> Router Class Initialized
INFO - 2016-10-07 15:32:54 --> Output Class Initialized
INFO - 2016-10-07 15:32:54 --> Security Class Initialized
DEBUG - 2016-10-07 15:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-07 15:32:54 --> Input Class Initialized
INFO - 2016-10-07 15:32:54 --> Language Class Initialized
INFO - 2016-10-07 15:32:54 --> Loader Class Initialized
DEBUG - 2016-10-07 15:32:54 --> Config file loaded: D:\xampp\htdocs\dev-proyectarte\application\config/pagination.php
INFO - 2016-10-07 15:32:54 --> Helper loaded: url_helper
INFO - 2016-10-07 15:32:54 --> Helper loaded: site_helper
INFO - 2016-10-07 15:32:54 --> Helper loaded: form_helper
INFO - 2016-10-07 15:32:54 --> Helper loaded: date_helper
INFO - 2016-10-07 15:32:54 --> Helper loaded: string_helper
INFO - 2016-10-07 15:32:54 --> Helper loaded: file_helper
INFO - 2016-10-07 15:32:54 --> Helper loaded: frontend_helper
INFO - 2016-10-07 15:32:54 --> Helper loaded: text_helper
INFO - 2016-10-07 15:32:54 --> Database Driver Class Initialized
DEBUG - 2016-10-07 15:32:54 --> Session Class Initialized
INFO - 2016-10-07 15:32:54 --> Encrypt Class Initialized
DEBUG - 2016-10-07 15:32:54 --> Session routines successfully run
INFO - 2016-10-07 15:32:54 --> Parser Class Initialized
INFO - 2016-10-07 15:32:54 --> Language file loaded: language/en/pagination_lang.php
INFO - 2016-10-07 15:32:54 --> Pagination Class Initialized
INFO - 2016-10-07 15:32:54 --> User Agent Class Initialized
INFO - 2016-10-07 15:32:54 --> Form Validation Class Initialized
INFO - 2016-10-07 15:32:54 --> Upload Class Initialized
INFO - 2016-10-07 15:32:54 --> Controller Class Initialized
INFO - 2016-10-07 15:32:54 --> Language file loaded: language/en/core_lang.php
DEBUG - 2016-10-07 15:32:54 --> Upload class already loaded. Second attempt ignored.
INFO - 2016-10-07 15:32:54 --> Image Lib Class Initialized
INFO - 2016-10-07 15:32:54 --> Model Class Initialized
INFO - 2016-10-07 15:32:54 --> Model Class Initialized
INFO - 2016-10-07 15:32:54 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\footer.php
INFO - 2016-10-07 15:32:54 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\admin/course/index.php
INFO - 2016-10-07 15:32:54 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\admin/layouts/sidemenu.php
INFO - 2016-10-07 15:32:54 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\admin/layouts/headmenu.php
INFO - 2016-10-07 15:32:54 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\admin/layouts/main.php
INFO - 2016-10-07 15:32:54 --> Final output sent to browser
DEBUG - 2016-10-07 15:32:54 --> Total execution time: 0.0760
INFO - 2016-10-07 15:50:54 --> Config Class Initialized
INFO - 2016-10-07 15:50:54 --> Hooks Class Initialized
DEBUG - 2016-10-07 15:50:54 --> UTF-8 Support Enabled
INFO - 2016-10-07 15:50:54 --> Utf8 Class Initialized
INFO - 2016-10-07 15:50:54 --> URI Class Initialized
INFO - 2016-10-07 15:50:54 --> Router Class Initialized
INFO - 2016-10-07 15:50:54 --> Output Class Initialized
INFO - 2016-10-07 15:50:54 --> Security Class Initialized
DEBUG - 2016-10-07 15:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-10-07 15:50:54 --> Input Class Initialized
INFO - 2016-10-07 15:50:54 --> Language Class Initialized
INFO - 2016-10-07 15:50:54 --> Loader Class Initialized
DEBUG - 2016-10-07 15:50:54 --> Config file loaded: D:\xampp\htdocs\dev-proyectarte\application\config/pagination.php
INFO - 2016-10-07 15:50:54 --> Helper loaded: url_helper
INFO - 2016-10-07 15:50:54 --> Helper loaded: site_helper
INFO - 2016-10-07 15:50:54 --> Helper loaded: form_helper
INFO - 2016-10-07 15:50:54 --> Helper loaded: date_helper
INFO - 2016-10-07 15:50:54 --> Helper loaded: string_helper
INFO - 2016-10-07 15:50:54 --> Helper loaded: file_helper
INFO - 2016-10-07 15:50:54 --> Helper loaded: frontend_helper
INFO - 2016-10-07 15:50:54 --> Helper loaded: text_helper
INFO - 2016-10-07 15:50:54 --> Database Driver Class Initialized
DEBUG - 2016-10-07 15:50:54 --> Session Class Initialized
INFO - 2016-10-07 15:50:54 --> Encrypt Class Initialized
DEBUG - 2016-10-07 15:50:54 --> Session routines successfully run
INFO - 2016-10-07 15:50:54 --> Parser Class Initialized
INFO - 2016-10-07 15:50:54 --> Language file loaded: language/en/pagination_lang.php
INFO - 2016-10-07 15:50:54 --> Pagination Class Initialized
INFO - 2016-10-07 15:50:54 --> User Agent Class Initialized
INFO - 2016-10-07 15:50:54 --> Form Validation Class Initialized
INFO - 2016-10-07 15:50:54 --> Upload Class Initialized
INFO - 2016-10-07 15:50:54 --> Controller Class Initialized
INFO - 2016-10-07 15:50:54 --> Language file loaded: language/en/core_lang.php
DEBUG - 2016-10-07 15:50:54 --> Upload class already loaded. Second attempt ignored.
INFO - 2016-10-07 15:50:54 --> Image Lib Class Initialized
INFO - 2016-10-07 15:50:54 --> Model Class Initialized
INFO - 2016-10-07 15:50:54 --> Model Class Initialized
INFO - 2016-10-07 15:50:54 --> Model Class Initialized
INFO - 2016-10-07 15:50:54 --> CATEGORY :::::: 
INFO - 2016-10-07 15:50:54 --> AREA ::::: 
INFO - 2016-10-07 15:50:54 --> SOFTWARE ::::::: 
INFO - 2016-10-07 15:50:54 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\frontend/courses/search.php
INFO - 2016-10-07 15:50:54 --> Model Class Initialized
INFO - 2016-10-07 15:50:54 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\frontend/layouts/footerlang.php
INFO - 2016-10-07 15:50:54 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\frontend/courses/index.php
INFO - 2016-10-07 15:50:54 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\frontend/layouts/header.php
INFO - 2016-10-07 15:50:54 --> File loaded: D:\xampp\htdocs\dev-proyectarte\application\views\frontend/layouts/main.php
INFO - 2016-10-07 15:50:54 --> Final output sent to browser
DEBUG - 2016-10-07 15:50:54 --> Total execution time: 0.1130
