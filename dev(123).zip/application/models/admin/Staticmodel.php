<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * @package     CodeIgniter
 * @author      Ikraftsolutions
 * @copyright   Copyright (c) Ikraftsolutions (http://ikraftsolutions.com)
 * @version 1.0
 */

class Staticmodel extends CI_Model 
{

	public $limit = '7';
	public function __construct() {
		parent::__construct();
		
	}
	public function category()
	{
		$this->db->select('CATEGORY_NAME_EN,CATEGORY_NAME_SP,URL_REWRITE_EN,URL_REWRITE_SP');
		$this->db->from('category_master');
		$this->db->where("category_master.INACTIVE","1");
		$this->db->limit($this->limit);
		$query = $this->db->get();
		
		if ($query->num_rows() > 0) {
			return $query->result();
		}
	}
	public function area()
	{
		$this->db->select('AREA_NAME_EN,AREA_NAME_SP,URL_REWRITE_EN,URL_REWRITE_SP');
		$this->db->from('area_master');
		$this->db->where("area_master.INACTIVE","1");
		$this->db->limit($this->limit);
		$query = $this->db->get();
		
		if ($query->num_rows() > 0) {
			return $query->result();
		}
	}
	public function software()
	{
		$this->db->select('SOFTWARE_NAME_EN,SOFTWARE_NAME_SP,URL_REWRITE_EN,URL_REWRITE_SP');
		$this->db->from('software_master');
		$this->db->where("software_master.INACTIVE","1");
		$this->db->limit($this->limit);
		$query = $this->db->get();
		
		if ($query->num_rows() > 0) {
			return $query->result();
		}
	}
	public function news()
	{
		$this->db->select('*');
		$this->db->from('cms');
		$this->db->where('CMS_TYPE','NEWS');
		$this->db->where('INACTIVE', '1');
		$this->db->order_by('CREATED_DATE',"desc");
		$this->db->limit('1');
		
		$query = $this->db->get();
		
		if ($query->num_rows() > 0) {
			return $query->result();
		}
	}
	
	public function banner()
	{
		$this->db->select('*');
		$this->db->from('banner');
		$this->db->where('INACTIVE', '1');
		//$this->db->where('CMS_TYPE','NEWS');
		//$this->db->limit('1');
		
		$query = $this->db->get();
		
		if ($query->num_rows() > 0) {
			return $query->result();
		}
	}
	public function annoucement()
	{
		$this->db->select('*');
		$this->db->from('cms');
		$this->db->where('CMS_TYPE','ACCOUNCEMENT');
		$this->db->where('INACTIVE', '1');
		$this->db->order_by('CREATED_DATE',"desc");
		$this->db->limit('6');
	
		$query = $this->db->get();
	
		if ($query->num_rows() > 0) {
			return $query->result();
		}
	}
}

?>
