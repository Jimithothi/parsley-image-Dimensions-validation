<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * @package     CodeIgniter
 * @author      Ikraftsolutions
 * @copyright   Copyright (c) Ikraftsolutions (http://ikraftsolutions.com)
 * @version 1.0
 */

class Unitmodel extends SB_Model 
{

	public $table = 'course_unit';
	public $primaryKey = 'UNIT_ID';
	public $jointable="course_unit_information";

	function getUnits($id)
	{
	
		$this->db->select('*');
		$this->db->from($this->table);
	
		
		$this->db->where("$this->table.COURSE_ID",$id);
		$this->db->order_by("$this->table.UNIT_ID","asc");
		
		$query = $this->db->get();
		$result = $query->result();
		
		
		return $results = array('rows'=> $result);
	}
	
	function update_video($data)
	{
		$this->db->where('COURSE_ID', $this->session->userdata('COURSE_ID'));
		$this->db->update('course_master',$data);
		
	}
	
	function getTotalvideo()
	{
		$this->db->select('COURSE_TOT_VIDEO');
		$this->db->from('course_master');
		$this->db->where("course_master.COURSE_ID",$this->session->userdata('COURSE_ID'));
		$query = $this->db->get();
		return $query->row_array();
	}
	
	
	public function __construct() {
		parent::__construct();
		
	}

	public static function querySelect(  ){
		
		
		return "   SELECT course_unit.* FROM course_unit   ";
	}
	public static function queryWhere(  ){
		
		return "  WHERE course_unit.UNIT_ID IS NOT NULL   ";
	}
	
	public static function queryGroup(){
		return "   ";
	}
	
	/**
	 * when course edit after update that time this method used
	 * @param string $table
	 * @param string $key
	 * @param int $id
	 */
	
	function course_information_delete($table,$key,$id)
	{
		$this->db->where($key, $id);
		$this->db->delete($table);
	}
	
	/**
	 * when course delete that time his information also delete that time this method used
	 * @param string $table
	 * @param string $key
	 * @param int $id
	 */
	
	function course_delete($table,$key,$id)
	{
		for($i=0;$i<count($id);$i++)
		{
			$query= $this->db->query("select UNIT_ID from course_unit where COURSE_ID=$id[$i]");
	
			$result = $query->result_array();
	
			for($k=0;$k<count($result);$k++)
			{
				$sql="delete from course_unit_information where UNIT_ID=".$result[$k]['UNIT_ID'];
				$this->db->query($sql);
				$usql="delete from course_unit where UNIT_ID=".$result[$k]['UNIT_ID'];
				$this->db->query($usql);
			}
			$csql="delete from ".$table." where ".$key."=".$id[$i];
			$this->db->query($csql);
		}
	}
	
	function unsetFiles($table,$key,$id)
	{
		for($i=0;$i<count($id);$i++)
		{
			$query= $this->db->query("select UNIT_ID from ".$table." where $key=$id[$i]");
	
			$result = $query->result_array();
			
			for($k=0;$k<count($result);$k++)
			{
				$this->getInformationcontent('course_unit_information',$result[$k]['UNIT_ID']);
				
			}
		}
	}
	
	function getInformationcontent($contentTable,$id)
	{
		$query= $this->db->query("select * from ".$contentTable." where $this->primaryKey=$id AND (UNIT_INFO_CONT_TYPE='FILEUPLOAD' OR UNIT_INFO_CONT_TYPE='SOUND')");
		$result = $query->result_array();
		for($i=0;$i<count($result);$i++)
		{	
			if(file_exists('uploads/course/unit/'.$result[$i]['UNIT_INFO_CONT_VALUE']))
			{
				//echo "yes";
				unlink( FCPATH .'uploads/course/unit/'.$result[$i]['UNIT_INFO_CONT_VALUE']);
			}
		}
	}
	function getunit($id)
	{
		$this->db->select("*");
		$this->db->from($this->table);
		$this->db->where($this->table.'.'.$this->primaryKey,$id);
		$query = $this->db->get();
	
	
		return $query->result_array();
	
	}
	
	function getUnitcontent($id)
	{
		$this->db->select('*');
		$this->db->from($this->jointable);
		$this->db->where($this->jointable.'.'.$this->primaryKey,$id);
		$query = $this->db->get();
	
		return $query->result_array();
	}
	
	function GetUnitID($id)
	{
		
		$this->db->select($this->table.'.'.$this->primaryKey);
		$this->db->from($this->table);
		$this->db->where($this->table.'.COURSE_ID',$id);
		$query = $this->db->get();
		
		return $query->result_array();
	}
	
	function countVideo($id)
	{
		$this->db->select('*');
		$this->db->from($this->jointable);
		$this->db->where($this->jointable.'.'.$this->primaryKey,$id);
		$this->db->where($this->jointable.'.UNIT_INFO_CONT_TYPE','MEDIA');
		$query = $this->db->get();
		
		return $query->num_rows();
	}
	
	function updateVideo($count,$id)
	{
		$this->db->where('course_master.COURSE_ID', $id);
		$data=array('COURSE_TOT_VIDEO'=>$count);
		$this->db->update('course_master', $data);
	}
	
	
}

?>
