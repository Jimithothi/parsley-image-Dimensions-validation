<?php

/**
 * @package     CodeIgniter
 * @author      Ikraftsolutions
 * @copyright   Copyright (c) Ikraftsolutions (http://ikraftsolutions.com)
 * @version 1.0
 */

class FrontendHelpers {
	
	/**
	 * footer category display
	 * @return ArrayObject
	 */
	static function footer_category() {
		$CI = & get_instance ();
		$CI->load->model ( 'admin/staticmodel' );
	
		$category = $CI->staticmodel->category ();
	
		return $category;
	}
	
	/**
	 * footer area display
	 * @return ArrayObject
	 */
	static function footer_area() {
		$CI = & get_instance ();
		$CI->load->model ( 'admin/staticmodel' );
	
		$area = $CI->staticmodel->area ();
	
		return $area;
	}
	
	/**
	 * footer software display
	 * @return ArrayObject
	 */
	static function footer_software() {
		$CI = & get_instance ();
		$CI->load->model ( 'admin/staticmodel' );
	
		$software = $CI->staticmodel->software ();
	
		return $software;
	}
	
	/**
	 * news display
	 * @return ArrayObject
	 */
	static function news() {
		$CI = & get_instance ();
		$CI->load->model ( 'admin/staticmodel' );	
		$news = $CI->staticmodel->news ();	
		return $news;
	}
	
	/**
	 * banner display
	 * @return ArrayObject
	 */
	static function banner() {
		$CI = & get_instance ();
		$CI->load->model ('admin/staticmodel');
		$banner = $CI->staticmodel->banner ();	
		return $banner;
	}
	
	/**
	 * annoucement display
	 * @return ArrayObject
	 */
	static function annoucement() {
		$CI = & get_instance ();
		$CI->load->model ( 'admin/staticmodel' );
		$annoucement = $CI->staticmodel->annoucement ();	
		return $annoucement;
	}
	
	
}

