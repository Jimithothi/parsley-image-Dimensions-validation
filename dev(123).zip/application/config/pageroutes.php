<?php 

$route["admin"] = "admin/user/index";

$route["user/login"]="admin/user/login";

$route["help"]="page/index/help";
$route["contact-us"] = "page/index/contact-us";

$route["courses/popular"] = "courses/popular";
$route["courses/high_rated"] = "courses/high_rated";
$route["courses/recent"] = "courses/recent";
$route["courses/(:any)/review"] = "courses/view/$1";


$route["courses/category/(:any)"] = "courses/category/$1";  // category-wise course display
$route["courses/software/(:any)"] = "courses/software/$1";  // category-wise course display
$route["courses/area/(:any)"] = "courses/area/$1";

$route["courses"] = "courses";
$route["courses/enroll_course"] = "courses/enroll_course";
$route["courses/(:any)"] = "courses/view/$1";
$route["courses/postreview"] = "courses/postreview";
$route["courses/units/(:any)"] = "units/view/$1";
?>