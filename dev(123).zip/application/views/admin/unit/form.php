<div class="page-content row">
    <!-- Page header -->
<div class="page-header">
  <div class="page-title">
  <h3> <a href="<?php echo site_url('dashboard') ?>"> Dashboard</a> / 
    <a href="<?php echo site_url('unit') ?>"><?php echo $pageTitle ?></a>
    <?php //echo $pageTitle ?> <small><?php //echo $pageNote ?></small></h3>
  </div>
       
</div>
 
   <div class="page-content-wrapper m-t">  
   <ul class="nav nav-tabs" style="margin-bottom:10px;">
			<li><a href="<?php echo base_url()?>course/add/<?php echo $this->session->userdata('COURSE_ID')?>"><?php echo "Course Info"; ?> </a></li>
			<li class="active" ><a href="<?php echo base_url()?>unit/index/<?php echo $row['COURSE_ID']?>"><?php echo "Unit"; ?> </a></li>
					<li><a
				href="<?php echo base_url()?>admin/comment/index/<?php echo $this->session->userdata('COURSE_ID')?>"><?php echo "Comments"; ?> </a></li>
		
			
				</ul>    
    <div class="sbox" >
    <div class="sbox-title" >
      <h5><?php echo $addForm;?><?php //echo $pageTitle ?> <small><?php //echo $pageNote ?></small></h5>
    </div>
    <div class="sbox-content" >

      
     <form action="<?php echo site_url('unit/save/'.$row['UNIT_ID']); ?>" class='form-horizontal'  data-parsley-validate='true' method="post" enctype="multipart/form-data" > 
<input type="hidden" value="0" id='hidden'> <p></p>

<div class="col-md-11">
						<fieldset>
									
								  <div class="form-group hidethis " style="display:none;">
									<label for="UNIT ID" class=" control-label col-md-4 text-left"> UNIT ID </label>
									<div class="col-md-8">
									  <input type='text' class='form-control' placeholder='' value='<?php echo $row['UNIT_ID'];?>' name='UNIT_ID'   /> <br />
									  <i> <small></small></i>
									 </div> 
								  </div> 					
								 <?php if($this->session->userdata('COURSE_ID')!=''){ ?>				
								  <div class="form-group  " >
									<div class="col-md-8">
									  <input type='hidden' class='form-control' placeholder='' value='<?php echo $this->session->userdata('COURSE_ID');?>' name='COURSE_ID'   /> <br />
									  <i> <small></small></i>
									 </div> 
								  </div> 
								  <div class="form-group  " >
									<label for="Course Name" class=" control-label col-md-4 text-left"> Course Name </label>
									<div class="col-md-8">
									  <input type='text' class='form-control' placeholder='' value='<?php echo $this->session->userdata('COURSE_NAME');?>' name='COURSE_NAME'  disabled  /> <br />
									  <i> <small></small></i>
									 </div> 
								  </div>
								  
								  <?php }
								  else{
								 	 redirect('course/index');
								  }?>					
								  <div class="form-group  " >
									<label for="Uint Name" class=" control-label col-md-4 text-left"> Unit Name <span class="asterix" style="color: red;"> * </span></label>
									<div class="col-md-8">
									  <input type='text' class='form-control' placeholder='' value='<?php echo $row['UNIT_NAME'];?>' name='UNIT_NAME'  required /> <br />
									  <i> <small></small></i>
									 </div> 
								  </div> 
								  
								   <div class="form-group">
									<label class="col-sm-4 text-right"> </label>
									<div class="col-sm-8">	
										
										<a id="texteditor" class="btn btn-primary">Text</a>
										<a id="fileuplaod" class="btn btn-primary">Image / File Upload</a>
										<a id="media" class="btn btn-primary">Media</a>	
										<a id="textbox" class="btn btn-primary">Textbox</a>	
										<a id="soundupload" class="btn btn-primary">Audio</a>	
										
									</div>
								  </div>
								   <div id="myForm">
								   
								      <?php if($row['UNIT_ID']!=""){
								      	
								      	//print_r($COURSE_CONTENT);
								      	
								      	
								      	
								      for ($i=0;$i<count($COURSE_CONTENT);$i++)
								      {
								      	if($COURSE_CONTENT[$i]['UNIT_INFO_CONT_TYPE']=='TEXT')
								      	{
								      		?><?php  
								      		/**
								      		 * 
								      		 * @var Ambiguous $in
								      		 */
								      		//$in=strip_tags($content_material[$i]['COURSE_INFO_CONT_VALUE']);
								      		//echo mb_strimwidth($in, 0, 10, "");
								      		
								      		
								      		?>
								      		<div class="div<?=$i?>" id="InputsWrapper_<?=$i?>">
								      		<div class="form-group  " >'
								      		<a id="<?=$i?>" class="removeclass0" ><span><i class="fa fa-trash-o fa-lg"></i></span></a>
								      		<a id="<?=$i?>" class="upclass"><span><i class="fa fa-arrow-up"></i></span></a>
								      		<a id="<?=$i?>" class="downclass"><span><i class="fa fa-arrow-down"></i></span></a>
								      				<label for="Course Name" class=" control-label col-md-4 text-left"> Editor <span class="asterix"> * </span></label>
								      				<div class="col-md-8">
								      						<textarea name="COURSE_CONTENT[]" rows="5" id="editor_<?=$i?>" class="form-control markItUp "><?php echo $COURSE_CONTENT[$i]['UNIT_INFO_CONT_VALUE']?></textarea><br>
								      								<i> <small></small></i>
								      				</div> <input type="hidden" name="type[]" value="TEXT" id="field_type'<?=$i?>">
								      		</div>
								      		</div> 
								      		<script type="text/javascript">
	area1 =  new MooEditable("editor_<?=$i?>",{
		actions: 'bold italic underline insertorderedlist insertunorderedlist'
	});
</script>
								      														<?php 
								      														
								      	}
								      	elseif ($COURSE_CONTENT[$i]['UNIT_INFO_CONT_TYPE']=='MEDIA')
								      	{
								      	?>
								      		<div class="div<?=$i?>" id="InputsWrapper_<?=$i?>">
								      		<div class="form-group  " >'
								      		<a id="<?=$i?>" class="removeclass0" ><span><i class="fa fa-trash-o fa-lg"></i></span></a>
								      		<a id="<?=$i?>" class="upclass"><span><i class="fa fa-arrow-up"></i></span></a>
								      		<a id="<?=$i?>" class="downclass"><span><i class="fa fa-arrow-down"></i></span></a>
								      				<label for="Course Name" class=" control-label col-md-4 text-left"> Media <span class="asterix"> * </span></label>
								      				<div class="col-md-8">
								      				
								      				<input class="form-control" type="text" name="COURSE_CONTENT[]" id="media_<?=$i?>" placeholder="http://" value="<?php echo $COURSE_CONTENT[$i]['UNIT_INFO_CONT_VALUE']?>" data-parsley-pattern="/^((http[s]?|ftp):)\/\/([a-z0-9_\.-]+)\.([\da-z\.-]+)\.([a-z\.]{2,6})\/(medias)\/([A-Za-z0-9_\.-]{10})/" required/><br>
								      				
								      							<i> <small></small></i>
								      				</div> <input type="hidden" name="type[]" value="MEDIA" id="field_type'<?=$i?>">
								      		</div>
								      		</div> 
								      	
								      	<?php 
								      	}elseif ($COURSE_CONTENT[$i]['UNIT_INFO_CONT_TYPE']=='TEXTBOX')
								      	{
								      	?>
								      		<div class="div<?=$i?>" id="InputsWrapper_<?=$i?>">
								      		<div class="form-group  " >'
								      		<a id="<?=$i?>" class="removeclass0" ><span><i class="fa fa-trash-o fa-lg"></i></span></a>
								      		<a id="<?=$i?>" class="upclass"><span><i class="fa fa-arrow-up"></i></span></a>
								      		<a id="<?=$i?>" class="downclass"><span><i class="fa fa-arrow-down"></i></span></a>
								      				<label for="Course Name" class=" control-label col-md-4 text-left"> Textbox <span class="asterix"> * </span></label>
								      				<div class="col-md-8">
								      				
								      				
								      				<table>
								      				
								      				<tr>
								      				<td width="80%">
								      				<input class="form-control" type="text" name="COURSE_CONTENT[]" id="textbox_<?=$i?>"  value="<?php echo $COURSE_CONTENT[$i]['UNIT_INFO_CONT_VALUE']?>" required/><br>
								      				
								      				</td>
								      				<td width="5%"></td>
								      				
								      				<td width="15%">
								      				<?php if($COURSE_CONTENT[$i]['IS_SUBUNIT']==1){?>
								      				<input type="checkbox" name="assign[]"  id="check_<?php echo $i?>" class="checkboxValue" checked="checked"/>
								      				<input type="hidden" name="checkboxValue[]" value="1" id="link_check_<?php echo $i?>" >
								      				
								      				<?php }
								      				else{?>
								      				<input type="checkbox" name="assign[]"  id="check_<?php echo $i?>" class="checkboxValue" />
								      				<input type="hidden" name="checkboxValue[]" value="0" id="link_check_<?php echo $i?>" >
								      				
								      				<?php }?>
								      				
								      				</td>
								      				</tr>
								      				</table>
								      				
								      				
								      				
								      				
								      				
								      				
								      							<i> <small></small></i>
								      				</div> <input type="hidden" name="type[]" value="TEXTBOX" id="field_type'<?=$i?>">
								      		</div>
								      		</div> 
								      	
								      	<?php 
								      	}elseif ($COURSE_CONTENT[$i]['UNIT_INFO_CONT_TYPE']=='FILEUPLOAD'){
								      		
								      		?>
								      		
								      		<div class="div<?=$i?>" id="InputsWrapper_<?=$i?>">
								      		<div class="form-group  " >'
								      		<a id="<?=$i?>" class="removeclass0" ><span><i class="fa fa-trash-o fa-lg"></i></span></a>
								      		<a id="<?=$i?>" class="upclass"><span><i class="fa fa-arrow-up"></i></span></a>
								      		<a id="<?=$i?>" class="downclass"><span><i class="fa fa-arrow-down"></i></span></a>
								      				<label for="Course Name" class=" control-label col-md-4 text-left"> File <span class="asterix"> * </span></label>
								      				<div class="col-md-8">
								      				<input type="hidden" value="<?php echo $COURSE_CONTENT[$i]['UNIT_INFO_CONT_VALUE']?>" name="COURSE_CONTENT_IMAGE[]">
								      				<input <?php if($COURSE_CONTENT[$i]['UNIT_INFO_CONT_VALUE'] =='') echo 'class="required"' ;?> type="file" name="COURSE_CONTENT[]" id="file_<?=$i?>" placeholder="http://"/><br>
								      				<?php echo SiteHelpers::CourseshowUploadedFile($COURSE_CONTENT[$i]['UNIT_INFO_CONT_VALUE'],'/uploads/course/unit/') ;?>
								      							<i> <small></small></i>
								      				</div> <input type="hidden" name="type[]" value="FILEUPLOAD" id="field_type'<?=$i?>">
								      		</div>
								      		</div> 
								      		
								      		  	<?php 
								      	}elseif ($COURSE_CONTENT[$i]['UNIT_INFO_CONT_TYPE']=='SOUND'){
								      		
								      		?>
								      		
								      		<div class="div<?=$i?>" id="InputsWrapper_<?=$i?>">
								      		<div class="form-group  " >'
								      		<a id="<?=$i?>" class="removeclass0" ><span><i class="fa fa-trash-o fa-lg"></i></span></a>
								      		<a id="<?=$i?>" class="upclass"><span><i class="fa fa-arrow-up"></i></span></a>
								      		<a id="<?=$i?>" class="downclass"><span><i class="fa fa-arrow-down"></i></span></a>
								      				<label for="Course Name" class=" control-label col-md-4 text-left"> Sound <span class="asterix"> * </span></label>
								      				<div class="col-md-8">
								      				<input type="hidden" value="<?php echo $COURSE_CONTENT[$i]['UNIT_INFO_CONT_VALUE']?>" name="COURSE_CONTENT_IMAGE[]">
								      				<input <?php if($COURSE_CONTENT[$i]['UNIT_INFO_CONT_VALUE'] =='') echo 'class="required"' ;?> type="file" name="COURSE_CONTENT[]" id="sound_<?=$i?>"/><br>
								      				
								      							<i> <small></small></i>
								      				</div> <input type="hidden" name="type[]" value="SOUND" id="field_type'<?=$i?>">
								      		</div>
								      		</div> 
								      		
								      		<?php 
								      	}
								      	
								      	else {
								      	}
								      	
								      	?>
								      	  <script type="text/javascript">
										
								      	document.getElementById("hidden").value = <?php echo $i?>+1;

								      	</script>
								      	  
								      	<?php 								    
								      }
								      	?>					
								 	<?php
								 } ?>  
								   </div>
								  </fieldset>
			</div>
			
			
    
      <div style="clear:both"></div>  
        
     <div class="toolbar-line text-center">    
      <?php if($row['UNIT_ID']!=""){?>					
								    <input type="submit" name="Update" class="btn btn-primary btn-sm" value="Update" />
     
								 <?php }else{?>
								  <input type="submit" name="Save" class="btn btn-info btn-sm" value="Save" />
      							<input type="submit" name="SaveandAnother" class="btn btn-info btn-sm" value="Save & Another" />
								 
								 	<?php
								 } ?>   
      <a href="<?php echo site_url('course');?>" class="btn btn-sm btn-warning"><?php echo $this->lang->line('core.btn_cancel'); ?> </a>
   </div>
            
    </form>
    
    </div>
    </div>

  </div>  
</div>  

<script>
$(document).ready(function() {
    window.Parsley
        .addValidator('fileextension', function (value, requirement) {
        		var tagslistarr = requirement.split(',');
            var fileExtension = value.split('.').pop();
						var arr=[];
						$.each(tagslistarr,function(i,val){
   						 arr.push(val);
						});
            if(jQuery.inArray(fileExtension, arr)!='-1') {
           
              return true;
            } else {
             
              return false;
            }
        }, 32)
        .addMessage('en', 'fileextension', 'This Type File Not allow. ');

    $("#validationForm").parsley();

});
</script>
       
  