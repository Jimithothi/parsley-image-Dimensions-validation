<!DOCTYPE html>
<html lang="en">
<head>
<title>Proyectarte | Courses</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<!-- LIBRARY FONT-->
<!-- <link type="text/css" rel="stylesheet"
	href="https://fonts.googleapis.com/css?family=Lato:400,400italic,700,900,300">   -->
<link type="text/css" rel="stylesheet"
	href="<?php echo base_url();?>assets/frontend/font/font-icon/font-awesome-4.4.0/css/font-awesome.css">
<link type="text/css" rel="stylesheet"
	href="<?php echo base_url();?>assets/frontend/font/font-icon/font-svg/css/Glyphter.css">
<!-- LIBRARY CSS-->
<link type="text/css" rel="stylesheet"
	href="<?php echo base_url();?>assets/frontend/libs/animate/animate.css">
<link type="text/css" rel="stylesheet"
	href="<?php echo base_url();?>assets/frontend/libs/bootstrap-3.3.5/css/bootstrap.css">
<link type="text/css" rel="stylesheet"
	href="<?php echo base_url();?>assets/frontend/libs/owl-carousel-2.0/assets/owl.carousel.css">
<link type="text/css" rel="stylesheet"
	href="<?php echo base_url();?>assets/frontend/libs/selectbox/css/jquery.selectbox.css">
<link type="text/css" rel="stylesheet"
	href="<?php echo base_url();?>assets/frontend/libs/fancybox/css/jquery.fancybox.css">
<link type="text/css" rel="stylesheet"
	href="<?php echo base_url();?>assets/frontend/libs/fancybox/css/jquery.fancybox-buttons.css">
<link type="text/css" rel="stylesheet"
	href="<?php echo base_url();?>assets/frontend/libs/media-element/build/mediaelementplayer.min.css">
<!-- STYLE CSS    -->
<link type="text/css" rel="stylesheet" href="<?php echo base_url();?>assets/frontend/css/color-1.css"
	id="color-skins">
<!--link(type="text/css", rel='stylesheet', href='#', id="color-skins")-->
<script src="<?php echo base_url();?>assets/frontend/libs/jquery/jquery-2.1.4.min.js"></script>
<script src="<?php echo base_url();?>assets/frontend/libs/js-cookie/js.cookie.js"></script>

	<script src="<?php echo base_url();?>assets/frontend/libs/bootstrap-3.3.5/js/bootstrap.min.js"></script>
	<script src="<?php echo base_url();?>assets/frontend/libs/smooth-scroll/jquery-smoothscroll.js"></script>
	<script src="<?php echo base_url();?>assets/frontend/libs/owl-carousel-2.0/owl.carousel.min.js"></script>
	<script src="<?php echo base_url();?>assets/frontend/libs/appear/jquery.appear.js"></script>
	<script src="<?php echo base_url();?>assets/frontend/libs/count-to/jquery.countTo.js"></script>
	<script src="<?php echo base_url();?>assets/frontend/libs/wow-js/wow.min.js"></script>
	<script src="<?php echo base_url();?>assets/frontend/libs/selectbox/js/jquery.selectbox-0.2.min.js"></script>
	<script src="<?php echo base_url();?>assets/frontend/libs/fancybox/js/jquery.fancybox.js"></script>
	<script src="<?php echo base_url();?>assets/frontend/libs/fancybox/js/jquery.fancybox-buttons.js"></script>
	<script src="<?php echo base_url();?>assets/admin/js/plugins/parsley.js"></script>
<script src="<?php echo base_url();?>assets/admin/js/plugins/parsley_2.4.js"></script>
	<!-- MAIN JS-->
	<script src="<?php echo base_url();?>assets/frontend/js/main.js"></script>
	<!-- LOADING SCRIPTS FOR PAGE
	<script src="assets/js/pages/courses.js"></script>-->
	
	
	<script src="<?php echo base_url();?>assets/frontend/libs/isotope/isotope.pkgd.min.js"></script>
	<script src="<?php echo base_url();?>assets/frontend/libs/isotope/fit-columns.js"></script>
	<script src="<?php echo base_url();?>assets/frontend/js/pages/homepage.js"></script>

<!--
<script charset="ISO-8859-1" src="//fast.wistia.com/assets/external/E-v1.js" async></script>

<script src="//fast.wistia.com/assets/external/E-v1.js" async></script>

<!--
<!--script.-->
<!--    if ((Cookies.get('color-skin') != undefined) && (Cookies.get('color-skin') != 'color-1')) {-->
<!--        $('#color-skins').attr('href', 'assets/css/' + Cookies.get('color-skin') + '.css');-->
<!--    } else if ((Cookies.get('color-skin') == undefined) || (Cookies.get('color-skin') == 'color-1')) {-->
<!--        $('#color-skins').attr('href', 'assets/css/color-1.css');-->
<!--    }-->
</head>


<body  id="solo">
	<!-- HEADER-->
				
					<!-- new event -->
					
							<div class="modal-dialog">

				<!-- Modal content-->
				<div class="modal-content">
				<div class="alert alert-success" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
  <strong></strong><i class="fa fa-thumbs-o-up"></i> You will receive an email with instructions about how to confirm your account in a few minutes.
</div>
					<div class="modal-body">
						<p class="text-center">
							<a href="index.html"><img
								src="<?php echo base_url();?>assets/frontend/images/logo-color-1.png" alt="" class="login"></a>
						</p>
						<br>
					<h2>Great! Look in your email.</h2>
						<div class="row">
						<div class="col-md-12" style="margin-top: 10px">
						<p>You will receive an email with instructions about how to confirm your account in a few minutes.</p>
<p>If you do not receive our mails check they are not being redirected to the "spam" folder.</p>
<p>
Sometimes, the email it takes a few minutes to arrive.
</p>
							</div>
						</div>
						
						
					</div>
					<div class="modal-footer">
						<p class="text-center">
							<label class="control-label form-label">Problems? Contact
								us at <a href='mailto:<?php echo CONTACT_MAIL?> '><?php echo CONTACT_MAIL?> </a></label>
						</p>
					</div>
				</div>
			</div>
		

	<div class="body-2 loading">
		<div class="dots-loader"></div>
	</div>
</body>
</html>
