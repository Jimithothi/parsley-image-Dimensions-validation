<div id="wrapper-content">
		<!-- PAGE WRAPPER-->
		<div id="page-wrapper">
			<!-- MAIN CONTENT-->
			<div class="main-content">
				<!-- CONTENT-->
				<div class="content">
					<div class="section background-opacity page-title set-height-top">
						<div class="container">
							<div class="page-title-wrapper">
								<h2 class="captions">FAQ</h2>
								
							</div>
						</div>
					</div>
					
					<!-- FREQUENTLY ASKED QUESTIONS-->
					<div class="section section-padding">
						<div class="container">
							<div class="group-title-index">
								<h4 class="top-title">Answer all of your questions</h4>

								<h2 class="center-title">FREQUENTLY ASKED QUESTIONS</h2>

								<div class="bottom-title">
									<i class="bottom-icon icon-icon-05"></i>
								</div>
							</div>
							<div class="accordion-faq">
								<div class="row">
									<div class="col-md-12">
										<div class="underline">Making Courses</div>
										<div id="accordion-2" class="panel-group accordion">
											<div class="panel">
												<div class="panel-heading">
													<h5 class="panel-title">
														<a data-toggle="collapse" data-parent="#accordion-2"
															href="#collapse-2-1" aria-expanded="false"
															class="accordion-toggle collapsed">1. What is
															Proyectarte?</a>
													</h5>
												</div>
												<div id="collapse-2-1" aria-expanded="false"
													style="height: 0px;" class="panel-collapse collapse">
													<div class="panel-body">Proyectarte is the largest
														creative community in Spanish. In Proyectarte thousands of
														creative professionals with different network profiles
														interact and share their work and knowledge. Proyectarte, is
														also a benchmark for the sector and has a specialized
														audience that extends beyond its own site.</div>
												</div>
											</div>
											<div class="panel active">
												<div class="panel-heading">
													<h5 class="panel-title">
														<a data-toggle="collapse" data-parent="#accordion-2"
															href="#collapse-2-2" aria-expanded="true"
															class="accordion-toggle">2. Why won't my lectures
															download to my mobile device?</a>
													</h5>
												</div>
												<div id="collapse-2-2" style="" aria-expanded="true"
													class="panel-collapse collapse in">
													<div class="panel-body">Lorem ipsum dolor sit amet,
														consectetur adipiscing elit. Aenean eu tellus ipsum. Nunc
														maximus sapien ac dui vulputate tincidunt. Morbi luctus
														nisi vel suscipit volutpat. Donec vitae auctor nisl. Ut
														malesuada felis in erat rutrum ultrices. Fusce iaculis
														ornare nunc rutrum ornare.</div>
												</div>
											</div>
											<div class="panel">
												<div class="panel-heading">
													<h5 class="panel-title">
														<a data-toggle="collapse" data-parent="#accordion-2"
															href="#collapse-2-3" aria-expanded="false"
															class="accordion-toggle collapsed">3. How do I
															disable push notifications?</a>
													</h5>
												</div>
												<div id="collapse-2-3" style="height: 0px;"
													aria-expanded="false" class="panel-collapse collapse">
													<div class="panel-body">Nemo enim ipsam voluptatem
														quia voluptas sit aspernatur aut odit aut fugit, sed quia
														consequuntur magni dolores eos qui ratione voluptatem
														sequi nesciunt.</div>
												</div>
											</div>
											<div class="panel">
												<div class="panel-heading">
													<h5 class="panel-title">
														<a data-toggle="collapse" data-parent="#accordion-2"
															href="#collapse-2-4" aria-expanded="true"
															class="accordion-toggle collapsed">4. How do I opt
															out of instructor e-mails?</a>
													</h5>
												</div>
												<div id="collapse-2-4" style="" aria-expanded="true"
													class="panel-collapse collapse">
													<div class="panel-body">Lorem ipsum dolor sit amet,
														consectetur adipiscing elit. Aenean eu tellus ipsum. Nunc
														maximus sapien ac dui vulputate tincidunt. Morbi luctus
														nisi vel suscipit volutpat. Donec vitae auctor nisl. Ut
														malesuada felis in erat rutrum ultrices. Fusce iaculis
														ornare nunc rutrum ornare.</div>
												</div>
											</div>
											<div class="panel">
												<div class="panel-heading">
													<h5 class="panel-title">
														<a data-toggle="collapse" data-parent="#accordion-2"
															href="#collapse-2-5" aria-expanded="false"
															class="accordion-toggle collapsed">5. What is the
															course URL?</a>
													</h5>
												</div>
												<div id="collapse-2-5" style="height: 0px;"
													aria-expanded="false" class="panel-collapse collapse">
													<div class="panel-body">Nemo enim ipsam voluptatem
														quia voluptas sit aspernatur aut odit aut fugit, sed quia
														consequuntur magni dolores eos qui ratione voluptatem
														sequi nesciunt.</div>
												</div>
											</div>
											<div class="panel">
												<div class="panel-heading">
													<h5 class="panel-title">
														<a data-toggle="collapse" data-parent="#accordion-2"
															href="#collapse-2-6" aria-expanded="false"
															class="accordion-toggle collapsed">6. What are the
															online courses Proyectarte?</a>
													</h5>
												</div>
												<div id="collapse-2-6" style="height: 0px;"
													aria-expanded="false" class="panel-collapse collapse">
													<div class="panel-body">Proyectarte courses are online
														classes that allow you to learn a set of tools and develop
														skills for a particular project. Each step of the course
														combines video and text with supplementary teaching
														materials that conclude with the creation of the project.

														Each course gives you the opportunity to share your own
														projects with thousands of creative people who are part of
														the Proyectarte community. Courses are taught by working
														professionals from different disciplines (design,
														illustration, photography, computer graphics, music,
														pattern, etc.) and allow you to see first hand the methods
														and practices they use on real projects. During the
														courses you can interact with teachers to exchange ideas
														and ask for advice.</div>
												</div>
											</div>
											<div class="panel">
												<div class="panel-heading">
													<h5 class="panel-title">
														<a data-toggle="collapse" data-parent="#accordion-2"
															href="#collapse-2-7" aria-expanded="false"
															class="accordion-toggle collapsed">7. For whom are
															the courses?</a>
													</h5>
												</div>
												<div id="collapse-2-7" style="height: 0px;"
													aria-expanded="false" class="panel-collapse collapse">
													<div class="panel-body">The courses are for those who
														are looking to discover new tricks and hand tools of a
														professional. For those who want to learn a completely new
														or for those who want to take the next step in their
														skills matter. Each of the courses is classified within a
														given level, and knowing the requirements and
														prerequisites for each knowledge required. So if you're a
														novice photography or an expert of calligraphy, we have a
														course for you.</div>
												</div>
											</div>
											<div class="panel">
												<div class="panel-heading">
													<h5 class="panel-title">
														<a data-toggle="collapse" data-parent="#accordion-2"
															href="#collapse-2-8" aria-expanded="false"
															class="accordion-toggle collapsed">8. What will I
															learn with the online courses?</a>
													</h5>
												</div>
												<div id="collapse-2-8" style="height: 0px;"
													aria-expanded="false" class="panel-collapse collapse">
													<div class="panel-body">Proyectarte courses will help
														you improve your professional skills with the techniques
														and tricks that teachers will show in each video. You'll
														get new tools to raise the result of all your work or to
														offer quality solutions to your customers. In addition,
														you will make a project during the course that you can add
														to your portfolio of Proyectarte to share with the entire
														community.</div>
												</div>
											</div>
											<div class="panel">
												<div class="panel-heading">
													<h5 class="panel-title">
														<a data-toggle="collapse" data-parent="#accordion-2"
															href="#collapse-2-9" aria-expanded="false"
															class="accordion-toggle collapsed">9. What materials
															do I need to learn my course?</a>
													</h5>
												</div>
												<div id="collapse-2-9" style="height: 0px;"
													aria-expanded="false" class="panel-collapse collapse">
													<div class="panel-body">Basically, a device where to
														display the courses (computer, mobile, tablet), an
														Internet connection and specific tools for the project of
														each course. In some cases you will need a brush and
														watercolors, in other vector program design or photo
														retouching. Each teacher will specify in detail the
														materials needed for the course, and proposing
														alternatives whenever possible.</div>
												</div>
											</div>
											<div class="panel">
												<div class="panel-heading">
													<h5 class="panel-title">
														<a data-toggle="collapse" data-parent="#accordion-2"
															href="#collapse-2-10" aria-expanded="false"
															class="accordion-toggle collapsed">10. Are there any
															geographical limitations to access the course content?</a>
													</h5>
												</div>
												<div id="collapse-2-10" style="height: 0px;"
													aria-expanded="false" class="panel-collapse collapse">
													<div class="panel-body">You can access all courses
														Proyectarte from any country. There is no geographical
														limitation because the conditions are proper content
														distribution.</div>
												</div>
											</div>
											<div class="panel">
												<div class="panel-heading">
													<h5 class="panel-title">
														<a data-toggle="collapse" data-parent="#accordion-2"
															href="#collapse-2-11" aria-expanded="false"
															class="accordion-toggle collapsed">11. Is there any
															certificate is delivered after the course?</a>
													</h5>
												</div>
												<div id="collapse-2-11" style="height: 0px;"
													aria-expanded="false" class="panel-collapse collapse">
													<div class="panel-body">Upon completion of the course
														is not given any official title. Although you can always
														include experience in Complementary Training section of
														your resume and your LinkedIn profile. Also, once you
														upload your final course project Proyectarte your portfolio
														will have a permanent URL to share the work whenever you
														want to.</div>
												</div>
											</div>
											<div class="panel">
												<div class="panel-heading">
													<h5 class="panel-title">
														<a data-toggle="collapse" data-parent="#accordion-2"
															href="#collapse-2-12" aria-expanded="false"
															class="accordion-toggle collapsed">12. What topics
															are the courses?</a>
													</h5>
												</div>
												<div id="collapse-2-12" style="height: 0px;"
													aria-expanded="false" class="panel-collapse collapse">
													<div class="panel-body">In Proyectarte you will find a
														wide variety of courses that include: design, programming,
														animation, typography, photography, textile design,
														advertising, video, digital and TV, space, 3D, print
														production, product design, film, music and audio books
														and multimedia. we are always open to suggestions for
														expanding the variety of courses .</div>
												</div>
											</div>
											<div class="panel">
												<div class="panel-heading">
													<h5 class="panel-title">
														<a data-toggle="collapse" data-parent="#accordion-2"
															href="#collapse-2-13" aria-expanded="false"
															class="accordion-toggle collapsed">13. What language
															are the courses?</a>
													</h5>
												</div>
												<div id="collapse-2-13" style="height: 0px;"
													aria-expanded="false" class="panel-collapse collapse">
													<div class="panel-body">By the time the courses are
														available in Spanish and English.</div>
												</div>
											</div>
											<div class="panel">
												<div class="panel-heading">
													<h5 class="panel-title">
														<a data-toggle="collapse" data-parent="#accordion-2"
															href="#collapse-2-14" aria-expanded="false"
															class="accordion-toggle collapsed">14. When they
															start and when the courses end?</a>
													</h5>
												</div>
												<div id="collapse-2-14" style="height: 0px;"
													aria-expanded="false" class="panel-collapse collapse">
													<div class="panel-body">The modality of the course is
														100% online , so once they are published, courses start
														and finish when you want. You set the pace of the class.
														You can go back to see what interests you, and spend what
														you know, ask questions, answer questions, share your
														projects and more.</div>
												</div>
											</div>
											<div class="panel">
												<div class="panel-heading">
													<h5 class="panel-title">
														<a data-toggle="collapse" data-parent="#accordion-2"
															href="#collapse-2-15" aria-expanded="false"
															class="accordion-toggle collapsed">15. How long are
															the courses?</a>
													</h5>
												</div>
												<div id="collapse-2-15" style="height: 0px;"
													aria-expanded="false" class="panel-collapse collapse">
													<div class="panel-body">The courses have an average
														duration of 45 minutes video lessons. The content thereof
														can see how many times the wish and pace that best fits
														you. In addition, courses not only end when you just saw
														the videos, but continue as long as you want through
														creating your project, resources and attachments that
														teachers provide you, and especially to participate in the
														Forums course and Proyectarte Community .</div>
												</div>
											</div>

										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<!-- CONTACT-->

				</div>
			</div>
		</div>
		<!-- BUTTON BACK TO TOP-->
		<div id="back-top">
			<a href="#top"><i class="fa fa-angle-double-up"></i></a>
		</div>
	</div>
	<!-- FOOTER-->
	<?php $this->load->view('frontend/layouts/footerlang');?> <!-- footer view Load -->