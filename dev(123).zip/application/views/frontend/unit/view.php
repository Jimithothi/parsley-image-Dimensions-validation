	
	<div id="wrapper-content">
		<!-- PAGE WRAPPER-->
		<div id="page-wrapper">
			<!-- MAIN CONTENT-->
			<div class="main-content">
				<!-- CONTENT-->
				<div class="content">
					<div class="section background-opacity page-title set-height-top">
						<div class="container">
							<div class="page-title-wrapper">
								<!--.page-title-content-->
								<h2 class="captions">unit detail</h2>
							</div>
						</div>
					</div>
					
					
					<?php $this->load->view('frontend/courses/search');?> 
					
					
					<div class="section section-padding courses-detail">
						<div class="container">
							<div class="courses-detail-wrapper">
								<div class="row">
									<div class="col-md-9 layout-left">
										<h1 class="course-title"><?php echo $row[0]['UNIT_NAME']?></h1>
<br><Br>
										
									
									</div>
									<div class="col-md-9 layout-left">
										<div class="tab-content courses-content">
										
											<div id="campus" role="tabpanel"
											class="tab-pane fade in active">
											<div class="news-comment-title underline">Information & Syllabus</div>
													
												<div class="course-des">
										
										 <div class="course-des-content">
                                      </div>
										
											<div class="course-des-title underline">Courses Info</div>
											<div class="course-des-content">
											
											<?php for ($i=0;$i<count($courseContent);$i++){
											
												if($courseContent[$i]['UNIT_INFO_CONT_TYPE']=='TEXT')
												{
													
													echo $courseContent[$i]['UNIT_INFO_CONT_VALUE'] ."<br><Br>";
													
												}
												elseif ($courseContent[$i]['UNIT_INFO_CONT_TYPE']=='MEDIA')
												{?>
												
												<?php preg_match('/https?:\/\/(.+)?(wistia\.com|wi\.st)\/(medias|embed)\/(.+)?/', $courseContent[$i]['UNIT_INFO_CONT_VALUE'], $matches);
			?>
												<div class="wistia_responsive_padding" style="padding:56.25% 0 0px 0;position:relative;">
	<div class="wistia_responsive_wrapper" style="height:100%;left:0;position:absolute;top:0;width:100%;">
		<iframe src="//fast.wistia.net/embed/iframe/<?php echo $matches[4]?>?videoFoam=true" allowtransparency="true" frameborder="0" scrolling="no" class="wistia_embed" name="wistia_embed" allowfullscreen mozallowfullscreen webkitallowfullscreen oallowfullscreen msallowfullscreen width="100%" height="100%"></iframe>
	</div>
</div><br><br> 
												<?php 
												}
												else 
												{?>
													<img src="<?php echo base_url()?>uploads/course/unit/<?php echo $courseContent[$i]['UNIT_INFO_CONT_VALUE']?>" alt=""
														class="img-responsive" /><br><br><?php 
												}
											}?>
												
											</div>
											
										</div>
											
											
											</div>
											
											<!-- <div id="education" role="tabpanel" class="tab-pane fade">
											
											  <div class="news-comment">
                                            <div class="news-comment-title underline">FeedBack & Comments</div>
                                            <ul class="comment-list list-unstyled">
                                                <li class="media">
                                                    <div class="list-item">
                                                        <div class="media-left"><a href="#" class="media-image"><img src="assets/images/people-avatar-7.png" alt=""/></a></div>
                                                        <div class="media-body">
                                                            <div class="pull-left">
                                                                <div class="info">
                                                                    <div class="reader item"><a href="#">Charlotte</a></div>
                                                                </div>
                                                            </div>
                                                            <div class="pull-right">
                                                                <div class="reply-comment reply-1">REPLY</div>
                                                            </div>
                                                            <div class="clearfix"></div>
                                                            <div class="time">March 23, 2017 at 7:59 pm</div>
                                                            <div class="des"><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam viverra euismod odio, gravida pellentesque urna varius vitae. Sed dui lorem, adipiscing in adipiscing et, interdum nec metus. Lorem ipsum dolor sit amet, consectetur adipiscing elit Nam viverra euismod odio, gravida pellentesque urna varius vitae.</p></div>
                                                        </div>
                                                    </div>
                                                    
                                                </li>
                                                <li class="media">
                                                    <div class="list-item">
                                                        <div class="media-left"><a href="#" class="media-image"><img src="assets/images/people-avatar-7.png" alt=""/></a></div>
                                                        <div class="media-body">
                                                            <div class="pull-left">
                                                                <div class="info">
                                                                    <div class="reader item"><a href="#">Daisy</a></div>
                                                                </div>
                                                            </div>
                                                            <div class="pull-right">
                                                                <div class="reply-comment reply-2">REPLY</div>
                                                            </div>
                                                            <div class="clearfix"></div>
                                                            <div class="time">March 23, 2017 at 7:59 pm</div>
                                                            <div class="des"><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam viverra euismod odio, gravida pellentesque urna varius vitae. Sed dui lorem, adipiscing in adipiscing et, interdum nec metus. Lorem ipsum dolor sit amet, consectetur adipiscing elit Nam viverra euismod odio, gravida pellentesque urna varius vitae.</p></div>
                                                        </div>
                                                    </div>
                                                    
                                                </li>
                                                <li class="media">
                                                    <div class="list-item">
                                                        <div class="media-left"><a href="#" class="media-image"><img src="assets/images/people-avatar-7.png" alt=""/></a></div>
                                                        <div class="media-body">
                                                            <div class="pull-left">
                                                                <div class="info">
                                                                    <div class="reader item"><a href="#">Charlotte</a></div>
                                                                </div>
                                                            </div>
                                                            <div class="pull-right">
                                                                <div class="reply-comment reply-3">REPLY</div>
                                                            </div>
                                                            <div class="clearfix"></div>
                                                            <div class="time">March 23, 2017 at 7:59 pm</div>
                                                            <div class="des"><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam viverra euismod odio, gravida pellentesque urna varius vitae. Sed dui lorem, adipiscing in adipiscing et, interdum nec metus. Lorem ipsum dolor sit amet, consectetur adipiscing elit Nam viverra euismod odio, gravida pellentesque urna varius vitae.</p></div>
                                                        </div>
                                                    </div>
                                                    
                                                </li>
                                            </ul>
                                        </div>
                                      		  <div class="comment-write">
                                            <div class="comment-write-title underline">Leave a comment</div>
                                            <form action="#" class="form-comment">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <div class="input-icon right"><i class="fa fa-user"></i><input type="text" placeholder="Name" class="form-control form-input"/></div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <div class="input-icon right"><i class="fa fa-envelope"></i><input type="text" placeholder="Email" class="form-control form-input"/></div>
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                          <button type="button" class="btn-info"> <i class="fa fa-thumbs-o-down">NO</i></button>  <button class="btn-info"><i class="fa fa-thumbs-o-up">YES</i></button>
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="col-md-12">
                                                        <div class="contact-question form-group"><textarea class="form-control form-input"></textarea></div>
                                                    </div>
                                                </div>
                                                <div class="contact-submit">
                                                    <button type="submit" class="btn btn-green btn-bold"><span>SUBMIT COMMENT</span></button>
                                                </div>
                                            </form>
                                        </div>
                                   
											</div>-->
											
										</div>
									</div>
									<div class="col-md-3 sidebar layout-right">
										<div class="row">
											<div class="clearfix"></div>
											
											<!-- ################################################################# -->
											
											
											 <div class="author-widget widget col-sm-6 col-md-12 col-xs-6 sd380">
                                            <div class="title-widget"><?php echo $this->lang->line('core.a_course_on')?></div>
                                            <div class="content-widget">
                                                <div class="staff-item author-widget-wrapper customize">
                                                    <div class="staff-item-wrapper">
                                                        <div class="staff-info"><a class="staff-avatar">
                                                       
                                                        <img src="<?php echo base_url()?>uploads/users/images.png" alt="" class="img-responsive"/></a>
                                                        
                                                        <a href="#" class="staff-name"><?php echo $courses_count[0]['CREATED_BY']?></a>
															<div style="padding-top: 50px"></div>
 															<div class="pull-left title"><strong><?php echo $this->lang->line('core.course_details')?></strong></div>
                                                            
                                                            <hr style="height:1px;border:none;color:#333;background-color:#333;" />
                                                            
                                                             <ul class="category-widget list-unstyled">
			                                                    <li><span class="pull-left cat-item"> <i class="fa fa-user"></i></span>  <span  class="pull-right" style="padding-left: 10px;"> <?php 
																		
			                                                        	echo $courses_count[0]['USER_TOT_ENROLL'];
			                                                        ?> User</span></li>
			                                                        
			                                                     <li><span class="pull-left cat-item"> <i class="fa fa-film"></i></span>  <span  class="pull-right" style="padding-left: 10px;"> 
			                                                     <?php echo $courses_count[0]['COURSE_TOT_VIDEO']?> <?php echo $this->lang->line('core.video_lesson')?></span></li>
			                                                      
			                                                      
			                                                      <li><span class="pull-left cat-item"> <i class="fa fa-thumbs-o-up"></i></span>  <span  class="pull-right" style="padding-left: 10px;"> 
			                                                     94%
																Positive reviews (<a class="link-secondary"><?php 
																
																if($courses_count[0]['USER_TOT_COMMENT']==null)
																{
																	echo "0";
																	
																}
																else 
																{
																echo $courses_count[0]['USER_TOT_COMMENT'];}?></a>)</span></li>
			                                                       
			                                                        
                                                      </ul>
                                                            
                                                            <div class="pull-left title"><strong><?php echo $this->lang->line('core.categories'); ?></strong></div>
                                                            <br>
                                                            
                                                            
                                                              <ul class="category-widget list-unstyled">
                                                              <?php if(isset($courseCategory)){?>
                                                              <?php for($i=0;$i<count($courseCategory);$i++){?>
                                                              
                                                              <?php if($this->session->userdata('lang')=='en'){?>
                                                              		<li><a href="<?php echo base_url() ?>courses/category/<?php echo $courseCategory[$i][0]['URL_REWRITE_EN']?>" class="link cat-item"><span class="pull-left"><?php echo $courseCategory[$i][0]['CATEGORY_NAME_EN']?></span></a></li>
                                                              
                                                              <?php }else{?>
                                                              		<li><a href="<?php echo base_url() ?>courses/category/<?php echo $courseCategory[$i][0]['URL_REWRITE_EN']?>" class="link cat-item"><span class="pull-left"><?php echo $courseCategory[$i][0]['CATEGORY_NAME_SP']?></span></a></li>
                                                              
                                                              <?php }?>
                                                              <?php }?>
                                                    		  <?php }?>
                                                   			 </ul>
                                                        
                                                        
                                                       <div class="pull-left title"><strong><?php echo $this->lang->line('core.software'); ?></strong></div>
                                                            
                                                             <br>
                                                            
                                                            
                                                              <ul class="category-widget list-unstyled">
                                                               <?php if(isset($courseSoftware)){?>
                                                              <?php for($i=0;$i<count($courseSoftware);$i++){?>
                                                              
                                                              <?php if($this->session->userdata('lang')=='en'){?>
                                                              		<li><a href="<?php echo base_url() ?>courses/software/<?php echo $courseSoftware[$i][0]['URL_REWRITE_EN']?>" class="link cat-item"><span class="pull-left"><?php echo $courseSoftware[$i][0]['SOFTWARE_NAME_EN']?></span></a></li>
                                                              
                                                              <?php }else{?>
                                                              		<li><a href="<?php echo base_url() ?>courses/software/<?php echo $courseSoftware[$i][0]['URL_REWRITE_EN']?>" class="link cat-item"><span class="pull-left"><?php echo $courseSoftware[$i][0]['SOFTWARE_NAME_SP']?></span></a></li>
                                                              
                                                              <?php }?>
                                                              <?php }?>
                                                              <?php }?>
                                                    
                                                   			 </ul>
                                                            
                                                            
                                                            </div>
                                                    </div>
                                                    </div>
                                            </div>
                                        </div>
											
											<!-- ################################################################ -->
											
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- BUTTON BACK TO TOP-->
		<div id="back-top">
			<a href="#top"><i class="fa fa-angle-double-up"></i></a>
		</div>
	</div>
	
	

	
<?php $this->load->view('frontend/layouts/footerlang');?> <!-- footer view Load -->

	