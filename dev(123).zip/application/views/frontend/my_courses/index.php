<div id="wrapper-content">
		<!-- PAGE WRAPPER-->
		<div id="page-wrapper">
			<!-- MAIN CONTENT-->
			<div class="main-content">
				<!-- CONTENT-->
				<div class="content">
				

					<div class="section section-padding courses-detail">
						<div class="container">
							<div class="courses-detail-wrapper">
								<div class="row">
									<div class="col-md-9 layout-right">
										<fieldset>
											<legend>My Courses</legend>
											
											
											<?php if (count($result)>0){?>
											
											 <?php for($i=0;$i<count($result);$i++){?>
										<div class="col-md-12" style="margin-top: 25px">

											<div>

												<div class="col-md-4">
													 <?php if(isset($courseCover[$i][0]['COURSE_INFO_CONT_TYPE'])){?>
                                        
                                         					 <?php if($courseCover[$i][0]['COURSE_INFO_CONT_TYPE']=='FILEUPLOAD'){?>
													
													<img
														src="<?php echo base_url()?>uploads/course/<?php echo $courseCover[$i][0]['COURSE_INFO_CONT_VALUE'] ?>"
														style="width: 250px; height: 180px;" />

																<?php
														
} else {
															preg_match ( '/https?:\/\/(.+)?(wistia\.com|wi\.st)\/(medias|embed)\/(.+)?/', $courseCover [$i] [0] ['COURSE_INFO_CONT_VALUE'], $coverVideo );
															
															$cover = "wistia_embed wistia_async_" . $coverVideo [4] . " popover=true popoverBorderWidth=2";
															// echo $cover;
															?>	
																
																									

													
													
													
													
														<a class="edugate-image">
														<div class="<?php echo $cover?>"
															style="width: 250px; height: 180px;"> &nbsp;
															</div>

													</a>
<?php }?>
																<?php
													
} else {
														?>
																
																<img
														src="<?php echo base_url()?>uploads/course/noimage.png"
														style="width: 250px; height: 180px;" />
																	
															<?php
													
}
													?>

													</div>

												<div class="col-md-8">
													<a
														href="<?php echo base_url()?>courses/<?php echo $courseName[$i]?>"> <h4> <?php echo $myCourseName[$i]['COURSE_NAME']?></h4></a>

													<div>
														<?php  $in=strip_tags($shortContent[$i][0]['COURSE_INFO_CONT_VALUE']);?>
															<p><?php echo mb_strimwidth($in, 0, 100, "");?></p>
													</div>
													<div class="col-md-10" style="margin-top: 25px">
														<div class="progress">
															<div aria-valuemax="100" aria-valuemin="0"
																aria-valuenow="25.0"
																class="progress-bar progress-bar-success"
																role="progressbar" style="width: 25.0%"></div>

														</div>
													</div>
													<div class="col-md-2" style="margin-top: 25px">
														<p class="course-item__progress__value pull-left">1 of 4</p>
													</div>


												</div>

											</div>
										</div>
										<?php }
										
										   
										
										}else 
										{
											echo "<h5>You haven't taken any Proyectarte courses.</h5> ";
										}
										?>
											
											
											
											  <div class="row">
                                <nav class="pagination col-md-12">
                                    <ul class="pagination__list">
                                         <?php echo  $pagination  ?>
                                    </ul>
                                </nav>
                            </div>
												
											 
											
											
											<!-- sdfsdfdsfdsfdsfsdf -->
											
										
											
										</fieldset>

									</div>
									<div class="col-md-3 sidebar layout-left">
										<!-- My Course option -->
										<div class="row">
											<div class="clearfix"></div>
											
											<div
												class="category-widget widget col-sm-6 col-md-12 col-xs-6 sd380">
												<div class="title-widget">Course</div>
												<div class="content-widget">
													<ul class="category-widget list-unstyled">
														<li><a href="<?php echo base_url()?>my_courses" class="js-smooth-scroll"><span
																class="pull-left">My course</span></a></li>
														<li><a href="<?php echo base_url()?>courses/high_rated"
															class="js-smooth-scroll"><span class="pull-left">Highest-rated course</span></a></li>
														<li><a href="<?php echo base_url()?>courses/recent" class="js-smooth-scroll"><span
																class="pull-left">Recent courses</span></a></li>
														<li><a href="<?php echo base_url()?>courses/popular" class="js-smooth-scroll"><span
																class="pull-left">Popular courses</span></a></li>
														<li><a href="<?php echo base_url()?>courses" class="js-smooth-scroll"><span
																class="pull-left">Course</span></a></li>
													</ul>
												</div>
											</div>
											
											
											
											<div class="clearfix"></div>
											
											<?php  $category=FrontendHelpers::footer_category();
																 $software=FrontendHelpers::footer_software();
																 $area=FrontendHelpers::footer_area();
																 
															?>
															
											<div
												class="category-widget widget col-sm-6 col-md-12 col-xs-6 sd380">
												<div class="title-widget">Categories</div>
												<div class="content-widget">
												
													<ul class="category-widget list-unstyled">
													
													 <?php if(count($category)>0){?>
														 	 <?php   foreach($category as $e): ?>
														 	 <?php if($this->session->userdata('lang')=='en'){?>
													
														<li><a href="<?php echo base_url()?>courses/category/<?php echo $e->URL_REWRITE_EN;?>" class="link cat-item"><span
																class="pull-left"><?php  echo $e->CATEGORY_NAME_EN; ?></span></a></li>
																
															<?php } else {?>	
														<li><a href="<?php echo base_url()?>courses/category/<?php echo $e->URL_REWRITE_SP;?>" class="link cat-item"><span
																class="pull-left"><?php  echo $e->CATEGORY_NAME_SP; ?></span></a></li>
																
																 <?php }?>
   															 <?php endforeach; ?>
															<?php }?>
															
															
														
													</ul>
												</div>
											</div>
											<div
												class="category-widget widget col-sm-6 col-md-12 col-xs-6 sd380">
												<div class="title-widget">Areas</div>
												<div class="content-widget">
													<ul class="category-widget list-unstyled">
													
													
													
													<?php if(count($area)>0){?>
														 	 <?php   foreach($area as $e): ?>
														 	 <?php if($this->session->userdata('lang')=='en'){?>
													
														<li><a href="<?php echo base_url()?>courses/area/<?php echo $e->URL_REWRITE_EN;?>" class="link cat-item"><span
																class="pull-left"><?php  echo $e->AREA_NAME_EN; ?></span></a></li>
																
															<?php } else {?>	
														<li><a href="<?php echo base_url()?>courses/area/<?php echo $e->URL_REWRITE_SP;?>" class="link cat-item"><span
																class="pull-left"><?php  echo $e->AREA_NAME_SP; ?></span></a></li>
																
																 <?php }?>
   															 <?php endforeach; ?>
															<?php }?>
															
															
													
													
													
													</ul>
												</div>
											</div>
											<div
												class="category-widget widget col-sm-6 col-md-12 col-xs-6 sd380">
												<div class="title-widget">Software</div>
												<div class="content-widget">
													<ul class="category-widget list-unstyled">
													
															<?php if(count($software)>0){?>
														 	 <?php   foreach($software as $e): ?>
														 	 <?php if($this->session->userdata('lang')=='en'){?>
													
														<li><a href="<?php echo base_url()?>courses/software/<?php echo $e->URL_REWRITE_EN;?>" class="link cat-item"><span
																class="pull-left"><?php  echo $e->SOFTWARE_NAME_EN; ?></span></a></li>
																
															<?php } else {?>	
														<li><a href="<?php echo base_url()?>courses/software/<?php echo $e->URL_REWRITE_SP;?>" class="link cat-item"><span
																class="pull-left"><?php  echo $e->SOFTWARE_NAME_SP; ?></span></a></li>
																
																 <?php }?>
   															 <?php endforeach; ?>
															<?php }?>
															
														
													</ul>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- BUTTON BACK TO TOP-->
		<div id="back-top">
			<a href="#top"><i class="fa fa-angle-double-up"></i></a>
		</div>
	</div>
	<!-- FOOTER-->
		<?php $this->load->view('frontend/layouts/footerlang');?>