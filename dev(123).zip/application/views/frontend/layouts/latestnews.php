<!--LATEST NEW-->
<?php  $news=FrontendHelpers::news();
if(count($news)>0){?>

<?php   foreach($news as $e): ?>
														 		
   															
					<div class="section section-padding latest-news">
						<div class="container">
							<div class="group-title-index">
								<h2 class="center-title"><?php echo $this->lang->line('core.news'); ?></h2>

								<div class="bottom-title">
									<i class="bottom-icon icon-icon-04"></i>
								</div>
							</div>
							<div class="latest-news-wrapper">
								<div class="edugate-layout-1">
									<div class="edugate-image">
										<img src="uploads/News/<?php echo $e->CMS_IMAGE?>" alt=""
											class="img-responsive" />
									</div>
									<div class="edugate-content">
										<a href="#" class="title">
										
										<?php if($this->session->userdata('lang')=='en'){?>
										<?php echo $e->CMS_TITLE_EN?>
<?php
} else {
			?>
<?php echo $e->CMS_TITLE_SP?>
<?php }?>
										</a>

										<div class="info-more">
												
											
										</div>
										<div class="description">
										<?php if($this->session->userdata('lang')=='en'){?>
										<?php echo $e->CMS_DESC_EN?></div>
<?php }
else {?>
<?php echo $e->CMS_DESC_SP?></div>
<?php }?>
										
										<button onclick="window.location.href='#'"
											class="btn btn-green">
											<span>Sign up</span>
										</button>
									</div>
								</div>

							</div>
						</div>
					</div>
<?php endforeach; ?>
<?php }?>	
<!--LATEST NEW-->
					<!-- End Lastest News -->