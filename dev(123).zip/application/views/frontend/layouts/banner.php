	 <?php  $banner=FrontendHelpers::banner();
																
					//print_r($banner);		
					
					
															?>
														 
														 	
														 
				<!-- Banner -->
					
					<div class="section slider-banner set-height-top">
					
					 <?php  for ($i=0;$i<count($banner);$i++){ ?>
														 	 
												<div class="slider-item">
						
							<div class="slider-1" style="background-image:url(uploads/banner/<?php echo $banner[$i]->BANNER_IMAGE?>)">
							
								<div class="slider-caption">
								
									<div class="container">
										<h5 class="text-info-2">
										<!-- Site Name display --></h5>
	<?php if($this->session->userdata('lang')=='en'){?>
	 <h1 class="text-info-1"><?php echo $banner[$i]->BANNER_DESC_EN?></h1>
	<?php }
else {?>
 <h1 class="text-info-1"><?php echo $banner[$i]->BANNER_DESC_SP?></h1>
<?php }?>
	                                   
	
	                                    <p class="text-info-3"><!-- Some extra description --></p>
	                                    
                               		</div>
								</div>
							</div>
						</div>		 	 
														 	 
														 	 <?php } ?>
														 	 
									
						
					</div>
					<!-- End Banner -->