
 
<style>
	.mystyle{
		
		background: url(assets/bg-404.jpg) no-repeat;
		background-size:fixed;
		
	}
	.contactform{
	
		background: transparent;
		width: 100%;
		margin: 80px auto 0;
		
	}
	.contactform input{
		background: transparent;
    	margin-bottom: 20px;
		width: 50%;
		height: 30px;
		color: #fff;
		background: rgba(23, 24, 25, 0.29);
		border: 2px ridge rgba(238, 238, 238, 0.13);
		border-radius: 5px;
	
	}
	.contactform textarea{
		background: transparent;
		margin-bottom: 20px;
		color: #fff;
		background: rgba(23, 24, 25, 0.29);
		border: 2px ridge rgba(238, 238, 238, 0.13);
   		width: 50%;
   		height: 6em;
   		border-radius: 5px;
	
	}
	::-webkit-input-placeholder{
	   color: #fff;
	}

	::-moz-input-placeholder{
	   color: #fff;
	}
</style>

<div class="mystyle">

		<div class="grad"></div>
		
		<br>
		<div class="contactform">
				<input type="text" placeholder="username" name="user"><br>
				<input type="password" name="password"><br>
				<textarea name="message" rows="4"></textarea><br>
				<input type="button" value="Login">
				
		</div>
		
		<!-- Hyper Link -->
		
		<!-- END -->
</div>







