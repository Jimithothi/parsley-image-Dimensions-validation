<!DOCTYPE html>
<html lang="en-US">
	<head>
		<meta charset="utf-8">
	</head>
	<body>
		
		<p> Thank your for joining with our site </p>
		<p> Bellow is your account Info </p>
		<p>
			Email :  <?php echo $USER_NAME ?> <br />
			Password :  <?php echo $PWD ?><br />
		</p>
		<p> Please follow link activation  <a href="<?php echo site_url('auth/activation?code='.$code) ?>"> Active my account now</a></p>
		<p> If the link now working , copy and paste link bellow </p>
		<p>  <?php echo site_url('auth/activation?code='.$code) ?> </p> 
		<br /><br /><p> Thank You </p><br /><br />
		
		 <?php //echo CNF_APPNAME ?> 
	</body>
</html>