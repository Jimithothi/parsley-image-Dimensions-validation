<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * @package     CodeIgniter
 * @author      Ikraftsolutions
 * @copyright   Copyright (c) Ikraftsolutions (http://ikraftsolutions.com)
 * @version 1.0
 */

class Auth extends SB_Controller
{
	protected $layout 	= "frontend/layouts/main";
	function __construct()
	{
		parent::__construct();
		//$this->load->model('coursesmodel');
		//$this->model = $this->coursesmodel;
	}
	function index()
	{
		show_404();
	}
	
	function password($id=null)
	{
		if($id=='new')
		{
			$this->load->view('frontend/user/index');
			//echo "hello";
			//$this->load->view('frontend/user/sendpassword');
			//$this->load->view('frontend/user/index');
		}
		elseif ($this->session->flashdata('UserId')==null) 
		{
			show_404();
		}
		else 
		{
			//$this->load->view('frontend/user/index');
			//echo "hello";
			$this->load->view('frontend/user/sendpassword');
		}
	}
	public function saveRequest()
	{

		if($this->input->post('forgetemail',true)==NULL)
		{
			show_404();
		}
		else 
		{
			$rules = array(
					array('field'   => 'forgetemail','rules'   => 'required|email'),
			);
			$this->form_validation->set_rules( $rules );
			if( !$this->form_validation->run() )
			{
				$user = $this->db->get_where('user_master',array('USER_NAME'=>$this->input->post('forgetemail',true)))->row();
				
				//print_r($user);
				//exit;
				
				$token = md5(rand(10000,10000000));
				$this->data = array('token'=>$token);
				
				$config['protocol']    = 'smtp';
				$config['smtp_host']    = 'ssl://smtp.gmail.com';
				$config['smtp_port']    = '465';
				$config['smtp_timeout'] = '7';
				$config['smtp_user']    = 'haribhajan101@gmail.com';
				$config['smtp_pass']    = 'H2SO4H2O';
				$config['charset']    = 'utf-8';
				$config['newline']    = "\r\n";
				$config['mailtype'] = 'html'; // or html
				$config['validation'] = TRUE; // bool whether to validate email or not
	
				$message = $this->load->view('emails/reminder', $this->data,true);
					
				$this->load->library('email', $config);
					
				$this->email->from('noreply@gmail.com', 'reset Password');
				$this->email->to($this->input->post('forgetemail'));
					
				$this->email->subject('reset new Password'); // mail title
				$this->email->message($message);
					
				$this->email->send();
				
				$data = array('REMEMBER_TOKEN'=>$token);
				$this->db->where('USER_ID',$user->USER_ID);
				$this->db->update('user_master',$data);
				
				//$this->password($user->USER_ID);
				$this->session->set_flashdata('UserId',$user->USER_ID);
				redirect('auth/password');
			} 
		} 
	}
	public function edit($id=null)
	{
			$user = $this->db->get_where('user_master',array('REMEMBER_TOKEN'=>$this->input->get('reset_password_token', true)))->row();
			if(count($user) >=1)
			{
				$this->data['USER_ID']=$user->USER_ID;
				$this->data['reset_token']=$this->input->get('reset_password_token', true);
				$this->load->view('frontend/user/resetpassword',$this->data);
			} else {
				show_404();
			}
	}
	
	public function setPassword()
	{
			$user = $this->db->get_where('user_master',array(
					'REMEMBER_TOKEN'=>$this->input->get('reset_password_token', true),
					'USER_ID'=>$this->input->post('id', true)))->row();
			
			if(count($user)>=1)
			{
				log_message('info','PASSWORD  :::::::::::::'.$this->input->post('password', true));
				log_message('info','CONFIRM PASSWORD ::::::::::::'.$this->input->post('password_confirmation', true));
				log_message('info','USER_ID ::::::::::::'.$this->input->post('id', true));
				$data =   array('PASSWORD'=>md5(trim($this->input->post('password'))),'REMEMBER_TOKEN'=>'');
				$this->db->where('USER_ID',$user->USER_ID);
				$this->db->update('user_master',$data);
				redirect('',301);
			}
			else 
			{
				show_404();
			}
	}
	
	public function activation( )
	{
		$num = $this->input->get('code',true);
		if($num =='')
		{
			$this->session->set_flashdata('message',SiteHelpers::alert('error','Invalid Code Activation!'));
			redirect('',301);
		}
		$user = $this->db->get_where('user_master',array('ACTIVATION'=>$num))->row();
		if (count($user) >=1)
		{
			$data = array('INACTIVE' => 1,'ACTIVATION'=>'');
			$this->db->where('ACTIVATION',$num);
			$this->db->update('user_master',$data);
	
			$this->session->set_flashdata('message',SiteHelpers::alert('success','Your account is active now!'));
			redirect('',301);
	
		} else {
	
			$this->session->set_flashdata('message',SiteHelpers::alert('error','Invalid Code Activation!'));
			redirect('',301);
		}
	
	}
}

?>