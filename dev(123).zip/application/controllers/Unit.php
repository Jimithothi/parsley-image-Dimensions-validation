<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * @package     CodeIgniter
 * @author      Ikraftsolutions
 * @copyright   Copyright (c) Ikraftsolutions (http://ikraftsolutions.com)
 * @version 1.0
 */


class Unit extends SB_Controller 
{

	protected $layout 	= "admin/layouts/main";
	public $module 		= 'unit';
	public $per_page	= '10';

	function __construct() {
		parent::__construct();
		
		$this->load->model('unitmodel');
		$this->model = $this->unitmodel;
		
		$this->info = $this->model->makeInfo( $this->module);
		$this->data = array_merge( $this->data, array(
			'pageTitle'	=> 	$this->info['title'],
			'pageNote'	=>  $this->info['note'],
			'pageModule'	=> 'unit',
		));
		
		if(!$this->session->userdata('logged_in')) redirect('user/login',301);
		
	}
	
	function index() 
	{
		
		
		$results=$this->model->getUnits($this->session->userdata('COURSE_ID'));  // Latest Course get in home page
		$this->data['rowData']		= $results['rows'];
		
		$this->data['tableGrid'] 	= $this->info['config']['grid'];
		$this->data['tableForm'] 	= $this->info['config']['forms'];
		$this->data['colspan'] 		= SiteHelpers::viewColSpan($this->info['config']['grid']);
		
		
		$this->data['content'] = $this->load->view('admin/unit/index',$this->data, true );
		
    	$this->load->view($this->layout, $this->data );
    	
		

	  
	}
	
	function show( $id = null) 
	{
		
		$row = $this->model->getRow($id);
		if($row)
		{
			$this->data['row'] =  $row;
		} else {
			$this->data['row'] = $this->model->getColumnTable('course_unit'); 
		}
		
		$this->data['id'] = $id;
		$this->data['content'] =  $this->load->view('admin/unit/view', $this->data ,true);	  
		$this->load->view($this->layout,$this->data);
	}
  
	function add( $id = null ) 
	{
		
		$row = $this->model->getRow( $id );
		if($row)
		{
			$this->data['row'] =  $row;
			$this->data['addForm']="Edit Unit";
			$this->data['COURSE_CONTENT'] = $this->model->getRowtable( $table='course_unit_information',$key='UNIT_ID',$id );
		} else {
			$this->data['row'] = $this->model->getColumnTable('course_unit'); 
			$this->data['addForm']="Add Unit";
		}
	
		$this->data['id'] = $id;
		$this->data['content'] = $this->load->view('admin/unit/form',$this->data, true );		
	  	$this->load->view($this->layout, $this->data );
	
	}
	
	function save() {
		
		//$data = $this->input->post('checkbox');
		//var_dump($data);
		
		
	
		
		if($this->input->post('checkboxValue')!=NULL)
		{
			$dataCheck = $this->input->post('checkboxValue');
			$subunitcount=count($datacheck);
		}
		
		
		//print_r($data1);
		
		//exit;
		
			$rules = $this->validateForm();
	
			$this->form_validation->set_rules( $rules );
	
			if( !$this->form_validation->run()){
				$data =	array(
						'message'	=> 'Ops , The following errors occurred',
						'errors'	=> validation_errors('<li>', '</li>')
						);			
				$this->displayError($data);
			}

			$data = $this->validatePost();
			$data['CREATED_BY']=$this->session->userdata('NICK_NAME');
			
			
			$courseID=$data['COURSE_ID'];
			//exit;
			
			$ID = $this->model->insertRow($data , $this->input->get_post( 'UNIT_ID' , true ));
			
			
			######################################################################


			$content=array();
			$contentType = $this->input->post('type');
			
			$contentData = $this->input->post('COURSE_CONTENT');
			
			$countImages=0;
			$imageArray=array();
			for($i=0;$i<count($contentType);$i++)
			{
				if($contentType[$i]=="FILEUPLOAD")
				{
					$countImages++;
				}
			if($contentType[$i]=="SOUND")
				{
					$countImages++;
				}
			}
			
			if($this->input->post('COURSE_CONTENT_IMAGE')!=null)
			{
				$course_content_image=$this->input->post('COURSE_CONTENT_IMAGE');
			}
			
			$content_image=0;
			
			///echo "Hello::::::::::::.....".count($_FILES['COURSE_CONTENT']);
			//exit;
			if(count($_FILES['COURSE_CONTENT']['name'])>0){
				
			
				for($j=0;$j<count($_FILES['COURSE_CONTENT']['name']);$j++)
				{
					if($_FILES['COURSE_CONTENT']['name'][$j]=="")
					{
						$imageNameArray[$j]=$course_content_image[$content_image];
						$content_image++;
					}
					else
					{
						$ext=pathinfo($_FILES['COURSE_CONTENT']['name'][$j], PATHINFO_EXTENSION);
						$imageNameArray[$j] = random_string('alnum',32).'.'.$ext;
					}
				}
			}
			
			$this->load->library('upload');
				
			$files = $_FILES;
			$cpt = count($_FILES['COURSE_CONTENT']['name']);
			
			for($j=0; $j<$cpt; $j++)
			{
				if($_FILES['COURSE_CONTENT']['name'][$j]=="")
				{
				}
				else
				{
					$_FILES['COURSE_CONTENT']['name']= $files['COURSE_CONTENT']['name'][$j];
					$_FILES['COURSE_CONTENT']['type']= $files['COURSE_CONTENT']['type'][$j];
					$_FILES['COURSE_CONTENT']['tmp_name']= $files['COURSE_CONTENT']['tmp_name'][$j];
					$_FILES['COURSE_CONTENT']['error']= $files['COURSE_CONTENT']['error'][$j];
					$_FILES['COURSE_CONTENT']['size']= $files['COURSE_CONTENT']['size'][$j];
				
					$config['upload_path'] = './uploads/course/unit/';
					$config['allowed_types'] = 'mp3|wav|gif|jpg|png';
					$config['file_name'] = $imageNameArray[$j];
				
					$this->upload->initialize($config);
					if ( ! $this->upload->do_upload('COURSE_CONTENT')) {echo $this->upload->display_errors();die();}
					$file_data = $this->upload->data();
				
					$filename = $imageNameArray[$j];
				}
			}
			$imageCount=0;
			$contentCount=0;
				
			$this->model->course_information_delete($table='course_unit_information',$key='UNIT_ID',$ID);
			$subunits=0;
			$countVideo=0;
			if(count($contentType)>0){
				
				for($i=0;$i<count($contentType);$i++)
				{
					if($contentType[$i]=="TEXT")
					{
						$content[$i]=array(
								
								'UNIT_ID'=>$ID,
								'UNIT_INFO_CONT_TYPE'=>$contentType[$i],
								'UNIT_INFO_CONT_VALUE'=>$contentData[$contentCount],
								'UNIT_INFO_ORDER'=>$i+1
						);
						$contentCount++;
			
					}
					elseif($contentType[$i]=="MEDIA")
					{
						$content[$i]=array(
								'UNIT_ID'=>$ID,
								'UNIT_INFO_CONT_TYPE'=>$contentType[$i],
								'UNIT_INFO_CONT_VALUE'=>$contentData[$contentCount],
								'UNIT_INFO_ORDER'=>$i+1
						);
						$contentCount++;
						
					$countVideo=$countVideo+1;
						
					}
					elseif($contentType[$i]=="TEXTBOX")
					{
						$content[$i]=array(
								'UNIT_ID'=>$ID,
								'UNIT_INFO_CONT_TYPE'=>$contentType[$i],
								'UNIT_INFO_CONT_VALUE'=>$contentData[$contentCount],
								'UNIT_INFO_ORDER'=>$i+1,
								'IS_SUBUNIT'=>$dataCheck[$subunits]
						);
						$subunits++;
						$contentCount++;
					}
					elseif($contentType[$i]=="SOUND")
					{
						$content[$i]=array(
								'UNIT_ID'=>$ID,
								'UNIT_INFO_CONT_TYPE'=>$contentType[$i],
								'UNIT_INFO_CONT_VALUE'=>$imageNameArray[$imageCount],
								'UNIT_INFO_ORDER'=>$i+1
						);
						$imageCount++;
					}
					else
					{
						$content[$i]=array(
								'UNIT_ID'=>$ID,
								'UNIT_INFO_CONT_TYPE'=>$contentType[$i],
								'UNIT_INFO_CONT_VALUE'=>$imageNameArray[$imageCount],
								'UNIT_INFO_ORDER'=>$i+1
						);
						$imageCount++;
					}
					$this->db->insert('course_unit_information',$content[$i]);
				}
				
				$totalVideo=$this->model->getTotalvideo();
				
				$datavideo=array('COURSE_TOT_VIDEO'=>($totalVideo['COURSE_TOT_VIDEO']+$countVideo));
				$this->model->update_video($datavideo);
			}
			else
			{
				/*$content=array(
						'UNIT_ID'=>$ID,
						'UNIT_INFO_CONT_TYPE'=>'',
						'UNIT_INFO_CONT_VALUE'=>'',
						'UNIT_INFO_ORDER'=>'1'
				);
				$this->db->insert('course_unit_information',$content);*/
			}
			//echo $courseID;
			
			$resultVideo=$this->model->GetUnitID($courseID);
			
			//echo "<pre>";
			$videoUpdate=0;
			for($i=0;$i<count($resultVideo);$i++)
			{
				$count=$this->model->countVideo($resultVideo[$i]['UNIT_ID']);
				//echo $count;
				$videoUpdate=$count+$videoUpdate;
			}
			
			echo $videoUpdate;
			
			$this->model->updateVideo($videoUpdate,$courseID);
			
			//exit;
			//print_r($resultVideo);
			
			
			//echo "</pre>";
			//exit;
			
			######################################################################
			
			if($this->input->post('Update'))
			{
				SiteHelpers::alert('success',$data['UNIT_NAME']." Has Been Changed Successfull !");
				redirect( 'unit',301);
			} 
			elseif($this->input->post('Save')) {
				//$this->session->set_flashdata('courseData',$courseData);
				SiteHelpers::alert('success',$this->session->userdata('COURSE_NAME')." has been saved succesfuly !");
				redirect('admin/course',301);
			}
			else 
			{
				SiteHelpers::alert('success',$data['UNIT_NAME']." has been saved succesfuly !");
				redirect('unit/add');
			}
	}
	
	function view($page=null)
	{
		$result=$this->model->getunit($page);

		if(count($result)==0)
		{
		}
		else
		{
			$this->data['row']=$result;
			$content=$this->model->getUnitcontent($page);
				
			$this->data['courseContent']=$content;
			$this->data['content']= $this->load->view('frontend/unit/view',$this->data, TRUE);
			$this->load->view('frontend/layouts/main', $this->data );
		}
		
	}

	function destroy()
	{
		$this->model->unsetFiles($table='course_unit_information',$key='UNIT_ID',$this->input->post( 'id' , true ));
		$this->model->course_delete($table='course_unit_information',$key='UNIT_ID',$this->input->post( 'id' , true ));
		$this->model->destroy($this->input->post( 'id' , true ));
		$this->inputLogs("ID : ".implode(",",$this->input->post( 'id' , true ))."  , Has Been Removed Successfull");
			SiteHelpers::alert('success',"ID : ".implode(",",$this->input->post( 'id' , true ))."  , Has Been Removed Successfull");
		Redirect('unit',301); 
	}

}
