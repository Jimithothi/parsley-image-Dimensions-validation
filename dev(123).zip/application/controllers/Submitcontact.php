<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * @package     CodeIgniter
 * @author      Ikraftsolutions
 * @copyright   Copyright (c) Ikraftsolutions (http://ikraftsolutions.com)
 * @version 1.0
 */

class Submitcontact extends SB_Controller
{
	
	function  index()
	{
	
		
		
		
			$data = array(
					'name'=>$this->input->post('name',true),
					'email'=>$this->input->post('email',true),
					'subject'=> 'New Form Submission',
					'notes'=>$this->input->post('message',true)
			);
			$message = $this->load->view('emails/contact', $data,true);
	
	
			
			
			
			
			$config['protocol']    	= 'smtp';
			$config['smtp_host']    = 'ssl://smtp.gmail.com';
			$config['smtp_port']    = '465';
			$config['smtp_timeout'] = '7';
			$config['smtp_user']    = 'haribhajan101@gmail.com';
			$config['smtp_pass']    = 'H2SO4H2O';
			$config['charset']    	= 'utf-8';
			$config['newline']   	= "\r\n";
			$config['mailtype'] 	= 'html'; // or html
			$config['validation'] 	= TRUE; // bool whether to validate email or not
						
			
			
			$this->load->library('email', $config);
			
			$this->email->from($data['email'], $data['name']);
			$this->email->to(CNF_EMAIL);
				
			$this->email->subject($data['subject']);
			$this->email->message($message);
			
			$this->email->send();
			
			$this->session->set_flashdata('message','Message send sucessfully');
			 
			
			redirect( base_url().'contact-us');
			
			/*
			
			$subject 	= 'New Form Submission';
			$headers  	= 'MIME-Version: 1.0' . "\r\n";
			$headers 	.= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
			$headers 	.= 'From: '.$this->input->post('name',true).' <'.$this->input->post('sender',true).'>' . "\r\n";
			//mail($to, $subject, $message, $headers);
			$message = "Thank You , Your message has been sent !";
			$this->session->set_flashdata('message',SiteHelpers::alert('success',$message));
			redirect('contact-us',301);
	
	*/
		
	
	}
}