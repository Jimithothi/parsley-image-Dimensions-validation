<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * @package     CodeIgniter
 * @author      Ikraftsolutions
 * @copyright   Copyright (c) Ikraftsolutions (http://ikraftsolutions.com)
 * @version 1.0
 */

class Course extends SB_Controller 
{

	protected $layout 	= "admin/layouts/main";
	public $module 		= 'course';
	public $pmodule		= 'admin/course';
	public $per_page	= '10';

	function __construct() {
		parent::__construct();
		
		$this->load->model('admin/coursemodel');
		$this->model = $this->coursemodel;
		
		$this->info = $this->model->makeInfo( $this->module);
		$this->data = array_merge( $this->data, array(
			'pageTitle'	=> 	$this->info['title'],
			'pageNote'	=>  $this->info['note'],
			'pageModule'	=> 'admin/course',
		));
		
		
		if(!$this->session->userdata('logged_in')) redirect('admin/user/login',301);
		
	}
	
	function index() 
	{
		$this->session->set_userdata(array(
				'COURSE_ID'  => '',
				'COURSE_NAME'    => '',
				
		
		));
		$sort = (!is_null($this->input->get('sort', true)) ? $this->input->get('sort', true) : 'COURSE_ID'); 
		$order = (!is_null($this->input->get('order', true)) ? $this->input->get('order', true) : 'asc');
		$filter = (!is_null($this->input->get('search', true)) ? $this->buildSearch() : '');
		
		
		$page = max(1, (int) $this->input->get('page', 1));
		$params = array(
			'page'		=> $page ,
			'limit'		=> ($this->input->get('rows', true) !='' ? filter_var($this->input->get('rows', true),FILTER_VALIDATE_INT) : $this->per_page ) ,
			'sort'		=> $sort ,
			'order'		=> $order,
			'params'	=> $filter,
		);
		
		$results = $this->model->getRows( $params );		
		
		
		$page = $page >= 1 && filter_var($page, FILTER_VALIDATE_INT) !== false ? $page : 1;	
		#$pagination = Paginator::make($results['rows'], $results['total'],$params['limit']);		
		$this->data['rowData']		= $results['rows'];
		
		
		$pagination = $this->paginator( array(
			'total_rows' => $results['total'] ,
			'per_page'	 => $params['limit']
		));
		$this->data['Total_count']=$results['total'];
		$this->data['pagination']	= $pagination;
		
		$this->data['i']			= ($page * $params['limit'])- $params['limit']; 
		
		$this->data['tableGrid'] 	= $this->info['config']['grid'];
		$this->data['tableForm'] 	= $this->info['config']['forms'];
		$this->data['colspan'] 		= SiteHelpers::viewColSpan($this->info['config']['grid']);		
		
		$this->data['content'] = $this->load->view('admin/course/index',$this->data, true );
		
    	$this->load->view($this->layout, $this->data );
	  
	}
	
	function show( $id = null) 
	{
		
		$row = $this->model->getRow($id);
		if($row)
		{
			$this->data['row'] =  $row;
		} else {
			$this->data['row'] = $this->model->getColumnTable('course_master'); 
		}
		
		$this->data['id'] = $id;
		$this->data['content'] =  $this->load->view('admin/course/view', $this->data ,true);	  
		$this->load->view($this->layout,$this->data);
	}
  
	function add( $id = null ) 
	{
		
		$row = $this->model->getRow( $id );

		if($row)
		{
			$this->data['row'] =  $row;
			$this->data['COURSE_CONTENT'] = $this->model->getRowtable( $table='course_information',$key='COURSE_ID',$id );
			
			/***********************
			 * Course Mapping
			 **********************/
			
			$this->data['category']=$this->model->getSelectbox('category_master');			
			$this->data['software']=$this->model->getSelectbox('software_master');
			$this->data['area']=$this->model->getSelectbox('area_master');
			$dataCategory=array(
							'COURSE_ID'=>$row['COURSE_ID'],
							'TYPE'=>'CATEGORY',
							);
			$dataSoftware=array(
					'COURSE_ID'=>$row['COURSE_ID'],
					'TYPE'=>'SOFTWARE',
			);
			$dataArea=array(
					'COURSE_ID'=>$row['COURSE_ID'],
					'TYPE'=>'AREA',
			);
			$this->data['checkCategory']=$this->model->getCheckSelectbox('course_area_category_mapping',$dataCategory);
			$this->data['checkSoftware']=$this->model->getCheckSelectbox('course_area_category_mapping',$dataSoftware);
			$this->data['checkArea']=$this->model->getCheckSelectbox('course_area_category_mapping',$dataArea);

			/********************
			 * End mapping
			 *******************/
			
			$this->data['addForm']="Edit Course";
			$this->session->set_userdata(array(
					'COURSE_ID'  => $row['COURSE_ID'],
					'COURSE_NAME'    => $row['COURSE_NAME'],
						
			));
		}
		else {
			$this->session->set_userdata(array(
					'COURSE_ID'  => '',
					'COURSE_NAME'    => '',
			
			));
			$this->data['addForm']="Add Course";
			
			/***********************
			 * Course Mapping
			 **********************/
			$this->data['category']=$this->model->getSelectbox('category_master');
			$this->data['software']=$this->model->getSelectbox('software_master');
			$this->data['area']=$this->model->getSelectbox('area_master');			
			$this->data['checkCategory']=array();
			$this->data['checkSoftware']=array();
			$this->data['checkArea']=array();
			
			/********************
			 * End mapping
			 *******************/
			$this->data['row'] = $this->model->getColumnTable('course_master'); 
		}
	
		$this->data['id'] = $id;
		$this->data['content'] = $this->load->view('admin/course/form',$this->data, true );		
	  	$this->load->view($this->layout, $this->data );
	}
	
	function save() {
			
			$rules = $this->validateForm();
			$this->form_validation->set_rules( $rules );
			
			if( !$this->form_validation->run()){
				$data =	array(
						'message'	=> 'Ops , The following errors occurred',
						'errors'	=> validation_errors('<li>', '</li>')
						);	
				
				$this->displayError($data);
			}
			$data = $this->validatePost();
			$data['CREATED_BY']=$this->session->userdata('NICK_NAME');
			
			
			
			$ID = $this->model->insertRow($data , $this->input->get_post( 'COURSE_ID' , true ));

			/********************
			 *  insert course mapping
			 *******************/
			
			$this->model->course_information_delete($table='course_area_category_mapping',$key='COURSE_ID',$ID);

			$category = $this->input->post('category');
				
			$software=$this->input->post('software');
			$area=$this->input->post('area');
			
			if(count($category)>0)
			{
				for($i=0;$i<count($category);$i++)
				{
					$categorymapping[$i]=array(
							'COURSE_ID'=>$ID,
							'AREA_CAT_SOFTWARE_ID'=>$category[$i],
							'TYPE'=>'CATEGORY',
					);
					
					$this->db->insert('course_area_category_mapping',$categorymapping[$i]);
				}
			}
			
			if(count($software)>0)
			{
				for($i=0;$i<count($software);$i++)
				{
					$softwaremapping[$i]=array(
							'COURSE_ID'=>$ID,
							'AREA_CAT_SOFTWARE_ID'=>$software[$i],
							'TYPE'=>'SOFTWARE',
								
					);
						
					$this->db->insert('course_area_category_mapping',$softwaremapping[$i]);
				}
			}
			
			if(count($area)>0)
			{
				for($i=0;$i<count($area);$i++)
				{
					$areamapping[$i]=array(
							'COURSE_ID'=>$ID,
							'AREA_CAT_SOFTWARE_ID'=>$area[$i],
							'TYPE'=>'AREA',
								
					);
						
					$this->db->insert('course_area_category_mapping',$areamapping[$i]);
				}
			}
			/********************
			 * End insert mapping
			 *******************/
			
			$content=array();
			$contentType = $this->input->post('type');
			$contentData = $this->input->post('COURSE_CONTENT');
			$countImages=0;
			$imageArray=array();
			for($i=0;$i<count($contentType);$i++)
			{
				if($contentType[$i]=="FILEUPLOAD")
				{
					$countImages++;
				}
			}
				
			if($this->input->post('COURSE_CONTENT_IMAGE')!=null)
			{
				$course_content_image=$this->input->post('COURSE_CONTENT_IMAGE');
			}
			
			$content_image=0;
			if(count($_FILES['COURSE_CONTENT']['name'])>0)
			{
				for($j=0;$j<count($_FILES['COURSE_CONTENT']['name']);$j++)
				{
					if($_FILES['COURSE_CONTENT']['name'][$j]=="")
					{
						$imageNameArray[$j]=$course_content_image[$content_image];
						$content_image++;
					}
					else 
					{
						
						$imageNameArray[$j] = random_string('alnum',32).$_FILES['COURSE_CONTENT']['name'][$j];
					}
				}
			}
				
			$this->load->library('upload');
			$this->load->library('image_lib');
			
			$files = $_FILES;
			$cpt = count($_FILES['COURSE_CONTENT']['name']);
				
			for($j=0; $j<$cpt; $j++)
			{
				if($_FILES['COURSE_CONTENT']['name'][$j]=="")
				{
				}
				else
				{
					$_FILES['COURSE_CONTENT']['name']= $files['COURSE_CONTENT']['name'][$j];
					$_FILES['COURSE_CONTENT']['type']= $files['COURSE_CONTENT']['type'][$j];
					$_FILES['COURSE_CONTENT']['tmp_name']= $files['COURSE_CONTENT']['tmp_name'][$j];
					$_FILES['COURSE_CONTENT']['error']= $files['COURSE_CONTENT']['error'][$j];
					$_FILES['COURSE_CONTENT']['size']= $files['COURSE_CONTENT']['size'][$j];
						
					$config['upload_path'] = './uploads/course/';
					$config['allowed_types'] = 'gif|jpg|png|jpeg';
					$config['file_name'] = $imageNameArray[$j];
					
					//$config['encrypt_name'] = TRUE;
					
					
					$this->upload->initialize($config);
					if ( ! $this->upload->do_upload('COURSE_CONTENT')) {echo $this->upload->display_errors();die();}
					$file_data = $this->upload->data();
					$filename = $imageNameArray[$j];
					
					
					print_r($file_data);
					
					
					
					$config['image_library'] = 'gd2';
					$config['source_image'] = $file_data['full_path'];
					$config['new_image'] = './uploads/course/' . $file_data['file_name'];
					$config['maintain_ratio'] = FALSE;
					$config['width'] = 870;
					$config['height'] = 540;
					
					$this->image_lib->initialize($config);
					$src = $config['new_image'];
					$data['new_image'] = substr($src, 2);
					$data['img_src'] = base_url() . $data['new_image'];
					$this->image_lib->resize();
					
					
					//echo $this->image_lib->resize();
				
					//exit;
					
				}
			}	
			$imageCount=0;
			$contentCount=0;
			
			$this->model->course_information_delete($table='course_information',$key='COURSE_ID',$ID);
			
			if(count($contentType)>0){
					for($i=0;$i<count($contentType);$i++)
					{
						
						if($contentType[$i]=="TEXT")
						{
							$content[$i]=array(
									'COURSE_ID'=>$ID,
									'COURSE_INFO_CONT_TYPE'=>$contentType[$i],
									'COURSE_INFO_CONT_VALUE'=>htmlspecialchars_decode($contentData[$contentCount]),
									'COURSE_INFO_CONT_ORDER'=>$i+1
							);
							$contentCount++;
								
						}
						elseif($contentType[$i]=="MEDIA")
						{
							
							$content[$i]=array(
									'COURSE_ID'=>$ID,
									'COURSE_INFO_CONT_TYPE'=>$contentType[$i],
									'COURSE_INFO_CONT_VALUE'=>$contentData[$contentCount],
									'COURSE_INFO_CONT_ORDER'=>$i+1
							);
							$contentCount++;
						}
						
						else 
						{
							$content[$i]=array(
									'COURSE_ID'=>$ID,
									'COURSE_INFO_CONT_TYPE'=>$contentType[$i],
									'COURSE_INFO_CONT_VALUE'=>$imageNameArray[$imageCount],
									'COURSE_INFO_CONT_ORDER'=>$i+1
							);
							$imageCount++;
						}
						$this->db->insert('course_information',$content[$i]);
						
					}
			}
			else 
			{
				$content=array(
						'COURSE_ID'=>$ID,
						'COURSE_INFO_CONT_TYPE'=>'',
						'COURSE_INFO_CONT_VALUE'=>'',
						'COURSE_INFO_CONT_ORDER'=>'1'
				);
				$this->db->insert('course_information',$content);
				
			}
			
			$this->session->set_userdata(array(
					'COURSE_ID'  => $ID,
					'COURSE_NAME'    => $data['COURSE_NAME'],
					
			));

			if($this->input->post('Update')=='update')
			{
				SiteHelpers::alert('success'," Data Has Been Changed Successfull !");
				redirect( 'admin/course',301);
			} else {
				
				
				redirect( 'unit/add',301);
			}
			
	}

	function destroy()
	{
		#############################################
		
		$this->model->courseImageDelete($this->input->post( 'id' , true ));
		
		$this->model->course_mapping_delete($table='course_area_category_mapping',$key='COURSE_ID',$this->input->post( 'id' , true ));
		
		#############################################
		
		$this->model->course_delete($table='course_information',$key='COURSE_ID',$this->input->post( 'id' , true ));
		$this->model->reviewDelete('course_review',$this->input->post( 'id' , true ));
		
		$this->model->course_mapping_delete($table='user_course_enroll',$key='COURSE_ID',$this->input->post( 'id' , true ));
		
		$this->model->destroy($this->input->post( 'id' , true ));
		$this->inputLogs("ID : ".implode(",",$this->input->post( 'id' , true ))."  , Has Been Removed Successfull");
		if(count($this->input->post( 'id' , true ))==0)
		{
				
		}
		else
		{
			SiteHelpers::alert('success',"ID : ".implode(",",$this->input->post( 'id' , true ))."  , Has Been Removed Successfull");
		}		
		Redirect('admin/course',301); 
	}


}
