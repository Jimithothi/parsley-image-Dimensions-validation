<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * @package     CodeIgniter
 * @author      Ikraftsolutions
 * @copyright   Copyright (c) Ikraftsolutions (http://ikraftsolutions.com)
 * @version 1.0
 */

class Account extends SB_Controller
{
	protected $layout 	= "frontend/layouts/main";
	protected $table='user_master';
	protected $primaryKey='USER_ID';
	function __construct()
	{
		parent::__construct();
		//$this->load->model('coursesmodel');
		//$this->model = $this->coursesmodel;
		$this->load->model('accountmodel');
		$this->model = $this->accountmodel;
		
	}
	function index()
	{
		log_message('info', 'Editing :::::::: ');
		
		if(count($this->input->post())==0)
		{
			show_404();
		}
		else 
		{
			if($this->session->userdata('userId')=='')
			{
				show_404();
			}
			else 
			{
				$userInfo=$this->input->post('user');
				
				$userId=$this->session->userdata('userId');
				
				if(!isset($_FILES['user_avatar']))
				{
					$data=array(
							'TELL_ABOUT_YOURSELF'=>$userInfo['about_me'],
							'FIRST_NAME'=>$userInfo['name'],
							'LAST_NAME'=>$userInfo['last_name'],
							'PROFESSIONAL_HEADLINE'=>$userInfo['professional'],
							'WEBSITE'=>$userInfo['website'],
							'PHONE'=>$userInfo['phone']
					);
				}
				else 
				{
					
					$data=array(
							'TELL_ABOUT_YOURSELF'=>$userInfo['about_me'],
							'FIRST_NAME'=>$userInfo['name'],
							'LAST_NAME'=>$userInfo['last_name'],
							'PROFESSIONAL_HEADLINE'=>$userInfo['professional'],
							'WEBSITE'=>$userInfo['website'],
							'PHONE'=>$userInfo['phone']
					);
					$this->db->where( array( $this->primaryKey => $userId ));
					$this->db->update( $this->table , $data );
						
					
					if($_FILES['user_avatar']['name']!='')
					{
						
						
						
						$this->load->library('upload');
						
						$config['upload_path'] = './uploads/users/';
						$config['allowed_types'] = 'gif|jpg|png';
						
						$this->upload->initialize($config);
						if ( ! $this->upload->do_upload('user_avatar')) {echo $this->upload->display_errors();die();}
						$file_data = $this->upload->data();
							
						$file_path     = $file_data['file_path'];
						$file         = $file_data['full_path'];
						$file_ext     = $file_data['file_ext'];
							
						$final_file_name = md5(time()).$file_ext;
						
						rename($file, $file_path . $final_file_name);
							
						$data=array(
								'USER_IMAGE'=>$final_file_name,
								
						);
							
						$this->session->set_userdata(array(
								'user_avatar'=>base_url().'uploads/users/'.$final_file_name
						));
						
						
						$this->model->unsetImage($userId,'USER_IMAGE',$path='uploads/users/');
						$this->db->where( array( $this->primaryKey => $userId ));
						$this->db->update( $this->table , $data );
						
					}
					
					SiteHelpers::alert('success'," Profile Update Success fully");
					redirect('account/edit');
				
				}
			}
		}
		//show_404(); 
	}
	
	function edit()
	{
		if($this->session->userdata('userId')=='')
		{
				show_404();
		}
		else 
		{
			$userId= $this->session->userdata('userId');
			
			log_message('info', "User ID :::::::::::::::::::::.$userId");
			
			$result=$this->model->getuserRow($userId);
		
			$this->data['row']=$result;
			
			$this->data['content'] = $this->load->view('frontend/account/index',$this->data,true);
			
			$this->load->view($this->layout, $this->data );
		}
	}
}